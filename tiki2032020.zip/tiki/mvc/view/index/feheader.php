<div class="dx-header" style="height: 300px; background-color: #195db0; color: white; padding-top: 30px">
    <div class="logo"></div>
    <div class="header-main" style="text-align: center">
        <h1>BỘ VĂN HÓA, THỂ THAO VÀ DU LỊCH</h1>
        <h3>Khảo sát hiện trạng ứng dụng phần mềm công nghệ thông tin tại các cơ sở đào tạo</h3>
    </div>
</div>