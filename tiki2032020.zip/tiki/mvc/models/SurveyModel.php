<?php
namespace MVC\Models;

class SurveyModel extends Database {


    public function getAll() {

        $stmt = $this->connection->prepare("SELECT * FROM userkhaosat");
        $stmt->execute();

        // set the resulting array to associative
        $result = $stmt->setFetchMode(\PDO::FETCH_ASSOC);

        return $stmt->fetchAll();
    }

    public function getAllTable($table, $id) {

        $stmt = $this->connection->prepare("SELECT * FROM ".$table. " WHERE user_id_answer = ?");
        $stmt->execute([$id]);

        // set the resulting array to associative
        $result = $stmt->setFetchMode(\PDO::FETCH_ASSOC);

        return $stmt->fetchAll();
    }


    public function getSurveyById($id) {
        $id = intval($id);
        $stmt = $this->connection->prepare("SELECT * FROM userkhaosat WHERE id = ?");
        $stmt->execute([$id]);

        // set the resulting array to associative
        $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $results = $stmt->fetchAll();
        $s = isset($results[0]) ? $results[0] : [];

        return $s;
    }

    public function getSurvey($email, $password) {
        $stmt = $this->connection->prepare("SELECT * FROM userkhaosat WHERE email = ? AND matkhau = ?");
        $stmt->execute([$email, $password]);

        // set the resulting array to associative
        $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $results = $stmt->fetchAll();
        $s = isset($results[0]) ? $results[0] : [];

        return $s;
    }

    public function getSingle($id = 0) {

        /**
         * userkhaosat
         * nghiepvu_survey
         * nghiepvu_lienthong_survey
        nghiepvu_noibo_survey
        maychuvatly
        csdl_datrienkhai
        csdl_traodoi
        ungdungcntt_datrienkhai
        ungdungcntt_dangtrienkhai
        ungdungcntt_yeucau
        v_nhu_cau_dao_tao
         *
         *
         *
         *
         *
         *
         */

        $stmt = $this->connection->prepare("SELECT * FROM userkhaosat WHERE id = ?");
        $stmt->execute([$id]);

        // set the resulting array to associative
        $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $results = $stmt->fetchAll();
        $res = isset($results[0]) ? $results[0] : [];

        $res["nghiepvu"] = $this->getAllTable('nghiepvu_survey', $id);
        $res["nghiepvulienthong"] = $this->getAllTable('nghiepvu_lienthong_survey', $id);
        $res["nghiepvunoibo"] = $this->getAllTable('nghiepvu_noibo_survey', $id);
        $res["maychuvatly"] = $this->getAllTable('maychuvatly', $id);
        $res["csdldatrienkhai"] = $this->getAllTable('csdl_datrienkhai', $id);
        $res["csdltraodoi"] = $this->getAllTable('csdl_traodoi', $id);
        $res["udcnttdatrienkhai"] = $this->getAllTable('ungdungcntt_datrienkhai', $id);
        $res["udcnttdangtrienkhai"] = $this->getAllTable('ungdungcntt_dangtrienkhai', $id);
        $res["udcnttyeucau"] = $this->getAllTable('ungdungcntt_yeucau', $id);
        $res["v_nhu_cau_dao_tao"] = $this->getAllTable('v_nhu_cau_dao_tao', $id);


        return $res;
    }



    public function deleteRel($userId) {
        $stmt = $this->connection->prepare("DELETE FROM nghiepvu_survey WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM nghiepvu_lienthong_survey WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM nghiepvu_noibo_survey WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM maychuvatly WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM csdl_datrienkhai WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM csdl_traodoi WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM ungdungcntt_datrienkhai WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM ungdungcntt_dangtrienkhai WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM ungdungcntt_yeucau WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        $stmt = $this->connection->prepare("DELETE FROM v_nhu_cau_dao_tao WHERE user_id_answer = ?");
        $res = $stmt->execute([$userId]);

        return;
    }


    public function insertSurvey($data) {
        /*$ten = $data['ten'];
        $donvikhaosat = $data['donvikhaosat'];
        $thoigian = $data['thoigian'];
        $so_dien_thoai = $data['so_dien_thoai'];
        $email = $data['email'];
        $bo_phan_khao_sat = $data['bo_phan_khao_sat'];
        $dai_dien = $data['dai_dien'];
        $chuc_vu = $data['chuc_vu'];
        $danh_sach_chuc_nang_nghiep_vu_file = $data['danh_sach_chuc_nang_nghiep_vu_file'];
        $danh_sach_chuc_nang_nghiep_vu_txt = $data['danh_sach_chuc_nang_nghiep_vu_txt'];
        $kho_khan_nghiep_vu = $data['kho_khan_nghiep_vu'];
        $hai_dich_vu_truc_tuyen = $data['hai_dich_vu_truc_tuyen'];
        $hai_phan_mem_thu_dien_tu = $data['hai_phan_mem_thu_dien_tu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_quy_che_thu_dien_tu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_so_luong_cap_thu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_ty_le_dung_thu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_ty_le_phan_tram_thu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_thu_cong_cong'];
        $hai_phan_mem_thu_dien_tu = $data['phong_may_chu'];
        $hai_phan_mem_thu_dien_tu = $data['moi_truong_du_phong'];
        $hai_phan_mem_thu_dien_tu = $data['may_chu_sao_luu'];
        $hai_phan_mem_thu_dien_tu = $data['nam_bo_phan_chuyen_trach'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cb_chuyen_trach'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cb_chuyen_trach'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cb_kiem_nhiem'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cntt_kiem_nhiem'];
        $hai_phan_mem_thu_dien_tu = $data['su_dung_pm_van_phong'];
        $hai_phan_mem_thu_dien_tu = $data['tiensi'];
        $hai_phan_mem_thu_dien_tu = $data['thacsi'];
        $hai_phan_mem_thu_dien_tu = $data['daihoc'];
        $hai_phan_mem_thu_dien_tu = $data['caodang'];
        $hai_phan_mem_thu_dien_tu = $data['trungcap'];
        $hai_phan_mem_thu_dien_tu = $data['ykien_khokhan'];
        $hai_phan_mem_thu_dien_tu = $data['ykien_thuanloi'];
        $hai_phan_mem_thu_dien_tu = $data['ykien_dexuat'];*/

        $fieldsD = ["ten"	,"donvikhaosat",	"thoigian"	,"so_dien_thoai"	,"email",	"bo_phan_khao_sat",	"dai_dien",	"chuc_vu",	"danh_sach_chuc_nang_nghiep_vu_file",	"danh_sach_chuc_nang_nghiep_vu_txt",	"kho_khan_nghiep_vu",	"hai_dich_vu_truc_tuyen"	   ,"hai_phan_mem_thu_dien_tu"	,"hai_quy_che_thu_dien_tu",	"hai_so_luong_cap_thu"	,"hai_ty_le_dung_thu"	,"hai_ty_le_phan_tram_thu",	"hai_thu_cong_cong"	,"phong_may_chu"	,"moi_truong_du_phong","may_chu_mo_rong","may_chu_sao_luu","nam_bo_phan_chuyen_trach","tong_so_cb_chuyen_trach"	  ,"tong_so_cb_kiem_nhiem"	,"tong_so_cntt_kiem_nhiem","su_dung_pm_van_phong","tiensi","thacsi","daihoc","caodang"	,"trungcap"	,"ykien_khokhan",	"ykien_thuanloi",	"ykien_dexuat", "matkhau"];
        $fields = [];
        foreach($fieldsD as $kf => $field) {
            $fields[$field] = $data[$field];
        }

        extract($fields);

        $sqlVal = str_repeat("?,",count($fields)-1);
        $sqlVal .= "?";

      /*  "id"	"ten"	"donvikhaosat"	"thoigian"	"so_dien_thoai"	"email"	"bo_phan_khao_sat"	"dai_dien"	"chuc_vu"	"danh_sach_chuc_nang_nghiep_vu_file"	"danh_sach_chuc_nang_nghiep_vu_txt"	"kho_khan_nghiep_vu"	"hai_dich_vu_truc_tuyen"	"hai_phan_mem_thu_dien_tu"	"hai_quy_che_thu_dien_tu"	"hai_so_luong_cap_thu"	"hai_ty_le_dung_thu"	"hai_ty_le_phan_tram_thu"	"hai_thu_cong_cong"	"phong_may_chu"	"moi_truong_du_phong"	"may_chu_mo_rong"	"may_chu_sao_luu"	"nam_bo_phan_chuyen_trach"	"tong_so_cb_chuyen_trach"	"tong_so_cb_kiem_nhiem"	"tong_so_cntt_kiem_nhiem"	"su_dung_pm_van_phong"	"tiensi"	"thacsi"	"daihoc"	"caodang"	"trungcap"	"ykien_khokhan"	"ykien_thuanloi"	"ykien_dexuat"*/
        $stmt = $this->connection->prepare("INSERT INTO userkhaosat (ten, donvikhaosat,thoigian,so_dien_thoai,email,bo_phan_khao_sat,dai_dien,chuc_vu,danh_sach_chuc_nang_nghiep_vu_file,danh_sach_chuc_nang_nghiep_vu_txt,kho_khan_nghiep_vu,hai_dich_vu_truc_tuyen,hai_phan_mem_thu_dien_tu,hai_quy_che_thu_dien_tu,hai_so_luong_cap_thu,hai_ty_le_dung_thu,hai_ty_le_phan_tram_thu,hai_thu_cong_cong,phong_may_chu,moi_truong_du_phong,may_chu_mo_rong,may_chu_sao_luu,nam_bo_phan_chuyen_trach,tong_so_cb_chuyen_trach,tong_so_cb_kiem_nhiem,tong_so_cntt_kiem_nhiem,su_dung_pm_van_phong,tiensi,thacsi,daihoc,caodang,trungcap,ykien_khokhan,ykien_thuanloi,ykien_dexuat,matkhau) VALUES ($sqlVal)");
        $res = $stmt->execute([$ten, $donvikhaosat,$thoigian,$so_dien_thoai,$email,$bo_phan_khao_sat,$dai_dien,$chuc_vu,$danh_sach_chuc_nang_nghiep_vu_file,$danh_sach_chuc_nang_nghiep_vu_txt,$kho_khan_nghiep_vu,$hai_dich_vu_truc_tuyen,$hai_phan_mem_thu_dien_tu,$hai_quy_che_thu_dien_tu,$hai_so_luong_cap_thu,$hai_ty_le_dung_thu,$hai_ty_le_phan_tram_thu,$hai_thu_cong_cong,$phong_may_chu,$moi_truong_du_phong,$may_chu_mo_rong,$may_chu_sao_luu,$nam_bo_phan_chuyen_trach,$tong_so_cb_chuyen_trach,$tong_so_cb_kiem_nhiem,$tong_so_cntt_kiem_nhiem,$su_dung_pm_van_phong,$tiensi,$thacsi,$daihoc,$caodang,$trungcap,$ykien_khokhan,$ykien_thuanloi,$ykien_dexuat,$matkhau]);

        return $this->connection->lastInsertId();
    }



    public function updateSurvey($data, $id) {
        /*$ten = $data['ten'];
        $donvikhaosat = $data['donvikhaosat'];
        $thoigian = $data['thoigian'];
        $so_dien_thoai = $data['so_dien_thoai'];
        $email = $data['email'];
        $bo_phan_khao_sat = $data['bo_phan_khao_sat'];
        $dai_dien = $data['dai_dien'];
        $chuc_vu = $data['chuc_vu'];
        $danh_sach_chuc_nang_nghiep_vu_file = $data['danh_sach_chuc_nang_nghiep_vu_file'];
        $danh_sach_chuc_nang_nghiep_vu_txt = $data['danh_sach_chuc_nang_nghiep_vu_txt'];
        $kho_khan_nghiep_vu = $data['kho_khan_nghiep_vu'];
        $hai_dich_vu_truc_tuyen = $data['hai_dich_vu_truc_tuyen'];
        $hai_phan_mem_thu_dien_tu = $data['hai_phan_mem_thu_dien_tu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_quy_che_thu_dien_tu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_so_luong_cap_thu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_ty_le_dung_thu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_ty_le_phan_tram_thu'];
        $hai_phan_mem_thu_dien_tu = $data['hai_thu_cong_cong'];
        $hai_phan_mem_thu_dien_tu = $data['phong_may_chu'];
        $hai_phan_mem_thu_dien_tu = $data['moi_truong_du_phong'];
        $hai_phan_mem_thu_dien_tu = $data['may_chu_sao_luu'];
        $hai_phan_mem_thu_dien_tu = $data['nam_bo_phan_chuyen_trach'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cb_chuyen_trach'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cb_chuyen_trach'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cb_kiem_nhiem'];
        $hai_phan_mem_thu_dien_tu = $data['tong_so_cntt_kiem_nhiem'];
        $hai_phan_mem_thu_dien_tu = $data['su_dung_pm_van_phong'];
        $hai_phan_mem_thu_dien_tu = $data['tiensi'];
        $hai_phan_mem_thu_dien_tu = $data['thacsi'];
        $hai_phan_mem_thu_dien_tu = $data['daihoc'];
        $hai_phan_mem_thu_dien_tu = $data['caodang'];
        $hai_phan_mem_thu_dien_tu = $data['trungcap'];
        $hai_phan_mem_thu_dien_tu = $data['ykien_khokhan'];
        $hai_phan_mem_thu_dien_tu = $data['ykien_thuanloi'];
        $hai_phan_mem_thu_dien_tu = $data['ykien_dexuat'];*/

        $fieldsD = ["ten"	,"donvikhaosat",	"thoigian"	,"so_dien_thoai"	,"email",	"bo_phan_khao_sat",	"dai_dien",	"chuc_vu",	"danh_sach_chuc_nang_nghiep_vu_file",	"danh_sach_chuc_nang_nghiep_vu_txt",	"kho_khan_nghiep_vu",	"hai_dich_vu_truc_tuyen"	   ,"hai_phan_mem_thu_dien_tu"	,"hai_quy_che_thu_dien_tu",	"hai_so_luong_cap_thu"	,"hai_ty_le_dung_thu"	,"hai_ty_le_phan_tram_thu",	"hai_thu_cong_cong"	,"phong_may_chu"	,"moi_truong_du_phong","may_chu_mo_rong","may_chu_sao_luu","nam_bo_phan_chuyen_trach","tong_so_cb_chuyen_trach"	  ,"tong_so_cb_kiem_nhiem"	,"tong_so_cntt_kiem_nhiem","su_dung_pm_van_phong","tiensi","thacsi","daihoc","caodang"	,"trungcap"	,"ykien_khokhan",	"ykien_thuanloi",	"ykien_dexuat", "matkhau"];
        $fields = [];
        foreach($fieldsD as $kf => $field) {
            if (isset($data[$field])) {
                $fields[$field] = $data[$field];
            }
        }

        extract($fields);

        $sqlVal = str_repeat("?,",count($fields)-1);
        $sqlVal .= "?";

        /*  "id"	"ten"	"donvikhaosat"	"thoigian"	"so_dien_thoai"	"email"	"bo_phan_khao_sat"	"dai_dien"	"chuc_vu"	"danh_sach_chuc_nang_nghiep_vu_file"	"danh_sach_chuc_nang_nghiep_vu_txt"	"kho_khan_nghiep_vu"	"hai_dich_vu_truc_tuyen"	"hai_phan_mem_thu_dien_tu"	"hai_quy_che_thu_dien_tu"	"hai_so_luong_cap_thu"	"hai_ty_le_dung_thu"	"hai_ty_le_phan_tram_thu"	"hai_thu_cong_cong"	"phong_may_chu"	"moi_truong_du_phong"	"may_chu_mo_rong"	"may_chu_sao_luu"	"nam_bo_phan_chuyen_trach"	"tong_so_cb_chuyen_trach"	"tong_so_cb_kiem_nhiem"	"tong_so_cntt_kiem_nhiem"	"su_dung_pm_van_phong"	"tiensi"	"thacsi"	"daihoc"	"caodang"	"trungcap"	"ykien_khokhan"	"ykien_thuanloi"	"ykien_dexuat"*/
        $stmt = $this->connection->prepare("UPDATE userkhaosat SET ten = ?, donvikhaosat = ?,thoigian = ?,so_dien_thoai = ?,email = ?,bo_phan_khao_sat = ?,dai_dien = ?,chuc_vu = ?,danh_sach_chuc_nang_nghiep_vu_file = ?,danh_sach_chuc_nang_nghiep_vu_txt = ?,kho_khan_nghiep_vu = ?,hai_dich_vu_truc_tuyen = ?,hai_phan_mem_thu_dien_tu = ?,hai_quy_che_thu_dien_tu = ?,hai_so_luong_cap_thu = ?,hai_ty_le_dung_thu = ?,hai_ty_le_phan_tram_thu = ?,hai_thu_cong_cong = ?,phong_may_chu = ?,moi_truong_du_phong = ?,may_chu_mo_rong = ?,may_chu_sao_luu = ?,nam_bo_phan_chuyen_trach = ?,tong_so_cb_chuyen_trach = ?,tong_so_cb_kiem_nhiem = ?,tong_so_cntt_kiem_nhiem = ?,su_dung_pm_van_phong = ?,tiensi = ?,thacsi = ?,daihoc = ?,caodang = ?,trungcap = ?,ykien_khokhan = ?,ykien_thuanloi = ?,ykien_dexuat = ?,matkhau = ? WHERE id = ?");
        $res = $stmt->execute([$ten, $donvikhaosat,$thoigian,$so_dien_thoai,$email,$bo_phan_khao_sat,$dai_dien,$chuc_vu,$danh_sach_chuc_nang_nghiep_vu_file,$danh_sach_chuc_nang_nghiep_vu_txt,$kho_khan_nghiep_vu,$hai_dich_vu_truc_tuyen,$hai_phan_mem_thu_dien_tu,$hai_quy_che_thu_dien_tu,$hai_so_luong_cap_thu,$hai_ty_le_dung_thu,$hai_ty_le_phan_tram_thu,$hai_thu_cong_cong,$phong_may_chu,$moi_truong_du_phong,$may_chu_mo_rong,$may_chu_sao_luu,$nam_bo_phan_chuyen_trach,$tong_so_cb_chuyen_trach,$tong_so_cb_kiem_nhiem,$tong_so_cntt_kiem_nhiem,$su_dung_pm_van_phong,$tiensi,$thacsi,$daihoc,$caodang,$trungcap,$ykien_khokhan,$ykien_thuanloi,$ykien_dexuat,$matkhau, $id]);

        return $res;
    }

    public function updateNghiepVu($data) {
        $user_id_answer = $data['user_id_answer'];
        $hien_trang = $data['hien_trang'];
        $nhu_cau_tin_hoc = $data['nhu_cau_tin_hoc'];
        $ten_nghiep_vu = $data['ten_nghiep_vu'];

        $stmt = $this->connection->prepare("INSERT INTO nghiepvu_survey (user_id_answer, hien_trang,nhu_cau_tin_hoc,ten_nghiep_vu) VALUES (?, ?, ?, ?)");

        $res = $stmt->execute([$user_id_answer, $hien_trang, $nhu_cau_tin_hoc, $ten_nghiep_vu]);
        return $res;
    }

    public function updateNghiepVuLienThong($data) {
        $user_id_answer = $data['user_id_answer'];
        $hien_trang = $data['hien_trang'];
        $nhu_cau_tin_hoc = $data['nhu_cau_tin_hoc'];
        $coquan = $data['coquan'];
        $ten_nghiep_vu = $data['ten_nghiep_vu'];

        $stmt = $this->connection->prepare("INSERT INTO nghiepvu_lienthong_survey (user_id_answer, hien_trang,nhu_cau_tin_hoc,coquan,ten_nghiep_vu) VALUES (?, ?, ?, ?, ?)");
        $res = $stmt->execute([$user_id_answer, $hien_trang, $nhu_cau_tin_hoc, $coquan, $ten_nghiep_vu]);
        return $res;
    }

    public function updateNghiepVuNoiBo($data) {
        $user_id_answer = $data['user_id_answer'];
        $hien_trang = $data['hien_trang'];
        $nhu_cau_tin_hoc = $data['nhu_cau_tin_hoc'];
        $ten_nghiep_vu = $data['ten_nghiep_vu'];

        $stmt = $this->connection->prepare("INSERT INTO nghiepvu_noibo_survey (user_id_answer, hien_trang,nhu_cau_tin_hoc, ten_nghiep_vu) VALUES (?, ?, ?, ?)");
        $res = $stmt->execute([$user_id_answer, $hien_trang, $nhu_cau_tin_hoc, $ten_nghiep_vu]);
        return $res;
    }

    public function updateMayChuVatLy($data) {

        $user_id_answer = $data['user_id_answer'];
        $model = $data['model'];
        $soluong = $data['soluong'];
        $thong_so = $data['thong_so'];
        $nam_dau_tu = $data['nam_dau_tu'];
        $tinh_trang = $data['tinh_trang'];
        $ghi_chu = $data['ghi_chu'];

        $stmt = $this->connection->prepare("INSERT INTO maychuvatly (user_id_answer, model,soluong,thong_so,nam_dau_tu,tinh_trang,ghi_chu) VALUES (?, ?, ?, ?,?,?,?)");
        $res = $stmt->execute([$user_id_answer, $model, $soluong, $thong_so,$nam_dau_tu,$tinh_trang,$ghi_chu]);
        return $res;
    }

    public function updateCSDLDaTrienKhai($data) {
        $user_id_answer = $data['user_id_answer'];
        $ten_csdl = $data['ten_csdl'];
        $he_csdl = $data['he_csdl'];
        $ban_quyen = $data['ban_quyen'];
        $nam_dau_tu = $data['nam_dau_tu'];
        $he_dieu_hanh = $data['he_dieu_hanh'];
        $nhucau = $data['nhucau'];

        $stmt = $this->connection->prepare("INSERT INTO csdl_datrienkhai (user_id_answer, ten_csdl,he_csdl,ban_quyen,nam_dau_tu,he_dieu_hanh,nhucau) VALUES (?, ?, ?, ?,?,?,?)");
        $res = $stmt->execute([$user_id_answer, $ten_csdl, $he_csdl, $ban_quyen,$nam_dau_tu,$he_dieu_hanh,$nhucau]);
        return $res;
    }

    public function updateCSDLTraoDoi($data) {

        $user_id_answer = $data['user_id_answer'];
        $linh_vuc = $data['linh_vuc'];
        $don_vi_lien_quan = $data['don_vi_lien_quan'];
        $thong_tin_trao_doi = $data['thong_tin_trao_doi'];
        $tan_suat = $data['tan_suat'];
        $phuong_thuc = $data['phuong_thuc'];
        $ghi_chu = $data['ghi_chu'];

        $stmt = $this->connection->prepare("INSERT INTO csdl_traodoi (user_id_answer, linh_vuc,don_vi_lien_quan,thong_tin_trao_doi,tan_suat,phuong_thuc,ghi_chu) VALUES (?, ?, ?, ?,?,?,?)");
        $res = $stmt->execute([$user_id_answer, $linh_vuc, $don_vi_lien_quan, $thong_tin_trao_doi,$tan_suat,$ghi_chu,$ghi_chu]);
        return $res;
    }

    public function updateUDCNTTDaTrienKhai($data) {
        $user_id_answer = $data['user_id_answer'];
        $ten_phan_mem = $data['ten_phan_mem'];
        $mo_ta_chung = $data['mo_ta_chung'];
        $doituongsudung = $data['doituongsudung'];
        $nhucau = $data['nhucau'];
        $nguyennhan = $data['nguyennhan'];

        $stmt = $this->connection->prepare("INSERT INTO ungdungcntt_datrienkhai (user_id_answer, ten_phan_mem,mo_ta_chung,doituongsudung,nhucau,nguyennhan) VALUES (?, ?, ?, ?,?,?)");
        $res = $stmt->execute([$user_id_answer, $ten_phan_mem, $mo_ta_chung, $doituongsudung,$nhucau,$nguyennhan]);
        return $res;
    }


    public function updateUDCNTTDangTrienKhai($data) {
        $user_id_answer = $data['user_id_answer'];
        $ten_duan = $data['ten_duan'];
        $muctieu = $data['muctieu'];
        $quymo = $data['quymo'];
        $tongmucdautu = $data['tongmucdautu'];
        $noidung = $data['noidung'];
        $ghichu = $data['ghichu'];
        $thoigianthuchien = $data['thoigianthuchien'];

        $stmt = $this->connection->prepare("INSERT INTO ungdungcntt_dangtrienkhai (user_id_answer, ten_duan,muctieu,quymo,tongmucdautu,noidung,ghichu, thoigianthuchien) VALUES (?, ?, ?, ?,?,?,?, ?)");
        $res = $stmt->execute([$user_id_answer, $ten_duan, $muctieu, $quymo,$tongmucdautu,$noidung,$ghichu,$thoigianthuchien]);
        return $res;
    }

    public function updateUDCNTTNhuCau($data) {
        $user_id_answer = $data['user_id_answer'];
        $yeucau = $data['yeucau'];
        $ungdungdexuat = $data['ungdungdexuat'];

        $stmt = $this->connection->prepare("INSERT INTO ungdungcntt_yeucau (user_id_answer, yeucau,ungdungdexuat) VALUES (?, ?, ?)");
        $res = $stmt->execute([$user_id_answer, $yeucau, $ungdungdexuat]);
        return $res;
    }

    public function updateNhuCauDaoTao($data) {
        $user_id_answer = $data['user_id_answer'];
        $noidung_daotao = $data['noidung_daotao'];
        $muc_do_uu_tien = $data['muc_do_uu_tien'];
        $soluong_hocvien = $data['soluong_hocvien'];

        $stmt = $this->connection->prepare("INSERT INTO v_nhu_cau_dao_tao (user_id_answer, noidung_daotao,muc_do_uu_tien,soluong_hocvien) VALUES (?, ?, ?, ?)");
        $res = $stmt->execute([$user_id_answer, $noidung_daotao, $muc_do_uu_tien, $soluong_hocvien]);
        return $res;
    }

    public function delete($id) {

        $sqlDelete = "DELETE FROM employees WHERE id = $id";
        if (mysqli_query($this->connection, $sqlDelete)) {
            return true;
        }

        return false;

    }


    public function getLoginSurvey($username, $password) {

        $sqlLogin = "SELECT * FROM userkhaosat WHERE email = ? AND matkhau = ?";

        $stmt = $this->connection->prepare($sqlLogin);
        $stmt->execute([$username,$password]);

        // set the resulting array to associative
        $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $results = $stmt->fetchAll();
        $res = isset($results[0]) ? $results[0] : [];

        return $res;
    }


    public function checkExistEmail($email) {

        $sqlLogin = "SELECT * FROM userkhaosat WHERE email = ?";

        $stmt = $this->connection->prepare($sqlLogin);
        $stmt->execute([$email]);

        // set the resulting array to associative
        $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $results = $stmt->fetchAll();
        $res = isset($results[0]) ? $results[0] : [];

        return $res;
    }


    public function checkAdministratorLogin($username, $password) {

        $sqlLogin = "SELECT * FROM admin WHERE username = ? AND password = ?";

        $stmt = $this->connection->prepare($sqlLogin);
        $stmt->execute([$username, $password]);

        // set the resulting array to associative
        $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $results = $stmt->fetchAll();
        $res = isset($results[0]) ? $results[0] : [];

        return $res;
    }
}