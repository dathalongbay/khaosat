<?php

namespace MVC\Controllers;

use MVC\Models\EmployeeModel;

class BeanswerController {


    public function indexAction() {

    }


    public function loginAction() {

    }


    public function logoutAction() {

    }

}