<?php

namespace MVC\Controllers;


use MVC\Models\SurveyModel;

class BeadminController {

    public function __construct()
    {

    }


    public function index() {
        if (!isset($_SESSION["loggedin"])) {
            header("Location: index.php?controller=beadmin&action=login");
            exit;
        }

        include_once "mvc/view/beadmin/index.php";
    }


    public function login() {


        if (isset($_SESSION["admin_login_error"])) {
            $errors = $_SESSION["admin_login_error"];
            unset($_SESSION["admin_login_error"]);
        }

        include_once "mvc/view/beadmin/login.php";
    }


    public function logged() {
        $errors = [];


        if (isset($_POST) && !empty($_POST)) {

            if (!isset($_POST["username"]) || empty($_POST["username"])) {
                $errors[] = "Chưa nhập username";
            }
            if (!isset($_POST["password"]) || empty($_POST["password"])) {
                $errors[] = "Chưa nhập password";
            }

            /**
             * Nếu mảng $errors bị rỗng tức là không có lỗi đăng nhập
             */
            if (is_array($errors) && empty($errors)) {
                $username = $_POST["username"];
                $password = md5($_POST["password"]);

                $model = new SurveyModel();
                $res = $model->checkAdministratorLogin($username, $password);

                if (isset($res['id']) && ($res['id'] > 0)) {

                    /**
                     * Nếu tồn tại bản ghi
                     * thì sẽ tạo ra session đăng nhập
                     */
                    $_SESSION["loggedin"] = true;
                    $_SESSION["username"] = $res['username'];

                    header("Location: index.php?controller=beadmin&action=index");
                    exit;
                } else {
                    $errors[] = "Dữ liệu đăng nhập không đúng";


                }

            }

        }

        $_SESSION["admin_login_error"] = $errors;

        header("Location: index.php?controller=beadmin&action=login");
        exit;
    }





}