<?php
session_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

define("ADMIN_PHONE", "0977565104");
define("QUYDINH_KS", "
1. Cán bộ thực hiện khảo sát lựa chọn đơn vị mình phụ trách
<br>
2. Điền đầy đủ thông tin sau đó click và nút “Thực hiện khảo sát”. Lưu ý: Bắt buộc phải điền vào các ô bắt buộc (*)
<br>
3. Sau khi hoàn thành tất cả các câu hỏi khảo sát. Cán bộ thực hiện khảo sát click vào nút “Hoàn thành khảo sát” hệ thống sẽ tự động gửi dữ liệu về cơ quan bộ.
<br>
4. Để xem lại và chỉnh sửa  nội dung khảo sát click và nút “Chỉnh sửa lại khảo sát”. Để hoàn thành thực hiện theo thao tác mục 3.
");

/**
 * Nạp các file cần thiết vào luồng chạy của MVC
 */
define("BASE_PATH", dirname(__FILE__));
define("BASE_URL", "http://localhost:8080/tiki/");

include_once "mvc/route.php";
include_once "mvc/models/Database.php";
include_once "mvc/models/SurveyModel.php";
include_once "mvc/controllers/BeadminController.php";
include_once "mvc/controllers/LogoutController.php";
include_once "mvc/controllers/BesurveyController.php";
include_once "mvc/controllers/IndexController.php";
include_once "mvc/controllers/ErrorController.php";


/**
 * Cần phải hiểu là trong ứng dụng MVC đến Framework
 * mọi request http sẽ đi qua index.php
 * => đi đến file điều hướng route.php
 * => file điều hướng sẽ gọi controller tương ứng với request
 * => controller gọi đến method có action tương ứng
 *
 * Route : chịu trách nhiệm dẫn hướng cho request vào Controller
 * Controller chịu trách nhiệm điều hướng . gọi model . trả vê view . redirect URL
 * Model : chịu trách nhiệm xử lý tính toán , tương tác trực tiếp với CSDL
 * View : chỉ chịu trách nhiệm hiển thị dữ liệu và giao diện
 * Mọi request đều chạy qua index.php
 * chứ ko trực tiếp chạy vào file controller
 *
 * View có khái niệm layout và view
 * Layout là bố cục hiển thị gồm header , footer , sidebar
 * View là khai niệm để nói về nội dung chính trong trang
 * Các trang đa số chỉ thay đổi nội dung chính giữa trang mà không thay đổi header hay footer
 */
$route = new \MVC\Route();

$route->run();

