<?php

namespace MVC\Controllers;


use MVC\Models\SurveyModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class BeadminController {

    public function __construct()
    {

    }

    public function test() {

        $htmlString = '<table>
                  <tr>
                      <td style="width: 30px;font-size: 20px">Hello World</td>
                      <td style="width: 30px;font-size: 20px">Hello World</td>
                      <td style="width: 30px;font-size: 20px">Hello World</td>
                  </tr>
                  <tr>
                      <td>Hello<br />World Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </td>
                      <td>Hello<br />World</td>
                      <td>Hello<br />World</td>
                  </tr>
                  <tr>
                      <td>Hello<br>World</td>
                      <td>Hello<br>World</td>
                      <td>Hello<br>World</td>
                  </tr>
              </table>';

        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Html();
        $spreadsheet = $reader->loadFromString($htmlString);

        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
        $name = time().'write.xlsx';
        $writer->save($name);

        header("Location: " . BASE_URL.$name); exit;
    }

    public function testsave() {
        echo __METHOD__;
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Hello World !');

        $writer = new Xlsx($spreadsheet);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="demo.xlsx"');
        header('Cache-Control: max-age=0');
        header('Expires: Fri, 11 Nov 2011 11:11:11 GMT');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
        header('Cache-Control: cache, must-revalidate');
        header('Pragma: public');
        $writer->save('php://output'); die;

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="file.xlsx"');
        //$writer->save("php://output");
        $writer->save('file.xlsx');
        die;


        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, "Xlsx");
        $writer->save("05featuredemo.xlsx");

        $htmlString = '<table>
                  <tr>
                      <td>Hello World</td>
                  </tr>
                  <tr>
                      <td>Hello<br />World</td>
                  </tr>
                  <tr>
                      <td>Hello<br>World</td>
                  </tr>
              </table>';

        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Html();
        $spreadsheet = $reader->loadFromString($htmlString);

        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xls');
        //$writer->save('write.xls');

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="file.xlsx"');
        $writer->save("php://output");
        //exit;
    }


    public function index() {
        if (!isset($_SESSION["loggedin"])) {
            header("Location: index.php?controller=beadmin&action=login");
            exit;
        }

        include_once "mvc/view/beadmin/index.php";
    }


    public function login() {


        if (isset($_SESSION["admin_login_error"])) {
            $errors = $_SESSION["admin_login_error"];
            unset($_SESSION["admin_login_error"]);
        }

        include_once "mvc/view/beadmin/login.php";
    }


    public function logged() {
        $errors = [];


        if (isset($_POST) && !empty($_POST)) {

            if (!isset($_POST["username"]) || empty($_POST["username"])) {
                $errors[] = "Chưa nhập username";
            }
            if (!isset($_POST["password"]) || empty($_POST["password"])) {
                $errors[] = "Chưa nhập password";
            }

            /**
             * Nếu mảng $errors bị rỗng tức là không có lỗi đăng nhập
             */
            if (is_array($errors) && empty($errors)) {
                $username = $_POST["username"];
                $password = md5($_POST["password"]);

                $model = new SurveyModel();
                $res = $model->checkAdministratorLogin($username, $password);

                if (isset($res['id']) && ($res['id'] > 0)) {

                    /**
                     * Nếu tồn tại bản ghi
                     * thì sẽ tạo ra session đăng nhập
                     */
                    $_SESSION["loggedin"] = true;
                    $_SESSION["username"] = $res['username'];

                    header("Location: index.php?controller=beadmin&action=index");
                    exit;
                } else {
                    $errors[] = "Dữ liệu đăng nhập không đúng";


                }

            }

        }

        $_SESSION["admin_login_error"] = $errors;

        header("Location: index.php?controller=beadmin&action=login");
        exit;
    }





}