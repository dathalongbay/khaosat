<?php

namespace MVC\Controllers;

use MVC\Models\SurveyModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class BesurveyController {



    public function uploadFile() {

        $target_dir = "uploadstla/";
        $target_file = $target_dir . "dxa" . time() .basename($_FILES["danh_sach_chuc_nang_nghiep_vu_file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $imageFileMimeAccept = ["image/jpeg", "image/gif", "image/png"];
        $imageFileAccept = ["doc", "docx"];
        $errorUpload = [];

        if(isset($_POST["submit"]) && isset($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']) && !empty($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name'])) {

            $mimetype = mime_content_type($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']);
            if(!in_array($mimetype, $imageFileMimeAccept)) {
                $errorUpload[] = "Kiểu file không hợp lệ chỉ upload file đuôi .doc hoặc .docx";
                $uploadOk = 0;
            }
        }

        if ($_FILES["danh_sach_chuc_nang_nghiep_vu_file"]["size"] > 20000000) {
            $errorUpload[] = "Kích cỡ file quá lớn vui lòng chỉ upload tối đa 16MB";
            $uploadOk = 0;
        }

        if(!in_array($imageFileType, $imageFileAccept)) {
            $errorUpload[] = "Kiểu file không hợp lệ chỉ upload file đuôi .doc hoặc .docx";
            $uploadOk = 0;
        }

        if ($uploadOk == 1) {
            if (!move_uploaded_file($_FILES["danh_sach_chuc_nang_nghiep_vu_file"]["tmp_name"], $target_file)) {
                $errorUpload[] = "Xảy ra lỗi trong quá trình upload file";
                $uploadOk = 0;
            }
        }

        if ($uploadOk == 0) {
            $errorUpload[] = "Xin lỗi không thể upload file này";
            $_SESSION["upload_error"] = $errorUpload;
            return false;
        }

        return $target_file;
    }

    public function __construct()
    {
        if (!isset($_SESSION["loggedin"])) {
            header("Location: index.php?controller=beadmin&action=login");
            exit;
        }
    }

    public function index() {

        $model = new SurveyModel();

        $list = $model->getAll();

        include_once "mvc/view/besurvey/index.php";
    }

    public function downloadSurvey() {
        $id = (int)$_GET["id"];
        $model = new SurveyModel();
        $survey = $model->getSingle($id);

       /* echo "<pre>";
        print_r($survey);
        echo "</pre>"; */

        $danh_sach_truong_dh_const = [
            "1" => "Học viện Âm nhạc quốc gia Việt Nam",
            "2" => "Nhạc viện Thành phố Hồ Chí Minh",
            "3" => "Học viện Âm nhạc Huế",
            "4" => "Trường Đại học Văn hóa Hà Nội",
            "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
            "6" => "Trường Đại học Mỹ thuật Việt Nam",
            "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
            "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
            "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
            "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
            "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
            "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
            "13" => "Học viện Múa Việt Nam",
            "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
            "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
            "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
            "17" => "Trường Cao đẳng Du lịch Hà Nội",
            "18" => "Trường Cao đẳng Du lịch Hải Phòng",
            "19" => "Trường Cao đẳng Du lịch Huế",
            "20" => "Trường Cao đẳng Du lịch Nha Trang",
            "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
            "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
            "23" => "Trường Cao đẳng Du lịch Đà Lạt",
            "24" => "Trường Cao đẳng Du lịch Cần Thơ",
            "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
            "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
        ];

        $htmlString = "<tr>
            <td></td>
            <td></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 100px;font-size: 20px; \">ID</td>
            <td style=\"width: 250px;font-size: 20px; \">".$survey["id"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Tên người khảo sát</td>
            <td style=\"font-size: 20px;\">".$survey["ten"]."</td>
        </tr>";

        $dvks = $survey["donvikhaosat"];
        $dvks_text = "";
        if (isset($danh_sach_truong_dh_const[$dvks])) {
            $dvks_text = $danh_sach_truong_dh_const[$dvks];
        }

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Đơn vị khảo sát</td>
            <td style=\"font-size: 20px;\">".$dvks_text."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Thời gian khảo sát</td>
            <td style=\"font-size: 20px;\">".$survey["thoigian"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Số điện thoại</td>
            <td style=\"font-size: 20px;\">SDT ".$survey["so_dien_thoai"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Email</td>
            <td style=\"font-size: 20px;\">".$survey["email"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Bộ phận khảo sát</td>
            <td style=\"font-size: 20px;\">".$survey["bo_phan_khao_sat"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Đại diện đơn vị khảo sát</td>
            <td style=\"font-size: 20px;\">".$survey["dai_dien"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Chức vụ</td>
            <td style=\"font-size: 20px;\">".$survey["chuc_vu"]."</td>
        </tr>";

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";



        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;\">1. Quý đơn vị vui lòng cung cấp danh sách các chức năng nhiệm vụ, nghiệp vụ đang có hiệu lực hoặc chuẩn bị có hiệu lực (nếu có) của Quý đơn vị? (cán bộ làm khảo sát có thể mô tả xuống dưới hoặc chọn chức năng tải văn bản lên</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";
        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Mô tả nghiệp vụ</td>
            <td style=\"font-size: 20px;\">".$survey["danh_sach_chuc_nang_nghiep_vu_txt"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Mô tả nghiệp vụ file upload ( nếu có )</td>
            <td style=\"font-size: 20px;\">".$survey["danh_sach_chuc_nang_nghiep_vu_file"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;\">2. Toàn bộ các chức năng nghiệp vụ do Quý đơn vị cung cấp đã được tin học hóa thành phần mềm quản trị chưa? Nếu có, vui lòng chuyển sang mục 3. Nếu chưa, xin vui lòng cung cấp các thông tin sau
</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên nghiệp vụ</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Hiện trạng</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nhu cầu tin học</td>
        </tr>";

        foreach($survey["nghiepvu"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\">STT</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ten_nghiep_vu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["hien_trang"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nhu_cau_tin_hoc"]."</td>
            </tr>";
        }

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;\">3. Quý đơn vị vui lòng cung cấp thông tin hiện trạng liên thông phối hợp từ các bộ phận liên quan trong chuỗi quy trình nghiệp vụ quản lý có nhu cầu tin học hóa theo các nội dung sau đây.
</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên nghiệp vụ</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Cơ quan</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Hiện trạng</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nhu cầu tin học</td>
        </tr>";

        foreach($survey["nghiepvulienthong"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\">STT</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ten_nghiep_vu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["coquan"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["hien_trang"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nhu_cau_tin_hoc"]."</td>
            </tr>";
        }



        $htmlString .= "<tr>
            <td style=\"font-size: 20px;\">4. Quý đơn vị vui lòng nêu khó khăn, bất cập liên quan đến công tác quản lý, hoặc sự phối hợp với các cơ quan liên quan trong việc xử lý các nghiệp vụ liên thông với các đơn vị khác? Nguyên nhân gây ra các khó khăn, bất cập?</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;\">5. Quý đơn vị vui lòng cung cấp các thông tin của các lĩnh vực nghiệp vụ nội bộ trong bảng sau?</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên nghiệp vụ</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Hiện trạng</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nhu cầu tin học</td>
        </tr>";

        foreach($survey["nghiepvunoibo"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\">STT</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ten_nghiep_vu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["hien_trang"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nhu_cau_tin_hoc"]."</td>
            </tr>";
        }

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;font-weight: bold \">II. KHẢO SÁT VỀ CÁC ỨNG DỤNG CNTT</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">1. Quý đơn vị cung cấp các thông tin dịch vụ trực tuyến đối với sinh viên – học viên thông qua các kênh 
        truy cập hoặc công cụ nào (ví dụ: Cổng thông tin điện tử của trường/Trang thông tin điện tử)? 
        Xin vui lòng cung cấp địa chỉ hoặc đường dẫn.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">2. Quý đơn vị có hệ thống Thư điện tử dùng riêng không? Nếu có, xin vui lòng trả lời thêm một số câu hỏi sau:
Tên phần mềm Thư điện tử đang sử dụng:</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";


        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">- Đơn vị đã có quy chế sử dụng hệ thống thư điện tử chưa?</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";



        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">- Tổng số cán bộ, đã được cấp hộp thư điện tử:</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">- Tỷ lệ cán bộ sử dụng hệ thống thư điện tử:</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";



        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">- Tỷ lệ % văn bản được trao đổi qua hệ thống thư điện tử: …%.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">Ngoài thư điện tử công vụ, Quý đơn vị có sử dụng thư điện tử công cộng (Gmail, Yahoo, Hotmail…) để trao đổi, làm việc không?</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">3. Quý đơn vị vui lòng cung cấp thông tin về các ứng dụng CNTT đã triển khai theo bảng sau.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên phần mềm</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Mô tả chung</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Đối tượng sử dụng</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nhu cầu sửa đổi, nâng cấp</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nguyên nhân</td>
        </tr>";

        foreach($survey["udcnttdatrienkhai"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\"></td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ten_phan_mem"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["mo_ta_chung"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["doituongsudung"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nhucau"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nguyennhan"]."</td>
            </tr>";
        }

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">4. Quý đơn vị vui lòng cung cấp các thông tin về nhu cầu ứng dụng CNTT để xử lý các yêu cầu nghiệp vụ tại Quý đơn vị theo bảng sau theo thứ tự ưu tiên từ trên xuống dưới.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Yêu cầu ứng dụng CNTT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên ứng dụng đề xuất</td>          
        </tr>";

        foreach($survey["udcnttyeucau"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\"></td>
                <td style=\"font-size: 20px;\">".$nghiepvu["yeucau"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["mo_ta_chung"]."</td>                
            </tr>";
        }

        $htmlString .= "<tr>
            <td style=\"font-size: 20px \">5. Quý đơn vị vui lòng cung cấp thông tin về các dự án ứng dụng CNTT đang triển khai (bao gồm cả các dự án đang trong giai đoạn chuẩn bị đầu tư) theo bảng sau? (Bỏ qua nếu không có)</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên dự án</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Mục tiêu tổng quát</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Quy mô</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tổng mức đầu tư</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nội dung thực hiện</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Thời gian thực hiện dự kiến</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Ghi chú</td>
        </tr>";

        foreach($survey["udcnttdangtrienkhai"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\"></td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ten_duan"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["muctieu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["quymo"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["tongmucdautu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["noidung"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ghichu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["thoigianthuchien"]."</td>
            </tr>";
        }

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;font-weight: bold \">III. KHẢO SÁT VỀ CƠ SỞ DỮ LIỆU</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">1. Quý đơn vị vui lòng cung cấp thông tin về các các CSDL đã được triển khai tại Quý đơn vị theo bảng sau.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tên cơ sở dữ liệu</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Hệ quản trị cơ sở dữ liệu</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tình trạng bản quyền</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Năm đầu tư</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Hệ điều hành cài đặt CSDL</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nhu cầu nâng cấp</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">sửa đổi</td>
        </tr>";

        foreach($survey["csdldatrienkhai"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\">STT</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ten_csdl"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["he_csdl"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ban_quyen"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nam_dau_tu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["he_dieu_hanh"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nhucau"]."</td>
            </tr>";
        }

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">2. Quý đơn vị vui lòng cung cấp các thông tin về việc trao đổi, chia sẻ dữ liệu hiện nay theo bảng sau.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">STT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Lĩnh vực nghiệp vụ</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Đơn vị liên quan</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Thông tin, dữ liệu trao đổi</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tần suất trao đổi</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Phương thức trao đổi</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Ghi chú</td>
        </tr>";

        foreach($survey["csdltraodoi"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\">STT</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["linh_vuc"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["don_vi_lien_quan"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["thong_tin_trao_doi"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["tan_suat"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["phuong_thuc"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ghi_chu"]."</td>
            </tr>";
        }

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;font-weight: bold \">IV. HẠ TẦNG KỸ THUẬT CNTT</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";


        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">1. Quý đơn vị đã có Trung tâm dữ liệu hoặc phòng máy chủ chưa?</td>
            <td style=\"font-size: 20px;\">".$survey["phong_may_chu"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Nếu có:
a) Trung tâm dữ liệu hoặc phòng máy chủ đó có môi trường dự phòng không?</td>
            <td style=\"font-size: 20px;\">".$survey["moi_truong_du_phong"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">b) Trung tâm dữ liệu hoặc phòng máy chủ có khả năng mở rộng hoặc lắp đặt các thiết bị mới không?</td>
            <td style=\"font-size: 20px;\">".$survey["may_chu_mo_rong"]."</td>
        </tr>";

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px\">2. Quý đơn vị vui lòng cung cấp các thông tin về các máy chủ vật lý hiện có.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">TT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Model</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Số lượng</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Thông số kỹ thuật</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Năm đầu tư</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Tình trạng</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Ghi chú</td>
        </tr>";

        foreach($survey["maychuvatly"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\"></td>
                <td style=\"font-size: 20px;\">".$nghiepvu["model"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["soluong"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["thong_so"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["nam_dau_tu"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["tinh_trang"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["ghi_chu"]."</td>
            </tr>";
        }

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">3. Quý đơn vị có trang bị hệ thống lưu trữ, sao lưu dữ liệu không?</td>
            <td style=\"font-size: 20px;\">".$survey["may_chu_sao_luu"]."</td>
        </tr>";

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px;font-weight: bold \">V. NGUỒN NHÂN LỰC VÀ NHU CẦU ĐÀO TẠO</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">1. Quý đơn vị vui lòng trả lời các câu hỏi về nguồn nhân lực theo bảng sau.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Đơn vị có bộ phận chuyên trách CNTT không?</td>
            <td style=\"font-size: 20px;\">".$survey["nam_bo_phan_chuyen_trach"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Tổng số cán bộ chuyên trách CNTT (nếu có)</td>
            <td style=\"font-size: 20px;\">".$survey["tong_so_cb_chuyen_trach"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Tổng số cán bộ khác kiêm nhiệm cán bộ CNTT (nếu có)</td>
            <td style=\"font-size: 20px;\">".$survey["tong_so_cb_kiem_nhiem"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Tổng số cán bộ CNTT kiêm nhiệm vị trí khác (nếu có)</td>
            <td style=\"font-size: 20px;\">".$survey["tong_so_cntt_kiem_nhiem"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Thống kê trình độ các cán bộ có bằng cấp trình độ về CNTT?</td>
            <td style=\"font-size: 20px;\">
            Tiến sĩ : ".$survey["tiensi"]." 
            </td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Thống kê trình độ các cán bộ có bằng cấp trình độ về CNTT?</td>
            <td style=\"font-size: 20px;\">          
            Thạc sĩ ".$survey["thacsi"]." 
            </td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Thống kê trình độ các cán bộ có bằng cấp trình độ về CNTT?</td>
            <td style=\"font-size: 20px;\">
            Đại học ".$survey["daihoc"]." 
            </td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Thống kê trình độ các cán bộ có bằng cấp trình độ về CNTT?</td>
            <td style=\"font-size: 20px;\">
            Cao đẳng ".$survey["caodang"]." 
            </td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Thống kê trình độ các cán bộ có bằng cấp trình độ về CNTT?</td>
            <td style=\"font-size: 20px;\">
            Trung cấp ".$survey["trungcap"]." 
            </td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">Các cán bộ hiện đang công tác Quý đơn vị đã sử dụng thành thạo các phần mềm văn phòng, hệ thống ứng dụng CNTT, 
        CSDL chuyên ngành để xử lý công việc không?</td>
            <td style=\"font-size: 20px;\">".$survey["su_dung_pm_van_phong"]."</td>
        </tr>";

        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">2. Quý đơn vị vui lòng cung cấp thông tin về nhu cầu đào tạo theo bảng sau.</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr></tr>";

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">TT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nội dung đào tạo</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Số lượng học viên dự kiến</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Mức độ ưu tiên</td>
        </tr>";

        foreach($survey["v_nhu_cau_dao_tao"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\"></td>
                <td style=\"font-size: 20px;\">".$nghiepvu["noidung_daotao"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["soluong_hocvien"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["muc_do_uu_tien"]."</td>
            </tr>";
        }

        $htmlString .= "<tr>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">TT</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Nội dung đào tạo</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Số lượng học viên dự kiến</td>
            <td style=\"width: 30px;font-size: 20px;font-weight: bold \">Mức độ ưu tiên</td>
        </tr>";

        foreach($survey["v_nhu_cau_dao_tao_ext"] as $nghiepvu) {
            $htmlString .= "<tr>
                <td style=\"font-size: 20px;\"></td>
                <td style=\"font-size: 20px;\">".$nghiepvu["noidung_daotao"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["soluong_hocvien"]."</td>
                <td style=\"font-size: 20px;\">".$nghiepvu["muc_do_uu_tien"]."</td>
            </tr>";
        }

        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";
        $htmlString .= "<tr></tr>";



        $htmlString .= "<tr>
            <td style=\"font-size: 20px;font-weight: bold \">VI. CÁC Ý KIẾN, KIẾN NGHỊ VÀ ĐỀ XUẤT</td>
            <td style=\"font-size: 20px;\"></td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">1. Khó khăn, vướng mắc</td>
            <td style=\"font-size: 20px;\">".$survey["ykien_khokhan"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">2. Các thuận lợi</td>
            <td style=\"font-size: 20px;\">".$survey["ykien_thuanloi"]."</td>
        </tr>";

        $htmlString .= "<tr>
            <td style=\"font-size: 20px; \">3. Các đề xuất, kiến nghị và ý kiến khác (nếu có)</td>
            <td style=\"font-size: 20px;\">".$survey["ykien_dexuat"]."</td>
        </tr>";
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Html();
        $spreadsheet = $reader->loadFromString($htmlString);

        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
        $name = "KS".$survey["id"].'.xlsx';
        $writer->save($name);


       /* $spreadsheet = new Spreadsheet();

        $spreadsheet->setActiveSheetIndex(0);
        $spreadsheet->getActiveSheet()->getCell('A1')->setValue("
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry. 
        is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.");
        $spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setWrapText(true);

        $writer = new Xlsx($spreadsheet);
        $writer->save($name);*/
        header("Location: " . BASE_URL.$name); exit;
    }


    public function resetpassword() {
        $model = new SurveyModel();
        $id = (int)$_GET["id"];
        $survey = $model->getSingle($id);

        if (isset($_POST["password"]) && $_POST["password"]) {
            $newpassword = trim($_POST["password"]);
            $newpassword = md5($newpassword);
            $model->changePassword($newpassword, $id);

            header("Location: " . BASE_URL."index.php?controller=besurvey");
            exit;
        }

        include_once "mvc/view/besurvey/resetpassword.php";
    }

    public function downloadFile() {
        $model = new SurveyModel();
        $id = (int)$_GET["id"];
        $survey = $model->getSingle($id);

        if (isset($survey["danh_sach_chuc_nang_nghiep_vu_file"]) && ($survey["danh_sach_chuc_nang_nghiep_vu_file"])) {
            header("Location: " . BASE_URL.$survey["danh_sach_chuc_nang_nghiep_vu_file"]);
            exit;
        }

        header("Location: " . BASE_URL."index.php?controller=besurvey"); exit;
    }


    public function edit() {

        $model = new SurveyModel();
        $id = (int)$_GET["id"];
        $survey = $model->getSingle($id);
        $danh_sach_truong_dh_const = [
            "1" => "Học viện Âm nhạc quốc gia Việt Nam",
            "2" => "Nhạc viện Thành phố Hồ Chí Minh",
            "3" => "Học viện Âm nhạc Huế",
            "4" => "Trường Đại học Văn hóa Hà Nội",
            "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
            "6" => "Trường Đại học Mỹ thuật Việt Nam",
            "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
            "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
            "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
            "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
            "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
            "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
            "13" => "Học viện Múa Việt Nam",
            "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
            "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
            "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
            "17" => "Trường Cao đẳng Du lịch Hà Nội",
            "18" => "Trường Cao đẳng Du lịch Hải Phòng",
            "19" => "Trường Cao đẳng Du lịch Huế",
            "20" => "Trường Cao đẳng Du lịch Nha Trang",
            "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
            "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
            "23" => "Trường Cao đẳng Du lịch Đà Lạt",
            "24" => "Trường Cao đẳng Du lịch Cần Thơ",
            "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
            "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
        ];
        $nghiepvusDefault = [
            "Quản lý hành chính điện tử - các hệ thống báo cáo số liệu",
            "Quản lý Tuyển sinh",
            "Quản lý Thời khóa biểu – kế hoạch giảng dạy",
            "Quản lý Công tác Sinh viên",
            "Quản lý học vụ",
            "Quản lý khảo thí – Trác nghiệm",
            "Quản lý Tài chính ",
            "Quản lý Lý túc xá",
            "Quản lý Nhân sự thỉnh giảng – Tiền Công",
            "Quản lý Tài sản – Thiết bị",
            "Quản lý nghiên cứu khoa học",
            "kết nối cộng đồng phụ huynh- sinh viên – nhà trường",
            "Hóa đơn điện tử",
            "Quản lý chuyển phát, điều hành xe"
        ];

        include_once "mvc/view/besurvey/edit.php";
    }

    public function update() {

        $model = new SurveyModel();
        $lastId = $id = (int)$_GET["id"];

        if ($lastId > 0) {
            $currentSurvey = $model->getSurveyById($lastId);
            $single = $model->getSingle($lastId);
            $logs = [
                "main" => $currentSurvey,
                "user_id_answer" => $lastId,
                "nghiepvu" => $single["nghiepvu"],
                "nghiepvulienthong" => $single["nghiepvulienthong"],
                "nghiepvunoibo" => $single["nghiepvunoibo"],
                "maychuvatly" => $single["maychuvatly"],
                "csdl" => $single["csdldatrienkhai"],
                "csdltraodoi" => $single["csdltraodoi"],
                "nhucaudaotao" => $single["v_nhu_cau_dao_tao"],
                "nhucaudaotaoext" => $single["v_nhu_cau_dao_tao_ext"],
                "udpmdatrienkhai" => $single["udcnttdatrienkhai"],
                "udpmnhucau" => $single["udcnttyeucau"],
                "udpmdangtrienkhai" => $single["udcnttdangtrienkhai"],
            ];
            $model->insertLogs($logs);

            if (isset($currentSurvey["id"]) && ($currentSurvey["id"] > 0)) {
                $dataNew = $_POST;

                $dataNew["matkhau"] = $currentSurvey["matkhau"];
                $dataNew["email"] = $currentSurvey["email"];

                if (isset($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']) && !empty($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name'])) {

                    $uploadF = $this->uploadFile();
                    if ($uploadF != false) {
                        $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = strval($uploadF);
                    } else {
                        $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                    }
                } else {
                    $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                }

                $model->updateSurvey($dataNew, $lastId);
            }


            $model->deleteRel($lastId);

            $idx_nghiepvu = 0;

            foreach ($_POST["nghiepvu"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvu"]["ten_nghiep_vu"][$idx_nghiepvu];
                $data['hien_trang'] = $_POST["nghiepvu"]["hien_trang"][$idx_nghiepvu];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvu"]["nhu_cau_tin_hoc"][$idx_nghiepvu];
                $model->updateNghiepVu($data);
                $idx_nghiepvu++;
            }

            $idx_nghiepvulienthong = 0;
            foreach ($_POST["nghiepvulienthong"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvulienthong"]["ten_nghiep_vu"][$idx_nghiepvulienthong];
                $data['coquan'] = $_POST["nghiepvulienthong"]["coquan"][$idx_nghiepvulienthong];
                $data['hien_trang'] = $_POST["nghiepvulienthong"]["hien_trang"][$idx_nghiepvulienthong];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvulienthong"]["nhu_cau_tin_hoc"][$idx_nghiepvulienthong];
                $model->updateNghiepVuLienThong($data);
                $idx_nghiepvulienthong++;
            }

            $idx_nghiepvunoibo = 0;
            foreach ($_POST["nghiepvunoibo"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvunoibo"]["ten_nghiep_vu"][$idx_nghiepvunoibo];
                $data['hien_trang'] = $_POST["nghiepvunoibo"]["hien_trang"][$idx_nghiepvunoibo];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvunoibo"]["nhu_cau_tin_hoc"][$idx_nghiepvunoibo];
                $model->updateNghiepVuNoiBo($data);
                $idx_nghiepvunoibo++;
            }



            $idx_udcnttdatrienkhai = 0;
            foreach ($_POST["udcnttdatrienkhai"]["ten_phan_mem"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_phan_mem'] = $_POST["udcnttdatrienkhai"]["ten_phan_mem"][$idx_udcnttdatrienkhai];
                $data['mo_ta_chung'] = $_POST["udcnttdatrienkhai"]["mo_ta_chung"][$idx_udcnttdatrienkhai];
                $data['doituongsudung'] = $_POST["udcnttdatrienkhai"]["doituongsudung"][$idx_udcnttdatrienkhai];
                $data['nhucau'] = $_POST["udcnttdatrienkhai"]["nhucau"][$idx_udcnttdatrienkhai];
                $data['nguyennhan'] = $_POST["udcnttdatrienkhai"]["nguyennhan"][$idx_udcnttdatrienkhai];
                $model->updateUDCNTTDaTrienKhai($data);
                $idx_udcnttdatrienkhai++;
            }

            $idx_udcnttyeucau = 0;
            foreach ($_POST["udcnttyeucau"]["yeucau"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['yeucau'] = $_POST["udcnttyeucau"]["yeucau"][$idx_udcnttyeucau];
                $data['ungdungdexuat'] = $_POST["udcnttyeucau"]["ungdungdexuat"][$idx_udcnttyeucau];
                $model->updateUDCNTTNhuCau($data);
                $idx_udcnttyeucau++;
            }

            $idx_udcnttdangtrienkhai = 0;
            foreach ($_POST["udcnttdangtrienkhai"]["ten_duan"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_duan'] = $_POST["udcnttdangtrienkhai"]["ten_duan"][$idx_udcnttdangtrienkhai];
                $data['muctieu'] = $_POST["udcnttdangtrienkhai"]["muctieu"][$idx_udcnttdangtrienkhai];
                $data['quymo'] = $_POST["udcnttdangtrienkhai"]["quymo"][$idx_udcnttdangtrienkhai];
                $data['tongmucdautu'] = $_POST["udcnttdangtrienkhai"]["tongmucdautu"][$idx_udcnttdangtrienkhai];
                $data['noidung'] = $_POST["udcnttdangtrienkhai"]["noidung"][$idx_udcnttdangtrienkhai];
                $data['thoigianthuchien'] = $_POST["udcnttdangtrienkhai"]["thoigianthuchien"][$idx_udcnttdangtrienkhai];
                $data['ghichu'] = $_POST["udcnttdangtrienkhai"]["ghichu"][$idx_udcnttdangtrienkhai];
                $model->updateUDCNTTDangTrienKhai($data);
                $idx_udcnttdangtrienkhai++;
            }

            $idx_maychuvatly = 0;
            foreach ($_POST["maychuvatly"]["model"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['model'] = $_POST["maychuvatly"]["model"][$idx_maychuvatly];
                $data['soluong'] = $_POST["maychuvatly"]["soluong"][$idx_maychuvatly];
                $data['thong_so'] = $_POST["maychuvatly"]["thong_so"][$idx_maychuvatly];
                $data['nam_dau_tu'] = $_POST["maychuvatly"]["nam_dau_tu"][$idx_maychuvatly];
                $data['tinh_trang'] = $_POST["maychuvatly"]["tinh_trang"][$idx_maychuvatly];
                $data['ghi_chu'] = $_POST["maychuvatly"]["ghi_chu"][$idx_maychuvatly];
                $model->updateMayChuVatLy($data);
                $idx_maychuvatly++;
            }





            $idx_csdldatrienkhai = 0;
            foreach ($_POST["csdldatrienkhai"]["ten_csdl"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_csdl'] = $_POST["csdldatrienkhai"]["ten_csdl"][$idx_csdldatrienkhai];
                $data['he_csdl'] = $_POST["csdldatrienkhai"]["he_csdl"][$idx_csdldatrienkhai];
                $data['ban_quyen'] = $_POST["csdldatrienkhai"]["ban_quyen"][$idx_csdldatrienkhai];
                $data['nam_dau_tu'] = $_POST["csdldatrienkhai"]["nam_dau_tu"][$idx_csdldatrienkhai];
                $data['he_dieu_hanh'] = $_POST["csdldatrienkhai"]["he_dieu_hanh"][$idx_csdldatrienkhai];
                $data['nhucau'] = $_POST["csdldatrienkhai"]["nhucau"][$idx_csdldatrienkhai];
                $model->updateCSDLDaTrienKhai($data);
                $idx_csdldatrienkhai++;
            }



            $idx_csdltraodoi = 0;
            foreach ($_POST["csdltraodoi"]["linh_vuc"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['linh_vuc'] = $_POST["csdltraodoi"]["linh_vuc"][$idx_csdltraodoi];
                $data['don_vi_lien_quan'] = $_POST["csdltraodoi"]["don_vi_lien_quan"][$idx_csdltraodoi];
                $data['thong_tin_trao_doi'] = $_POST["csdltraodoi"]["thong_tin_trao_doi"][$idx_csdltraodoi];
                $data['tan_suat'] = $_POST["csdltraodoi"]["tan_suat"][$idx_csdltraodoi];
                $data['phuong_thuc'] = $_POST["csdltraodoi"]["phuong_thuc"][$idx_csdltraodoi];
                $data['ghi_chu'] = $_POST["csdltraodoi"]["ghi_chu"][$idx_csdltraodoi];
                $model->updateCSDLTraoDoi($data);
                $idx_csdltraodoi++;
            }



            $idx_nhucaudaotao = 0;
            foreach ($_POST["nhucaudaotao"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao"]["noidung_daotao"][$idx_nhucaudaotao];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao"]["soluong_hocvien"][$idx_nhucaudaotao];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao"]["muc_do_uu_tien"][$idx_nhucaudaotao];

                $model->updateNhuCauDaoTao($data);
                $idx_nhucaudaotao++;
            }


            $idx_nhucaudaotao_ext = 0;
            foreach ($_POST["nhucaudaotao_ext"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao_ext"]["noidung_daotao"][$idx_nhucaudaotao_ext];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao_ext"]["soluong_hocvien"][$idx_nhucaudaotao_ext];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao_ext"]["muc_do_uu_tien"][$idx_nhucaudaotao_ext];

                $model->updateNhuCauDaoTaoExt($data);
                $idx_nhucaudaotao_ext++;
            }

        header("Location: index.php?controller=besurvey&action=edit&id=".$id);
        exit;
    }
    }

    public function store() {

        $model = new SurveyModel();

        $lastId = (int) $model->insertSurvey($_POST);

        $currentSurvey = $model->getSurveyById($lastId);

        if (isset($currentSurvey["id"]) && ($currentSurvey["id"] > 0)) {
            $dataNew = $_POST;

            $dataNew["matkhau"] = $currentSurvey["matkhau"];
            $dataNew["email"] = $currentSurvey["email"];

            if (isset($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']) && !empty($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name'])) {

                $uploadF = $this->uploadFile();
                if ($uploadF != false) {
                    $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = strval($uploadF);
                } else {
                    $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                }
            } else {
                $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
            }

            $model->updateSurvey($dataNew, $lastId);
        }

        if ($lastId > 0) {
            $idx_nghiepvu = 0;
            foreach ($_POST["nghiepvu"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvu"]["ten_nghiep_vu"][$idx_nghiepvu];
                $data['hien_trang'] = $_POST["nghiepvu"]["hien_trang"][$idx_nghiepvu];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvu"]["nhu_cau_tin_hoc"][$idx_nghiepvu];
                $model->updateNghiepVu($data);
                $idx_nghiepvu++;
            }

            $idx_nghiepvulienthong = 0;
            foreach ($_POST["nghiepvulienthong"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvulienthong"]["ten_nghiep_vu"][$idx_nghiepvulienthong];
                $data['coquan'] = $_POST["nghiepvulienthong"]["coquan"][$idx_nghiepvulienthong];
                $data['hien_trang'] = $_POST["nghiepvulienthong"]["hien_trang"][$idx_nghiepvulienthong];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvulienthong"]["nhu_cau_tin_hoc"][$idx_nghiepvulienthong];
                $model->updateNghiepVuLienThong($data);
                $idx_nghiepvulienthong++;
            }

            $idx_nghiepvunoibo = 0;
            foreach ($_POST["nghiepvunoibo"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvunoibo"]["ten_nghiep_vu"][$idx_nghiepvunoibo];
                $data['hien_trang'] = $_POST["nghiepvunoibo"]["hien_trang"][$idx_nghiepvunoibo];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvunoibo"]["nhu_cau_tin_hoc"][$idx_nghiepvunoibo];
                $model->updateNghiepVuNoiBo($data);
                $idx_nghiepvunoibo++;
            }



            $idx_udcnttdatrienkhai = 0;
            foreach ($_POST["udcnttdatrienkhai"]["ten_phan_mem"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_phan_mem'] = $_POST["udcnttdatrienkhai"]["ten_phan_mem"][$idx_udcnttdatrienkhai];
                $data['mo_ta_chung'] = $_POST["udcnttdatrienkhai"]["mo_ta_chung"][$idx_udcnttdatrienkhai];
                $data['doituongsudung'] = $_POST["udcnttdatrienkhai"]["doituongsudung"][$idx_udcnttdatrienkhai];
                $data['nhucau'] = $_POST["udcnttdatrienkhai"]["nhucau"][$idx_udcnttdatrienkhai];
                $data['nguyennhan'] = $_POST["udcnttdatrienkhai"]["nguyennhan"][$idx_udcnttdatrienkhai];
                $model->updateUDCNTTDaTrienKhai($data);
                $idx_udcnttdatrienkhai++;
            }

            $idx_udcnttyeucau = 0;
            foreach ($_POST["udcnttyeucau"]["yeucau"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['yeucau'] = $_POST["udcnttyeucau"]["yeucau"][$idx_udcnttyeucau];
                $data['ungdungdexuat'] = $_POST["udcnttyeucau"]["ungdungdexuat"][$idx_udcnttyeucau];
                $model->updateUDCNTTNhuCau($data);
                $idx_udcnttyeucau++;
            }

            $idx_udcnttdangtrienkhai = 0;
            foreach ($_POST["udcnttdangtrienkhai"]["ten_duan"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_duan'] = $_POST["udcnttdangtrienkhai"]["ten_duan"][$idx_udcnttdangtrienkhai];
                $data['muctieu'] = $_POST["udcnttdangtrienkhai"]["muctieu"][$idx_udcnttdangtrienkhai];
                $data['quymo'] = $_POST["udcnttdangtrienkhai"]["quymo"][$idx_udcnttdangtrienkhai];
                $data['tongmucdautu'] = $_POST["udcnttdangtrienkhai"]["tongmucdautu"][$idx_udcnttdangtrienkhai];
                $data['noidung'] = $_POST["udcnttdangtrienkhai"]["noidung"][$idx_udcnttdangtrienkhai];
                $data['thoigianthuchien'] = $_POST["udcnttdangtrienkhai"]["thoigianthuchien"][$idx_udcnttdangtrienkhai];
                $data['ghichu'] = $_POST["udcnttdangtrienkhai"]["ghichu"][$idx_udcnttdangtrienkhai];
                $model->updateUDCNTTDangTrienKhai($data);
                $idx_udcnttdangtrienkhai++;
            }

            $idx_maychuvatly = 0;
            foreach ($_POST["maychuvatly"]["model"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['model'] = $_POST["maychuvatly"]["model"][$idx_maychuvatly];
                $data['soluong'] = $_POST["maychuvatly"]["soluong"][$idx_maychuvatly];
                $data['thong_so'] = $_POST["maychuvatly"]["thong_so"][$idx_maychuvatly];
                $data['nam_dau_tu'] = $_POST["maychuvatly"]["nam_dau_tu"][$idx_maychuvatly];
                $data['tinh_trang'] = $_POST["maychuvatly"]["tinh_trang"][$idx_maychuvatly];
                $data['ghi_chu'] = $_POST["maychuvatly"]["ghi_chu"][$idx_maychuvatly];
                $model->updateMayChuVatLy($data);
                $idx_maychuvatly++;
            }





            $idx_csdldatrienkhai = 0;
            foreach ($_POST["csdldatrienkhai"]["ten_csdl"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_csdl'] = $_POST["csdldatrienkhai"]["ten_csdl"][$idx_csdldatrienkhai];
                $data['he_csdl'] = $_POST["csdldatrienkhai"]["he_csdl"][$idx_csdldatrienkhai];
                $data['ban_quyen'] = $_POST["csdldatrienkhai"]["ban_quyen"][$idx_csdldatrienkhai];
                $data['nam_dau_tu'] = $_POST["csdldatrienkhai"]["nam_dau_tu"][$idx_csdldatrienkhai];
                $data['he_dieu_hanh'] = $_POST["csdldatrienkhai"]["he_dieu_hanh"][$idx_csdldatrienkhai];
                $data['nhucau'] = $_POST["csdldatrienkhai"]["nhucau"][$idx_csdldatrienkhai];
                $model->updateCSDLDaTrienKhai($data);
                $idx_csdldatrienkhai++;
            }



            $idx_csdltraodoi = 0;
            foreach ($_POST["csdltraodoi"]["linh_vuc"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['linh_vuc'] = $_POST["csdltraodoi"]["linh_vuc"][$idx_csdltraodoi];
                $data['don_vi_lien_quan'] = $_POST["csdltraodoi"]["don_vi_lien_quan"][$idx_csdltraodoi];
                $data['thong_tin_trao_doi'] = $_POST["csdltraodoi"]["thong_tin_trao_doi"][$idx_csdltraodoi];
                $data['tan_suat'] = $_POST["csdltraodoi"]["tan_suat"][$idx_csdltraodoi];
                $data['phuong_thuc'] = $_POST["csdltraodoi"]["phuong_thuc"][$idx_csdltraodoi];
                $data['ghi_chu'] = $_POST["csdltraodoi"]["ghi_chu"][$idx_csdltraodoi];
                $model->updateCSDLTraoDoi($data);
                $idx_csdltraodoi++;
            }



            $idx_nhucaudaotao = 0;
            foreach ($_POST["nhucaudaotao"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao"]["noidung_daotao"][$idx_nhucaudaotao];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao"]["soluong_hocvien"][$idx_nhucaudaotao];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao"]["muc_do_uu_tien"][$idx_nhucaudaotao];

                $model->updateNhuCauDaoTao($data);
                $idx_nhucaudaotao++;
            }

            $idx_nhucaudaotao_ext = 0;
            foreach ($_POST["nhucaudaotao_ext"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao_ext"]["noidung_daotao"][$idx_nhucaudaotao_ext];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao_ext"]["soluong_hocvien"][$idx_nhucaudaotao_ext];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao_ext"]["muc_do_uu_tien"][$idx_nhucaudaotao_ext];

                $model->updateNhuCauDaoTaoExt($data);
                $idx_nhucaudaotao_ext++;
            }

            /**
             *
             *
             nghiepvu_survey
             nghiepvu_lienthong_survey
            nghiepvu_noibo_survey
            * maychuvatly
            * csdl_datrienkhai
            * csdl_traodoi
            ungdungcntt_datrienkhai
            ungdungcntt_dangtrienkhai
            ungdungcntt_yeucau
            * v_nhu_cau_dao_tao
             */

        }

        header("Location: index.php?controller=besurvey&action=index");
        exit;
    }

    public function detail() {



    }


    public function delete() {

    }

    public function add() {
        $danh_sach_truong_dh_const = [
            "1" => "Học viện Âm nhạc quốc gia Việt Nam",
            "2" => "Nhạc viện Thành phố Hồ Chí Minh",
            "3" => "Học viện Âm nhạc Huế",
            "4" => "Trường Đại học Văn hóa Hà Nội",
            "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
            "6" => "Trường Đại học Mỹ thuật Việt Nam",
            "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
            "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
            "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
            "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
            "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
            "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
            "13" => "Học viện Múa Việt Nam",
            "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
            "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
            "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
            "17" => "Trường Cao đẳng Du lịch Hà Nội",
            "18" => "Trường Cao đẳng Du lịch Hải Phòng",
            "19" => "Trường Cao đẳng Du lịch Huế",
            "20" => "Trường Cao đẳng Du lịch Nha Trang",
            "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
            "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
            "23" => "Trường Cao đẳng Du lịch Đà Lạt",
            "24" => "Trường Cao đẳng Du lịch Cần Thơ",
            "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
            "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
        ];
        $nghiepvusDefault = [
            "Quản lý hành chính điện tử - các hệ thống báo cáo số liệu",
            "Quản lý Tuyển sinh",
            "Quản lý Thời khóa biểu – kế hoạch giảng dạy",
            "Quản lý Công tác Sinh viên",
            "Quản lý học vụ",
            "Quản lý khảo thí – Trác nghiệm",
            "Quản lý Tài chính ",
            "Quản lý Lý túc xá",
            "Quản lý Nhân sự thỉnh giảng – Tiền Công",
            "Quản lý Tài sản – Thiết bị",
            "Quản lý nghiên cứu khoa học",
            "kết nối cộng đồng phụ huynh- sinh viên – nhà trường",
            "Hóa đơn điện tử",
            "Quản lý chuyển phát, điều hành xe"
        ];

        include_once "mvc/view/besurvey/add.php";
    }


}