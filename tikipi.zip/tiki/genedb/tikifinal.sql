/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : tiki1

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-03-22 21:38:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('2', 'admin@gmail.com', 'ce3ac1807677ee36943b210356f517f9');

-- ----------------------------
-- Table structure for csdl_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `csdl_datrienkhai`;
CREATE TABLE `csdl_datrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_csdl` text DEFAULT NULL,
  `he_csdl` text DEFAULT NULL,
  `ban_quyen` text DEFAULT NULL,
  `nam_dau_tu` text DEFAULT NULL,
  `he_dieu_hanh` text DEFAULT NULL,
  `nhucau` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of csdl_datrienkhai
-- ----------------------------
INSERT INTO `csdl_datrienkhai` VALUES ('1', null, null, null, '', '', '', '1');
INSERT INTO `csdl_datrienkhai` VALUES ('2', null, null, null, '', '', '', '7');
INSERT INTO `csdl_datrienkhai` VALUES ('4', null, null, null, '', '', '', '9');
INSERT INTO `csdl_datrienkhai` VALUES ('5', '', '', '', '', '', '', '10');
INSERT INTO `csdl_datrienkhai` VALUES ('6', '', '', '', '', '', '', '8');
INSERT INTO `csdl_datrienkhai` VALUES ('7', '', '', '', '', '', '', '11');
INSERT INTO `csdl_datrienkhai` VALUES ('8', '', '', '', '', '', '', '12');
INSERT INTO `csdl_datrienkhai` VALUES ('13', 'csdldatrienkhai[ten_csdl][]', 'csdldatrienkhai[he_csdl][]', 'csdldatrienkhai[ban_quyen][]', 'csdldatrienkhai[nam_dau_tu][]', 'csdldatrienkhai[he_dieu_hanh][]', 'csdldatrienkhai[nhucau][]', '16');
INSERT INTO `csdl_datrienkhai` VALUES ('14', 'csdldatrienkhai[ten_csdl][]', 'csdldatrienkhai[he_csdl][]', 'csdldatrienkhai[ban_quyen][]', 'csdldatrienkhai[nam_dau_tu][]', 'csdldatrienkhai[he_dieu_hanh][]', 'csdldatrienkhai[nhucau][]', '16');
INSERT INTO `csdl_datrienkhai` VALUES ('15', 'Laboris qui et volup', 'Non quia iure odio m', 'Cum do aliquam ex co', 'Ad excepturi proiden', 'Amet provident del', 'Molestias soluta tem', '21');
INSERT INTO `csdl_datrienkhai` VALUES ('16', 'Harum ipsam similiqu', 'Hic itaque laborum o', 'Velit nulla lorem en', 'Voluptate irure expe', 'Voluptatum ea volupt', 'In at ut eveniet re', '24');
INSERT INTO `csdl_datrienkhai` VALUES ('17', 'Dolorem ipsam praese', 'Et omnis harum omnis', 'Vel sit reprehender', 'Incidunt nesciunt ', 'Et perferendis cillu', 'Ex iure dicta sed ra', '24');
INSERT INTO `csdl_datrienkhai` VALUES ('18', 'Necessitatibus enim ', 'Illum blanditiis do', 'Itaque et cumque eu ', 'Esse quos provident', 'Culpa adipisicing no', 'Rem quia rerum cupid', '24');
INSERT INTO `csdl_datrienkhai` VALUES ('19', 'Id aut exercitation ', 'Deserunt optio dolo', 'Et ipsum cumque alia', 'Cupiditate quos magn', 'Fugiat non nisi quo ', 'Fuga Quo adipisci v', '27');
INSERT INTO `csdl_datrienkhai` VALUES ('21', 'Id velit dolore quia', 'Sed qui est commodo', 'Consectetur et fuga', 'Cillum magni deserun', 'Vitae nulla pariatur', 'Minima autem pariatu', '28');

-- ----------------------------
-- Table structure for csdl_traodoi
-- ----------------------------
DROP TABLE IF EXISTS `csdl_traodoi`;
CREATE TABLE `csdl_traodoi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `linh_vuc` text DEFAULT NULL,
  `don_vi_lien_quan` text DEFAULT NULL,
  `thong_tin_trao_doi` text DEFAULT NULL,
  `tan_suat` text DEFAULT NULL,
  `phuong_thuc` text DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of csdl_traodoi
-- ----------------------------
INSERT INTO `csdl_traodoi` VALUES ('1', '1', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('2', '7', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('4', '9', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('5', '10', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('6', '8', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('7', '11', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('8', '12', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('13', '16', 'csdltraodoi[linh_vuc][]', 'csdltraodoi[don_vi_lien_quan][]', 'csdltraodoi[thong_tin_trao_doi][]', 'csdltraodoi[tan_suat][]', 'csdltraodoi[ghi_chu][]', 'csdltraodoi[ghi_chu][]');
INSERT INTO `csdl_traodoi` VALUES ('14', '16', 'csdltraodoi[linh_vuc][]', 'csdltraodoi[don_vi_lien_quan][]', 'csdltraodoi[thong_tin_trao_doi][]', 'csdltraodoi[tan_suat][]', 'csdltraodoi[ghi_chu][]', 'csdltraodoi[ghi_chu][]');
INSERT INTO `csdl_traodoi` VALUES ('15', '21', 'Asperiores voluptati', 'Proident consequatu', 'Voluptatum voluptas ', 'Consequuntur aut por', 'Sed ea dolorem ullam', 'Sed ea dolorem ullam');
INSERT INTO `csdl_traodoi` VALUES ('16', '24', 'Dolorem at ullam ex ', 'Eveniet libero ulla', 'Aut neque quo eu eli', 'Dolore animi eius e', 'Quibusdam quis tempo', 'Quibusdam quis tempo');
INSERT INTO `csdl_traodoi` VALUES ('17', '24', 'Doloremque voluptatu', 'Molestiae porro illo', 'Quia eius possimus ', 'Quidem qui quam dolo', 'Voluptas facere ea c', 'Voluptas facere ea c');
INSERT INTO `csdl_traodoi` VALUES ('18', '24', 'Lorem molestiae maxi', 'Architecto cupidatat', 'Lorem rerum non ex d', 'Suscipit esse volup', 'Distinctio Voluptat', 'Distinctio Voluptat');
INSERT INTO `csdl_traodoi` VALUES ('19', '27', 'Magna distinctio Cu', 'Excepturi et et dolo', 'Ad voluptatum cupidi', 'Amet ea quas dolore', 'Sunt libero non nis', 'Sunt libero non nis');
INSERT INTO `csdl_traodoi` VALUES ('21', '28', 'In sit obcaecati occ', 'Commodi voluptas fug', 'Ut dolor excepteur n', 'Voluptatibus tenetur', 'Repellendus Sed ut ', 'Repellendus Sed ut ');

-- ----------------------------
-- Table structure for logs
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `main` text DEFAULT NULL,
  `nghiepvu` text DEFAULT NULL,
  `nghiepvulienthong` text DEFAULT NULL,
  `nghiepvunoibo` text DEFAULT NULL,
  `maychuvatly` text DEFAULT NULL,
  `csdl` text DEFAULT NULL,
  `csdltraodoi` text DEFAULT NULL,
  `nhucaudaotao` text DEFAULT NULL,
  `nhucaudaotaoext` text DEFAULT NULL,
  `udpmdatrienkhai` text DEFAULT NULL,
  `udpmnhucau` text DEFAULT NULL,
  `udpmdangtrienkhai` text DEFAULT NULL,
  `thoigian` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of logs
-- ----------------------------
INSERT INTO `logs` VALUES ('1', '1', null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `logs` VALUES ('2', '1', null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `logs` VALUES ('3', '1', null, null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for maychuvatly
-- ----------------------------
DROP TABLE IF EXISTS `maychuvatly`;
CREATE TABLE `maychuvatly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `model` text DEFAULT NULL,
  `soluong` text DEFAULT NULL,
  `thong_so` text DEFAULT NULL,
  `nam_dau_tu` text DEFAULT NULL,
  `tinh_trang` text DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of maychuvatly
-- ----------------------------
INSERT INTO `maychuvatly` VALUES ('1', '1', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('2', '7', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('4', '9', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('5', '10', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('6', '8', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('7', '11', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('8', '12', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('13', '16', 'maychuvatly[model][]', 'maychuvatly[soluong][]', 'maychuvatly[thong_so][]', 'maychuvatly[nam_dau_tu][]', 'maychuvatly[tinh_trang][]', 'maychuvatly[ghi_chu][]');
INSERT INTO `maychuvatly` VALUES ('14', '16', 'maychuvatly[model][]', 'maychuvatly[soluong][]', 'maychuvatly[thong_so][]', 'maychuvatly[nam_dau_tu][]', 'maychuvatly[tinh_trang][]', 'maychuvatly[ghi_chu][]');
INSERT INTO `maychuvatly` VALUES ('15', '21', 'Quis rem totam repel', 'Omnis quos voluptas ', 'Eos perspiciatis d', 'Neque labore sit vol', 'Amet odit ex sed an', 'Autem eveniet amet');
INSERT INTO `maychuvatly` VALUES ('16', '24', 'Molestiae consequat', 'Et mollit quia rerum', 'Facere fuga Eos lo', 'Nobis minim sit elit', 'Quaerat aliquam qui ', 'Sapiente ea cumque n');
INSERT INTO `maychuvatly` VALUES ('17', '27', 'Fugiat neque fuga ', 'Corporis quidem cupi', 'Nostrum voluptas et ', 'Eum itaque adipisci ', 'Voluptatem quidem al', 'Rerum id esse a ut ');
INSERT INTO `maychuvatly` VALUES ('19', '28', 'Illo quia velit dol', 'Magni veritatis dolo', 'Quia aliquip ipsum ', 'Voluptatem Aut quis', 'Sed eius aperiam dol', 'Quisquam deleniti vo');

-- ----------------------------
-- Table structure for nghiepvu_lienthong_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_lienthong_survey`;
CREATE TABLE `nghiepvu_lienthong_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text DEFAULT NULL,
  `nhu_cau_tin_hoc` text DEFAULT NULL,
  `coquan` text DEFAULT NULL,
  `ten_nghiep_vu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_lienthong_survey
-- ----------------------------
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('1', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('2', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('3', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('4', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('5', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('6', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('7', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('8', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('9', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('10', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('11', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('12', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('13', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('14', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('15', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('16', '2', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('17', '2', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('18', '2', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('19', '2', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('20', '2', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('21', '2', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('22', '2', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('23', '2', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('24', '2', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('25', '2', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('26', '2', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('27', '2', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('28', '2', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('29', '2', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('30', '2', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('31', '3', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('32', '3', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('33', '3', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('34', '3', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('35', '3', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('36', '3', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('37', '3', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('38', '3', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('39', '3', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('40', '3', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('41', '3', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('42', '3', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('43', '3', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('44', '3', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('45', '3', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('46', '4', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('47', '4', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('48', '4', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('49', '4', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('50', '4', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('51', '4', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('52', '4', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('53', '4', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('54', '4', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('55', '4', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('56', '4', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('57', '4', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('58', '4', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('59', '4', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('60', '4', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('61', '5', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('62', '5', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('63', '5', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('64', '5', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('65', '5', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('66', '5', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('67', '5', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('68', '5', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('69', '5', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('70', '5', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('71', '5', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('72', '5', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('73', '5', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('74', '5', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('75', '5', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('76', '6', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('77', '6', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('78', '6', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('79', '6', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('80', '6', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('81', '6', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('82', '6', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('83', '6', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('84', '6', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('85', '6', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('86', '6', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('87', '6', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('88', '6', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('89', '6', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('90', '6', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('91', '7', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('92', '7', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('93', '7', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('94', '7', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('95', '7', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('96', '7', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('97', '7', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('98', '7', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('99', '7', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('100', '7', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('101', '7', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('102', '7', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('103', '7', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('104', '7', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('105', '7', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('121', '9', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('122', '9', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('123', '9', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('124', '9', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('125', '9', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('126', '9', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('127', '9', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('128', '9', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('129', '9', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('130', '9', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('131', '9', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('132', '9', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('133', '9', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('134', '9', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('135', '9', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('136', '10', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('137', '10', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('138', '10', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('139', '10', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('140', '10', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('141', '10', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('142', '10', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('143', '10', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('144', '10', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('145', '10', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('146', '10', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('147', '10', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('148', '10', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('149', '10', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('150', '10', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('151', '8', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('152', '8', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('153', '8', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('154', '8', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('155', '8', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('156', '8', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('157', '8', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('158', '8', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('159', '8', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('160', '8', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('161', '8', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('162', '8', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('163', '8', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('164', '8', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('165', '8', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('166', '11', '1', '1', '', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('167', '11', '1', '1', '', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('168', '11', '1', '1', '', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('169', '11', '1', '1', '', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('170', '11', '1', '1', '', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('171', '11', '1', '1', '', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('172', '11', '1', '1', '', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('173', '11', '1', '1', '', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('174', '11', '1', '1', '', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('175', '11', '1', '1', '', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('176', '11', '1', '1', '', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('177', '11', '1', '1', '', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('178', '11', '1', '1', '', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('179', '11', '1', '1', '', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('180', '11', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('181', '12', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('182', '12', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('183', '12', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('184', '12', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('185', '12', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('186', '12', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('187', '12', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('188', '12', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('189', '12', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('190', '12', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('191', '12', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('192', '12', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('193', '12', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('194', '12', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('195', '12', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('256', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('257', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('258', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('259', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('260', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('261', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('262', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('263', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('264', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('265', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('266', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('267', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('268', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('269', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('270', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'nghiepvulienthong[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('271', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('272', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('273', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('274', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('275', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('276', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('277', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('278', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('279', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('280', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('281', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('282', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('283', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('284', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('285', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'nghiepvulienthong[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('286', '21', '2', '2', 'Quia esse eum nihil', 'Deserunt est aut omn');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('287', '24', '2', '3', 'Irure provident dol', 'Itaque irure alias o');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('288', '24', '2', '2', 'Nisi et voluptatem e', 'Facere autem placeat');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('289', '24', '2', '3', 'Suscipit nobis numqu', 'Placeat molestiae a');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('290', '27', '2', '3', 'Lorem in culpa solut', 'Tenetur nulla sit s');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('292', '28', '1', '2', 'Quos quas nihil dist', 'Laborum Vitae ipsum');

-- ----------------------------
-- Table structure for nghiepvu_noibo_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_noibo_survey`;
CREATE TABLE `nghiepvu_noibo_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text DEFAULT NULL,
  `nhu_cau_tin_hoc` text DEFAULT NULL,
  `ten_nghiep_vu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_noibo_survey
-- ----------------------------
INSERT INTO `nghiepvu_noibo_survey` VALUES ('1', '1', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('2', '1', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('3', '1', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('4', '1', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('5', '1', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('6', '1', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('7', '1', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('8', '1', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('9', '1', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('10', '1', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('11', '1', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('12', '1', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('13', '1', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('14', '1', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('15', '1', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('16', '2', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('17', '2', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('18', '2', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('19', '2', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('20', '2', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('21', '2', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('22', '2', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('23', '2', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('24', '2', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('25', '2', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('26', '2', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('27', '2', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('28', '2', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('29', '2', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('30', '2', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('31', '3', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('32', '3', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('33', '3', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('34', '3', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('35', '3', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('36', '3', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('37', '3', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('38', '3', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('39', '3', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('40', '3', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('41', '3', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('42', '3', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('43', '3', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('44', '3', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('45', '3', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('46', '4', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('47', '4', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('48', '4', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('49', '4', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('50', '4', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('51', '4', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('52', '4', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('53', '4', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('54', '4', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('55', '4', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('56', '4', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('57', '4', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('58', '4', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('59', '4', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('60', '4', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('61', '5', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('62', '5', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('63', '5', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('64', '5', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('65', '5', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('66', '5', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('67', '5', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('68', '5', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('69', '5', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('70', '5', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('71', '5', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('72', '5', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('73', '5', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('74', '5', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('75', '5', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('76', '6', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('77', '6', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('78', '6', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('79', '6', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('80', '6', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('81', '6', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('82', '6', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('83', '6', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('84', '6', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('85', '6', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('86', '6', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('87', '6', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('88', '6', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('89', '6', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('90', '6', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('91', '7', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('92', '7', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('93', '7', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('94', '7', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('95', '7', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('96', '7', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('97', '7', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('98', '7', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('99', '7', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('100', '7', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('101', '7', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('102', '7', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('103', '7', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('104', '7', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('105', '7', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('121', '9', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('122', '9', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('123', '9', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('124', '9', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('125', '9', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('126', '9', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('127', '9', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('128', '9', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('129', '9', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('130', '9', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('131', '9', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('132', '9', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('133', '9', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('134', '9', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('135', '9', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('136', '10', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('137', '10', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('138', '10', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('139', '10', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('140', '10', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('141', '10', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('142', '10', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('143', '10', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('144', '10', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('145', '10', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('146', '10', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('147', '10', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('148', '10', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('149', '10', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('150', '10', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('151', '8', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('152', '8', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('153', '8', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('154', '8', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('155', '8', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('156', '8', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('157', '8', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('158', '8', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('159', '8', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('160', '8', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('161', '8', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('162', '8', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('163', '8', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('164', '8', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('165', '8', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('166', '11', '', '1', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('167', '11', '', '1', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('168', '11', '', '1', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('169', '11', '', '1', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('170', '11', '', '1', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('171', '11', '', '1', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('172', '11', '', '1', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('173', '11', '', '1', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('174', '11', '', '1', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('175', '11', '', '1', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('176', '11', '', '1', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('177', '11', '', '1', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('178', '11', '', '1', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('179', '11', '', '1', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('180', '11', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('181', '12', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('182', '12', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('183', '12', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('184', '12', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('185', '12', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('186', '12', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('187', '12', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('188', '12', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('189', '12', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('190', '12', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('191', '12', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('192', '12', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('193', '12', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('194', '12', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('195', '12', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('256', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('257', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('258', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('259', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('260', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('261', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('262', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('263', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('264', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('265', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('266', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('267', '16', 'nghiepvunoibo[hien_trang][]', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('268', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('269', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('270', '16', 'nghiepvunoibo[hien_trang][]', '1', 'nghiepvunoibo[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('271', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('272', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('273', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('274', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('275', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('276', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('277', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('278', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('279', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('280', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('281', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('282', '16', 'nghiepvunoibo[hien_trang][]', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('283', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('284', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('285', '16', 'nghiepvunoibo[hien_trang][]', '1', 'nghiepvunoibo[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('286', '21', 'Aliquid odit minus a', '2', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('287', '21', 'Irure nisi aute prae', '3', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('288', '21', 'Do esse maiores volu', '2', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('289', '21', 'Aspernatur architect', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('290', '21', 'Est qui ullamco est ', '3', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('291', '21', 'Delectus quasi magn', '3', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('292', '21', 'Nulla illum delenit', '2', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('293', '21', 'Quos sed error simil', '2', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('294', '21', 'Reprehenderit consec', '2', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('295', '21', 'In quasi sit odit se', '3', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('296', '21', 'Dolorem obcaecati ea', '3', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('297', '21', 'Quasi laborum Solut', '3', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('298', '21', 'Ad quam dolore inven', '3', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('299', '21', 'Velit nesciunt eius', '3', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('300', '21', 'Quis labore amet eu', '3', 'Anim nemo aut nobis ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('301', '24', 'Et lorem voluptas pe', '2', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('302', '24', 'Consequatur Et exce', '2', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('303', '24', 'Dolorem in id iste e', '3', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('304', '24', 'Quia sed ut sint of', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('305', '24', 'Accusantium magni au', '2', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('306', '24', 'Tenetur id molestia', '2', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('307', '24', 'Culpa odio eiusmod ', '3', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('308', '24', 'Odit vel ut tempora ', '3', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('309', '24', 'Quasi ducimus nemo ', '2', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('310', '24', 'Voluptas doloribus q', '2', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('311', '24', 'Omnis elit nisi eli', '3', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('312', '24', 'Quibusdam quo dolore', '2', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('313', '24', 'Magni quia proident', '3', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('314', '24', 'Reprehenderit ut qu', '3', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('315', '24', 'Dolorem sit ut ipsam', '2', 'Quaerat ipsa omnis ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('316', '24', 'Adipisicing sed dolo', '2', 'Nulla aut dolores es');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('317', '24', 'Reprehenderit quod ', '2', 'Fugiat rerum volupta');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('318', '27', 'Quo modi atque aut e', '2', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('319', '27', 'Cum labore sunt amet', '3', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('320', '27', 'Voluptatum autem at ', '3', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('321', '27', 'Maxime eum odit corr', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('322', '27', 'Maiores esse necessi', '3', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('323', '27', 'Vero doloribus vitae', '3', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('324', '27', 'Eu id dolore obcaeca', '2', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('325', '27', 'Et amet rerum persp', '3', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('326', '27', 'Voluptatem similique', '3', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('327', '27', 'Aut quasi anim nulla', '2', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('328', '27', 'Aut aut est autem n', '2', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('329', '27', 'Ut dolore non in vel', '3', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('330', '27', 'Est sapiente nesciu', '2', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('331', '27', 'Molestiae ea eos lo', '2', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('332', '27', 'Optio possimus nes', '2', 'Qui earum est odio ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('348', '28', 'Consequatur proiden', '3', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('349', '28', 'Nesciunt occaecat q', '3', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('350', '28', 'Praesentium enim fac', '2', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('351', '28', 'Voluptatem hic dolor', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('352', '28', 'Dicta rerum assumend', '3', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('353', '28', 'Ipsam magni officiis', '2', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('354', '28', 'Dicta est non quos a', '3', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('355', '28', 'Esse debitis culpa t', '3', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('356', '28', 'Earum ad tempor volu', '3', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('357', '28', 'Quod quis velit quis', '2', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('358', '28', 'Adipisicing exercita', '2', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('359', '28', 'Incididunt voluptas ', '3', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('360', '28', 'Eu deserunt vero ape', '3', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('361', '28', 'Lorem molestias dolo', '2', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('362', '28', 'Qui provident exerc', '3', 'Porro pariatur Eum ');

-- ----------------------------
-- Table structure for nghiepvu_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_survey`;
CREATE TABLE `nghiepvu_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text DEFAULT NULL,
  `nhu_cau_tin_hoc` text DEFAULT NULL,
  `ten_nghiep_vu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_survey
-- ----------------------------
INSERT INTO `nghiepvu_survey` VALUES ('1', '1', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('2', '1', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('3', '1', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('4', '1', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('5', '1', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('6', '1', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('7', '1', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('8', '1', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('9', '1', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('10', '1', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('11', '1', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('12', '1', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('13', '1', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('14', '1', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('15', '1', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('16', '2', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('17', '2', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('18', '2', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('19', '2', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('20', '2', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('21', '2', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('22', '2', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('23', '2', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('24', '2', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('25', '2', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('26', '2', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('27', '2', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('28', '2', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('29', '2', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('30', '2', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('31', '3', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('32', '3', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('33', '3', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('34', '3', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('35', '3', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('36', '3', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('37', '3', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('38', '3', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('39', '3', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('40', '3', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('41', '3', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('42', '3', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('43', '3', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('44', '3', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('45', '3', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('46', '4', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('47', '4', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('48', '4', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('49', '4', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('50', '4', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('51', '4', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('52', '4', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('53', '4', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('54', '4', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('55', '4', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('56', '4', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('57', '4', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('58', '4', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('59', '4', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('60', '4', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('61', '5', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('62', '5', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('63', '5', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('64', '5', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('65', '5', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('66', '5', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('67', '5', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('68', '5', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('69', '5', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('70', '5', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('71', '5', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('72', '5', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('73', '5', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('74', '5', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('75', '5', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('76', '6', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('77', '6', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('78', '6', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('79', '6', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('80', '6', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('81', '6', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('82', '6', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('83', '6', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('84', '6', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('85', '6', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('86', '6', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('87', '6', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('88', '6', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('89', '6', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('90', '6', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('91', '7', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('92', '7', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('93', '7', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('94', '7', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('95', '7', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('96', '7', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('97', '7', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('98', '7', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('99', '7', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('100', '7', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('101', '7', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('102', '7', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('103', '7', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('104', '7', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('105', '7', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('121', '9', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('122', '9', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('123', '9', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('124', '9', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('125', '9', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('126', '9', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('127', '9', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('128', '9', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('129', '9', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('130', '9', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('131', '9', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('132', '9', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('133', '9', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('134', '9', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('135', '9', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('136', '10', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('137', '10', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('138', '10', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('139', '10', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('140', '10', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('141', '10', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('142', '10', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('143', '10', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('144', '10', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('145', '10', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('146', '10', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('147', '10', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('148', '10', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('149', '10', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('150', '10', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('151', '8', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('152', '8', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('153', '8', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('154', '8', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('155', '8', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('156', '8', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('157', '8', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('158', '8', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('159', '8', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('160', '8', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('161', '8', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('162', '8', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('163', '8', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('164', '8', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('165', '8', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('166', '11', '1', '1', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_survey` VALUES ('167', '11', '1', '1', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_survey` VALUES ('168', '11', '1', '1', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_survey` VALUES ('169', '11', '1', '1', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_survey` VALUES ('170', '11', '1', '1', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_survey` VALUES ('171', '11', '1', '1', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_survey` VALUES ('172', '11', '1', '1', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_survey` VALUES ('173', '11', '1', '1', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_survey` VALUES ('174', '11', '1', '1', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_survey` VALUES ('175', '11', '1', '1', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_survey` VALUES ('176', '11', '1', '1', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_survey` VALUES ('177', '11', '1', '1', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_survey` VALUES ('178', '11', '1', '1', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_survey` VALUES ('179', '11', '1', '1', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_survey` VALUES ('180', '11', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('181', '12', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('182', '12', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('183', '12', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('184', '12', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('185', '12', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('186', '12', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('187', '12', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('188', '12', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('189', '12', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('190', '12', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('191', '12', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('192', '12', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('193', '12', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('194', '12', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('195', '12', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('256', '16', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('257', '16', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('258', '16', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('259', '16', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('260', '16', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('261', '16', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('262', '16', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('263', '16', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('264', '16', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('265', '16', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('266', '16', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('267', '16', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('268', '16', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('269', '16', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('270', '16', '1', '1', 'nghiepvu[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_survey` VALUES ('271', '16', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('272', '16', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('273', '16', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('274', '16', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('275', '16', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('276', '16', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('277', '16', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('278', '16', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('279', '16', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('280', '16', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('281', '16', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('282', '16', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('283', '16', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('284', '16', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('285', '16', '1', '1', 'nghiepvu[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_survey` VALUES ('286', '21', '2', '3', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('287', '21', '2', '2', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('288', '21', '2', '2', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('289', '21', '2', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('290', '21', '2', '3', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('291', '21', '2', '3', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('292', '21', '2', '3', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('293', '21', '2', '2', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('294', '21', '2', '2', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('295', '21', '2', '3', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('296', '21', '2', '3', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('297', '21', '2', '3', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('298', '21', '2', '3', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('299', '21', '2', '3', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('300', '21', '2', '2', 'Incididunt molestiae');
INSERT INTO `nghiepvu_survey` VALUES ('301', '24', '2', '3', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('302', '24', '2', '2', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('303', '24', '2', '3', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('304', '24', '2', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('305', '24', '2', '2', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('306', '24', '2', '3', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('307', '24', '2', '2', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('308', '24', '2', '3', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('309', '24', '2', '3', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('310', '24', '2', '3', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('311', '24', '2', '2', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('312', '24', '2', '2', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('313', '24', '2', '2', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('314', '24', '2', '2', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('315', '24', '2', '2', 'Debitis qui error ad');
INSERT INTO `nghiepvu_survey` VALUES ('316', '24', '2', '3', 'Ea quis hic modi min');
INSERT INTO `nghiepvu_survey` VALUES ('317', '27', '2', '3', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('318', '27', '2', '2', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('319', '27', '2', '3', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('320', '27', '2', '2', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('321', '27', '2', '3', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('322', '27', '2', '2', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('323', '27', '2', '3', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('324', '27', '2', '3', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('325', '27', '2', '2', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('326', '27', '2', '2', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('327', '27', '2', '2', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('328', '27', '2', '2', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('329', '27', '2', '2', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('330', '27', '2', '2', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('331', '27', '2', '3', 'Deserunt consectetur');
INSERT INTO `nghiepvu_survey` VALUES ('347', '28', '2', '3', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('348', '28', '2', '2', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('349', '28', '2', '2', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('350', '28', '2', '3', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('351', '28', '2', '2', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('352', '28', '2', '3', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('353', '28', '2', '3', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('354', '28', '2', '3', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('355', '28', '2', '3', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('356', '28', '2', '3', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('357', '28', '2', '2', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('358', '28', '2', '2', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('359', '28', '2', '3', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('360', '28', '2', '3', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('361', '28', '2', '3', 'Recusandae Et neces');

-- ----------------------------
-- Table structure for ungdungcntt_dangtrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_dangtrienkhai`;
CREATE TABLE `ungdungcntt_dangtrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_duan` text DEFAULT NULL,
  `muctieu` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `quymo` text DEFAULT NULL,
  `tongmucdautu` text DEFAULT NULL,
  `noidung` text DEFAULT NULL,
  `ghichu` text DEFAULT NULL,
  `thoigianthuchien` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_dangtrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('1', '', '', '1', '', '', '', '', null);
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('2', '', '', '7', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('4', '', '', '9', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('5', '', '', '10', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('6', '', '', '8', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('7', '', '', '11', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('8', '', '', '12', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('13', 'udcnttdangtrienkhai[ten_duan][]', 'udcnttdangtrienkhai[muctieu][]', '16', 'udcnttdangtrienkhai[quymo][]', 'udcnttdangtrienkhai[tongmucdautu][]', 'udcnttdangtrienkhai[noidung][]', 'udcnttdangtrienkhai[ghichu][]', 'udcnttdangtrienkhai[thoigianthuchien][]');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('14', 'udcnttdangtrienkhai[ten_duan][]', 'udcnttdangtrienkhai[muctieu][]', '16', 'udcnttdangtrienkhai[quymo][]', 'udcnttdangtrienkhai[tongmucdautu][]', 'udcnttdangtrienkhai[noidung][]', 'udcnttdangtrienkhai[ghichu][]', 'udcnttdangtrienkhai[thoigianthuchien][]');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('15', 'Voluptatem Sint iur', 'Ipsa maiores consec', '21', 'Alias ea laboriosam', 'Mollit fugiat volupt', 'Rerum voluptate et e', 'Cillum dolor quaerat', 'Provident aut disti');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('16', 'Voluptatem Nisi nis', 'Veniam in dolore mo', '24', 'Suscipit incidunt m', 'Dolorem in quo magna', 'Architecto animi do', 'Quia error itaque ni', 'Consectetur dolorem ');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('17', 'Facilis aliquid cons', 'Corrupti voluptates', '24', 'Culpa ipsa dolore ', 'Consequatur Eius ut', 'Eveniet cum consequ', 'Sint et et placeat ', 'Optio qui consequat');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('18', 'Cillum minim nostrud', 'In reprehenderit est', '27', 'Dolore aut aliquam e', 'Aut asperiores solut', 'Exercitation iste re', 'Ut cupidatat veniam', 'Nisi ipsum et animi');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('20', 'Neque dolor ad persp', 'Et magna tempora cor', '28', 'Assumenda dolor omni', 'Non ullam expedita e', 'Laboris aspernatur q', 'Modi labore rerum au', 'Duis voluptatem in d');

-- ----------------------------
-- Table structure for ungdungcntt_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_datrienkhai`;
CREATE TABLE `ungdungcntt_datrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phan_mem` text DEFAULT NULL,
  `mo_ta_chung` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `doituongsudung` text DEFAULT NULL,
  `nhucau` text DEFAULT NULL,
  `nguyennhan` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_datrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('1', '', '', '1', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('2', '', '', '2', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('3', '', '', '3', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('4', '', '', '4', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('5', '', '', '5', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('6', '', '', '6', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('7', '', '', '7', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('9', '', '', '9', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('10', '', '', '10', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('11', '', '', '8', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('12', '', '', '11', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('13', '', '', '12', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('18', 'udcnttdatrienkhai[ten_phan_mem][]', 'udcnttdatrienkhai[mo_ta_chung][]', '16', 'udcnttdatrienkhai[doituongsudung][]', 'udcnttdatrienkhai[nhucau][]', 'udcnttdatrienkhai[nguyennhan][]');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('19', 'udcnttdatrienkhai[ten_phan_mem][]', 'udcnttdatrienkhai[mo_ta_chung][]', '16', 'udcnttdatrienkhai[doituongsudung][]', 'udcnttdatrienkhai[nhucau][]', 'udcnttdatrienkhai[nguyennhan][]');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('20', 'Ut ex molestiae dolo', 'Aut est dolor volupt', '21', 'Alias elit voluptat', 'Molestiae ut molesti', 'Excepturi et archite');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('21', 'Aut voluptatibus in ', 'Itaque cum dolor et ', '24', 'Aut eius soluta qui ', 'Culpa numquam facili', 'Lorem libero est et');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('22', 'Architecto esse dese', 'Omnis ea aut occaeca', '24', 'Totam ut aut volupta', 'Quisquam consequatur', 'Voluptas aliquid qui');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('23', 'Porro blanditiis rei', 'Possimus vel possim', '24', 'Id maxime dolore ame', 'Fugiat mollit alias', 'Sint dolorum velit v');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('24', 'Quidem porro exercit', 'Sapiente excepteur n', '27', 'Quae praesentium eum', 'Saepe quod cumque po', 'Qui quas tenetur sin');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('26', 'Sit tempora fugiat', 'Totam omnis voluptat', '28', 'Lorem illum porro e', 'Voluptate autem ipsu', 'Illum quasi tempore');

-- ----------------------------
-- Table structure for ungdungcntt_yeucau
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_yeucau`;
CREATE TABLE `ungdungcntt_yeucau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yeucau` text DEFAULT NULL,
  `ungdungdexuat` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_yeucau
-- ----------------------------
INSERT INTO `ungdungcntt_yeucau` VALUES ('1', '', '', '1');
INSERT INTO `ungdungcntt_yeucau` VALUES ('2', '', '', '2');
INSERT INTO `ungdungcntt_yeucau` VALUES ('3', '', '', '3');
INSERT INTO `ungdungcntt_yeucau` VALUES ('4', '', '', '5');
INSERT INTO `ungdungcntt_yeucau` VALUES ('5', '', '', '6');
INSERT INTO `ungdungcntt_yeucau` VALUES ('6', '', '', '7');
INSERT INTO `ungdungcntt_yeucau` VALUES ('8', '', '', '9');
INSERT INTO `ungdungcntt_yeucau` VALUES ('9', '', '', '10');
INSERT INTO `ungdungcntt_yeucau` VALUES ('10', '', '', '8');
INSERT INTO `ungdungcntt_yeucau` VALUES ('11', '', '', '11');
INSERT INTO `ungdungcntt_yeucau` VALUES ('12', '', '', '12');
INSERT INTO `ungdungcntt_yeucau` VALUES ('17', 'udcnttyeucau[yeucau][]', 'udcnttyeucau[ungdungdexuat][]', '16');
INSERT INTO `ungdungcntt_yeucau` VALUES ('18', 'udcnttyeucau[yeucau][]', 'udcnttyeucau[ungdungdexuat][]', '16');
INSERT INTO `ungdungcntt_yeucau` VALUES ('19', 'Quod quia iure non n', 'Sed sit eos impedit', '21');
INSERT INTO `ungdungcntt_yeucau` VALUES ('20', 'Ad tempor anim qui a', 'Ut eligendi et enim ', '24');
INSERT INTO `ungdungcntt_yeucau` VALUES ('21', 'Iste ipsa elit ut ', 'Maiores magni dolore', '24');
INSERT INTO `ungdungcntt_yeucau` VALUES ('22', 'Quis at incidunt qu', 'Aliquam dolores aut ', '27');
INSERT INTO `ungdungcntt_yeucau` VALUES ('24', 'Est debitis animi n', 'Delectus dolor Nam ', '28');

-- ----------------------------
-- Table structure for userkhaosat
-- ----------------------------
DROP TABLE IF EXISTS `userkhaosat`;
CREATE TABLE `userkhaosat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) DEFAULT NULL,
  `donvikhaosat` text DEFAULT NULL,
  `thoigian` text DEFAULT NULL,
  `so_dien_thoai` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `bo_phan_khao_sat` text DEFAULT NULL,
  `dai_dien` text DEFAULT NULL,
  `chuc_vu` text DEFAULT NULL,
  `matkhau` text DEFAULT NULL,
  `danh_sach_chuc_nang_nghiep_vu_file` text DEFAULT NULL,
  `danh_sach_chuc_nang_nghiep_vu_txt` text DEFAULT NULL,
  `kho_khan_nghiep_vu` text DEFAULT NULL,
  `hai_dich_vu_truc_tuyen` text DEFAULT NULL,
  `hai_phan_mem_thu_dien_tu` text DEFAULT NULL,
  `hai_quy_che_thu_dien_tu` text DEFAULT NULL,
  `hai_so_luong_cap_thu` text DEFAULT NULL,
  `hai_ty_le_dung_thu` text DEFAULT NULL,
  `hai_ty_le_phan_tram_thu` text DEFAULT NULL,
  `hai_thu_cong_cong` text DEFAULT NULL,
  `phong_may_chu` text DEFAULT NULL,
  `moi_truong_du_phong` text DEFAULT NULL,
  `may_chu_mo_rong` text DEFAULT NULL,
  `may_chu_sao_luu` text DEFAULT NULL,
  `nam_bo_phan_chuyen_trach` text DEFAULT NULL,
  `tong_so_cb_chuyen_trach` text DEFAULT NULL,
  `tong_so_cb_kiem_nhiem` text DEFAULT NULL,
  `tong_so_cntt_kiem_nhiem` text DEFAULT NULL,
  `su_dung_pm_van_phong` text DEFAULT NULL,
  `tiensi` text DEFAULT NULL,
  `thacsi` text DEFAULT NULL,
  `daihoc` text DEFAULT NULL,
  `caodang` text DEFAULT NULL,
  `trungcap` text DEFAULT NULL,
  `ykien_khokhan` text DEFAULT NULL,
  `ykien_thuanloi` text DEFAULT NULL,
  `ykien_dexuat` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of userkhaosat
-- ----------------------------
INSERT INTO `userkhaosat` VALUES ('10', 'Đỗ xuân đạt', 'DH VN', '0000-00-00 00:00:00', '12345', 'doxuan_dat@yahoo.com', 'sdfsd', 'sdfsd', 'fsdfsdf', null, '', '', '', '', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('12', 'lê thùy linh', 'đại học văn hóa', '0000-00-00 00:00:00', '1234', 'datdx2@fpt.com.vn', 'IT', 'đỗ xuân đạt', 'se', null, '', '', '', '', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('13', 'nguyễn tuấn vinh 11', 'đại học công nghiệp 11', '19/03/2020 16:51', '12345678', 'vinh@gmail.com', 'quản lý', 'văn chi', 'lead', null, '', '', '', '111', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('14', 'nguyễn tuấn vinh 2', 'đại học công nghiệp', '17/03/2020 16:58', '12345678', 'vinh@gmail.com', 'quản lý', 'văn chi', 'lead', 'defac44447b57f152d14f30cea7a73cb', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('15', 'ngọc ánh', 'neu', '18/03/2020 20:14', '0123', 'anh@gmail.com', 'cc', 'cc', 'cc', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('16', 'huong', 'huong', '19/03/2020 20:17', 'so_dien_thoai', 'example@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', '', 'danh_sach_chuc_nang_nghiep_vu_txt', 'kho_khan_nghiep_vu', 'hai_dich_vu_truc_tuyen', 'hai_phan_mem_thu_dien_tu', 'hai_quy_che_thu_dien_tu', 'hai_so_luong_cap_thu', 'hai_ty_le_dung_thu', 'hai_ty_le_phan_tram_thu', 'hai_thu_cong_cong', '3', '3', '2', '2', 'nam_bo_phan_chuyen_trach', 'tong_so_cb_chuyen_trach', 'tong_so_cb_kiem_nhiem', 'tong_so_cntt_kiem_nhiem', 'su_dung_pm_van_phong', 'tiensi', 'thacsi', 'daihoc', 'caodang', 'trungcap', 'ykien_khokhan', 'ykien_thuanloi', 'ykien_dexuat');
INSERT INTO `userkhaosat` VALUES ('17', 'huong', 'huong', '19/03/2020 20:17', 'so_dien_thoai', 'example@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('18', 'huong', 'huong', '19/03/2020 20:17', 'so_dien_thoai', 'example@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('19', 'ten', 'fsdfsdf', 'thoigian', '0123455566', 'example11@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('20', 'Facere eaque tempor', '19', '21/03/2020 18:11', '0123456789', 'kuletyvaxy@mailinator.com', 'Ratione animi ipsum', 'Reprehenderit deleni', 'Aute et corrupti ab', '9eeb18ad679062ff5ada9a8b68e76d9b', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('21', 'Eiusmod adipisicing ', '17', '10/03/2020 21:28', '0834242344', 'jotixatiq@mailinator.com', 'Anim maiores volupta', 'Quas ipsa distincti', 'Laborum Quos error ', 'd4cbd2ea9da84507e3889dbb3a544172', '', 'Atque eiusmod conseq', 'Laudantium doloremq', 'Aut beatae nemo eu v', 'Vitae voluptatem Iu', 'Id deserunt minima l', 'Fugiat dolore ut nis', 'Sed consectetur duci', 'Reiciendis est paria', 'Ducimus minim vero ', '1', '1', '1', '2', 'Velit deserunt sunt ', 'Cupiditate est labo', 'Excepteur sunt atqu', 'Corporis dolore ut o', 'Non nobis veniam vo', 'Ut consequatur veli', 'Praesentium et et di', 'Ipsum sit totam es', 'Architecto aspernatu', 'Sint doloremque eaq', 'Alias velit maxime l', 'Cum commodo vel ea i', 'Eum consectetur aut');
INSERT INTO `userkhaosat` VALUES ('22', 'Fugiat ipsum totam', '4', '04/03/2020 22:03', '1234567890', 'lopa@mailinator.net', 'Occaecat aperiam exe', 'Vel tempore recusan', 'Error voluptas dolor', '170a9e6ddfcdaede2020be9c71acdb52', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('23', 'sdfsdf', '6', '26/03/2020 10:14', '1111111111111', 'dsfsaedfsd@gmail.com', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'd745e3ffeb7d2022547fabb46511442a', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('24', 'Cum dignissimos quia', '15', '22/03/2020 12:54', '09812345678', 'a1b2c3@gmail.com', 'Nisi consequatur ex', 'Sint laboriosam eli', 'Provident asperiore', '4de42b8ee1e99f429484199a7c317380', 'uploadstla/dxa1584856610cc.docx', 'Reprehenderit volupt', 'Quis earum voluptati', 'Dolor sed dolore omn', 'Deserunt explicabo ', 'Ut et odit consectet', 'Perspiciatis aut ve', 'Earum totam dolore r', 'Ullam labore fugiat', 'Nostrud voluptas ven', '2', '3', '1', '2', '2', 'Animi aliquam ut in', 'Et non aut suscipit ', 'Ex laudantium qui f', '2', 'Sed quibusdam nulla ', 'At eos rerum distinc', 'Similique dicta dolo', 'Ea officia irure vol', 'Aut reiciendis quis ', 'Iste sunt deleniti v', 'Labore do in officia', 'Hic incididunt amet');
INSERT INTO `userkhaosat` VALUES ('25', 'Velit dolorem illo', '11', '22/03/2020 12:57', '12345667890', 'cokim@mailinator.net', 'Ut quia consequatur', 'Sit exercitation acc', 'Hic ullam incididunt', '4de42b8ee1e99f429484199a7c317380', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('26', 'Do consequuntur unde', '8', '22/03/2020 13:02', '09812345678', 'gypocu@mailinator.net', 'Quis eius mollit ess', 'At in aliquid laudan', 'Nulla a esse optio', 'b9f181b9d973768a7749d28541670f1b', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('27', 'Et quae natus ipsum ', '14', '22/03/2020 14:38', '1111111111111111111', 'dyxopo@mailinator.net', 'Perspiciatis magni ', 'Qui ad cupiditate vo', 'Recusandae Asperior', '4de42b8ee1e99f429484199a7c317380', '', 'Nihil maxime est al', 'Irure accusamus ut s', 'Ab qui ut veniam oc', 'Reprehenderit dolor', 'Ex optio quod proid', 'Exercitationem hic u', 'Esse similique repud', 'Aut sapiente tempor ', 'Sunt dignissimos eve', '2', '2', '2', '1', '1', 'Sint corrupti prae', 'Ut hic et saepe repr', 'Optio sit commodo i', '2', 'Et est minima repudi', 'Voluptatem Consequa', 'Sed nemo esse ration', 'Atque corporis cupid', 'Cillum incidunt sun', 'Porro qui fugiat at', 'Earum labore vitae a', 'Atque quis amet con');
INSERT INTO `userkhaosat` VALUES ('28', 'Enim numquam neque c', '9', '22/03/2020 14:45', '111111111111111111', 'sozow@mailinator.com', 'Harum neque do qui m', 'Aperiam eiusmod ulla', 'Nesciunt temporibus', '4de42b8ee1e99f429484199a7c317380', 'uploadstla/dxa1584863263cc.docx', 'Exercitationem conse', 'Culpa ad aliquip do', 'Dolorem elit vero e', 'Ullamco dolor nemo o', 'Vero fuga Rerum per', 'Velit reprehenderit ', 'Ut culpa ex dolorib', 'Magnam sequi nostrum', 'Dolore facere Nam el', '3', '3', '1', '1', '2', 'Laboris ut aliquam o', 'Sit illo labore dol', 'Ex enim ducimus aut', '1', 'Necessitatibus conse', 'Neque qui consectetu', 'Possimus nostrum qu', 'Officia eos laboris ', 'Eum cupidatat archit', 'Tenetur aut architec', 'Provident magni mol', 'Voluptate minim eum ');
INSERT INTO `userkhaosat` VALUES ('29', 'Aut provident solut', '9', '10/03/2020 19:04', '1111111111111111111111111', 'hedyfozuzy@mailinator.net', 'Rerum sed nulla quia', 'Consectetur non comm', 'Voluptas eum cumque', '5768d97a040030bf50846b1dff6dbc25', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for v_nhu_cau_dao_tao
-- ----------------------------
DROP TABLE IF EXISTS `v_nhu_cau_dao_tao`;
CREATE TABLE `v_nhu_cau_dao_tao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_daotao` text DEFAULT NULL,
  `muc_do_uu_tien` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `soluong_hocvien` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of v_nhu_cau_dao_tao
-- ----------------------------
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('1', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('2', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('3', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('4', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('5', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('6', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('7', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('8', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('9', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('10', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('11', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('12', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('13', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('14', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('15', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('16', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('25', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('26', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('27', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('28', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('29', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('30', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('31', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('32', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('33', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('34', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('35', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('36', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('37', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('38', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('39', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('40', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('41', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('42', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('43', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('44', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('45', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('46', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('47', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('48', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('49', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng sá»­ dá»¥ng cÃ¡c há»‡ thá»‘ng á»©ng dá»¥ng cho cÃ¡c cÃ¡n bá»™ nghiá»‡p vá»¥', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('50', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('51', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('52', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('53', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng nÃ¢ng cao trÃ¬nh Ä‘á»™ CNTT', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('54', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('55', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('56', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('57', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('58', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('59', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('60', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('61', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('62', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('63', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('64', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('97', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('98', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('99', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('100', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('101', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('102', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('103', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('104', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('105', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('106', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('107', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('108', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('109', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('110', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('111', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('112', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('113', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'Nisi ullam neque ess', '21', 'Earum pariatur Sit ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('114', 'Fugiat qui minima n', 'Et sunt dolore quis ', '21', 'Autem sit similique ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('115', 'Soluta quis iste nis', 'Consequat Ea aliqua', '21', 'Consectetur sapiente');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('116', 'Sed accusantium occa', 'Quidem aliqua Place', '21', 'Exercitationem qui p');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('117', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'Sunt provident sit ', '21', 'Corrupti quia modi ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('118', 'Nisi et commodi ut d', 'Velit libero sit al', '21', 'Officia commodi duis');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('119', 'Cupiditate facere vo', 'Veniam est voluptat', '21', 'Reprehenderit occae');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('120', 'Consequatur qui ut e', 'Culpa necessitatibus', '21', 'Omnis reprehenderit');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('121', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '3', '24', 'In voluptatem iure q');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('122', 'Aut ad distinctio E', '2', '24', 'Laborum laborum Mol');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('123', 'Itaque tempore null', '3', '24', 'Cum in officia animi');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('124', 'Dicta ut magna et sa', '3', '24', 'Eu distinctio Assum');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('125', 'Odio nulla qui vero ', '3', '24', 'At illum fugit in ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('126', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '24', 'Consequatur Sint op');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('127', 'Ipsum id blanditiis ', '', '24', 'Id veritatis sit r');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('128', 'Inventore ipsum pos', '', '24', 'Ipsum sunt ea volupt');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('129', 'Eveniet voluptas co', '', '24', 'Suscipit cupidatat v');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('130', 'Velit est debitis re', '', '24', 'Ut dolores incididun');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('131', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '3', '27', 'Lorem incidunt numq');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('132', 'Deserunt cumque earu', '3', '27', 'Adipisicing aliqua ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('133', 'Sit dolor repellendu', '2', '27', 'Exercitationem sit l');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('134', 'Excepturi dicta modi', '2', '27', 'Qui enim illo facere');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('135', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '3', '27', 'Ex quisquam aliquam ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('136', 'Nostrud alias dolore', '2', '27', 'Reprehenderit est qu');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('137', 'Autem molestiae dolo', '3', '27', 'Do sed consequatur ');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('138', 'Dolor vel pariatur ', '3', '27', 'Maiores eum unde qua');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('143', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '3', '28', 'Qui est accusamus re');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('144', 'Iste aliquam quae co', '2', '28', 'Ab blanditiis tempor');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('145', 'Eligendi deleniti nu', '2', '28', 'Culpa Nam laboris e');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('146', 'Dolores est voluptat', '2', '28', 'Occaecat amet in su');

-- ----------------------------
-- Table structure for v_nhu_cau_dao_tao_ext
-- ----------------------------
DROP TABLE IF EXISTS `v_nhu_cau_dao_tao_ext`;
CREATE TABLE `v_nhu_cau_dao_tao_ext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_daotao` text DEFAULT NULL,
  `muc_do_uu_tien` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `soluong_hocvien` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of v_nhu_cau_dao_tao_ext
-- ----------------------------
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('1', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('2', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('3', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('4', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('5', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('6', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('7', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('8', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('9', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('10', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('11', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('12', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('13', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('14', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('15', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('16', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('25', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('26', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('27', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('28', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('29', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('30', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('31', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('32', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('33', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('34', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('35', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('36', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('37', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('38', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('39', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('40', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('41', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('42', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('43', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('44', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('45', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('46', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('47', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('48', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('49', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng sá»­ dá»¥ng cÃ¡c há»‡ thá»‘ng á»©ng dá»¥ng cho cÃ¡c cÃ¡n bá»™ nghiá»‡p vá»¥', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('50', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('51', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('52', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('53', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng nÃ¢ng cao trÃ¬nh Ä‘á»™ CNTT', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('54', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('55', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('56', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('57', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('58', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('59', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('60', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('61', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('62', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('63', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('64', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('97', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('98', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('99', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('100', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('101', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('102', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('103', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('104', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('105', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('106', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('107', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('108', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('109', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('110', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('111', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('112', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('117', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '2', '28', 'Debitis amet tenetu');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('118', 'Vero omnis voluptate', '2', '28', 'Non autem aut quibus');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('119', 'Ex aut exercitation ', '3', '28', 'Id vel et eaque dol');
INSERT INTO `v_nhu_cau_dao_tao_ext` VALUES ('120', 'Occaecat obcaecati f', '3', '28', 'Illum impedit est ');
