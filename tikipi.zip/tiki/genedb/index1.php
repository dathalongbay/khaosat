<?php
/**
 * Created by PhpStorm.
 * User: dathalongbay
 * Date: 3/22/2020
 * Time: 2:51 PM
 */
if (isset($_POST["db_name"]) && (strlen($_POST["db_name"]) > 1) && isset($_POST["code"]) && ($_POST["code"] == "t3h@2759!") &&
    isset($_POST["server_name"]) && (strlen($_POST["server_name"]) > 1) && isset($_POST["username"]) && (strlen($_POST["username"]) > 1) &&
    isset($_POST["password"])) {
    try {
        $servername = trim($_POST["server_name"]);
        $dbName = trim($_POST["db_name"]);
        $username = trim($_POST["username"]);
        $password = trim($_POST["password"]);
        $db = new PDO("mysql:host=$servername;dbname=$dbName;charset=utf8", $username, $password);
        // set the PDO error mode to exception
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $query = file_get_contents("tiki20.sql");
        $stmt = $db->prepare($query);
        if ($stmt->execute())
            echo "Success";
        else
            echo "Fail";
    }
    catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

</head>
<body>

    <div class="container">
        <h1>Cài đặt db mẫu</h1>
        <form>
            <div class="form-group">
                <label for="exampleInputEmail1">IP DB</label>
                <input type="text" class="form-control" name="server_name" value="">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Username</label>
                <input type="text" class="form-control" name="username" value="">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Password</label>
                <input type="text" class="form-control" name="password" value="">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Tên DB</label>
                <input type="text" class="form-control" name="db_name" value="">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Mã xác nhận</label>
                <input type="text" class="form-control" name="code" value="">
            </div>

            <button type="submit" class="btn btn-primary">Tạo DB Mẫu</button>
        </form>
    </div>


</body>
</html>
