/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 100411
 Source Host           : localhost:3306
 Source Schema         : tiki1

 Target Server Type    : MySQL
 Target Server Version : 100411
 File Encoding         : 65001

 Date: 18/03/2020 21:45:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------

-- ----------------------------
-- Table structure for csdl_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `csdl_datrienkhai`;
CREATE TABLE `csdl_datrienkhai`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_csdl` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `he_csdl` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ban_quyen` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nam_dau_tu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `he_dieu_hanh` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nhucau` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of csdl_datrienkhai
-- ----------------------------
INSERT INTO `csdl_datrienkhai` VALUES (1, NULL, NULL, NULL, '', '', '', 1);
INSERT INTO `csdl_datrienkhai` VALUES (2, NULL, NULL, NULL, '', '', '', 7);
INSERT INTO `csdl_datrienkhai` VALUES (4, NULL, NULL, NULL, '', '', '', 9);
INSERT INTO `csdl_datrienkhai` VALUES (5, '', '', '', '', '', '', 10);
INSERT INTO `csdl_datrienkhai` VALUES (6, '', '', '', '', '', '', 8);

-- ----------------------------
-- Table structure for csdl_traodoi
-- ----------------------------
DROP TABLE IF EXISTS `csdl_traodoi`;
CREATE TABLE `csdl_traodoi`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `linh_vuc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `don_vi_lien_quan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `thong_tin_trao_doi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tan_suat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `phuong_thuc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ghi_chu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of csdl_traodoi
-- ----------------------------
INSERT INTO `csdl_traodoi` VALUES (1, 1, '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES (2, 7, '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES (4, 9, '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES (5, 10, '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES (6, 8, '', '', '', '', '', '');

-- ----------------------------
-- Table structure for maychuvatly
-- ----------------------------
DROP TABLE IF EXISTS `maychuvatly`;
CREATE TABLE `maychuvatly`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `model` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `soluong` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `thong_so` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nam_dau_tu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tinh_trang` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ghi_chu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of maychuvatly
-- ----------------------------
INSERT INTO `maychuvatly` VALUES (1, 1, '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES (2, 7, '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES (4, 9, '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES (5, 10, '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES (6, 8, '', '', '', '', '', '');

-- ----------------------------
-- Table structure for nghiepvu_lienthong_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_lienthong_survey`;
CREATE TABLE `nghiepvu_lienthong_survey`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `hien_trang` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nhu_cau_tin_hoc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `coquan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ten_nghiep_vu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 166 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nghiepvu_lienthong_survey
-- ----------------------------
INSERT INTO `nghiepvu_lienthong_survey` VALUES (1, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (2, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (3, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (4, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (5, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (6, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (7, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (8, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (9, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (10, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (11, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (12, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (13, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (14, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (15, 1, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (16, 2, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (17, 2, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (18, 2, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (19, 2, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (20, 2, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (21, 2, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (22, 2, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (23, 2, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (24, 2, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (25, 2, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (26, 2, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (27, 2, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (28, 2, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (29, 2, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (30, 2, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (31, 3, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (32, 3, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (33, 3, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (34, 3, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (35, 3, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (36, 3, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (37, 3, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (38, 3, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (39, 3, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (40, 3, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (41, 3, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (42, 3, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (43, 3, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (44, 3, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (45, 3, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (46, 4, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (47, 4, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (48, 4, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (49, 4, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (50, 4, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (51, 4, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (52, 4, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (53, 4, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (54, 4, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (55, 4, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (56, 4, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (57, 4, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (58, 4, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (59, 4, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (60, 4, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (61, 5, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (62, 5, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (63, 5, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (64, 5, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (65, 5, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (66, 5, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (67, 5, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (68, 5, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (69, 5, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (70, 5, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (71, 5, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (72, 5, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (73, 5, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (74, 5, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (75, 5, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (76, 6, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (77, 6, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (78, 6, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (79, 6, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (80, 6, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (81, 6, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (82, 6, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (83, 6, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (84, 6, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (85, 6, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (86, 6, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (87, 6, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (88, 6, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (89, 6, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (90, 6, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (91, 7, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (92, 7, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (93, 7, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (94, 7, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (95, 7, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (96, 7, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (97, 7, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (98, 7, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (99, 7, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (100, 7, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (101, 7, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (102, 7, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (103, 7, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (104, 7, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (105, 7, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (121, 9, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (122, 9, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (123, 9, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (124, 9, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (125, 9, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (126, 9, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (127, 9, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (128, 9, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (129, 9, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (130, 9, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (131, 9, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (132, 9, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (133, 9, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (134, 9, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (135, 9, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (136, 10, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (137, 10, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (138, 10, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (139, 10, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (140, 10, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (141, 10, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (142, 10, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (143, 10, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (144, 10, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (145, 10, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (146, 10, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (147, 10, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (148, 10, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (149, 10, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (150, 10, '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (151, 8, '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (152, 8, '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (153, 8, '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (154, 8, '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (155, 8, '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (156, 8, '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (157, 8, '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (158, 8, '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (159, 8, '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (160, 8, '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (161, 8, '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (162, 8, '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (163, 8, '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (164, 8, '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES (165, 8, '1', '1', '', '');

-- ----------------------------
-- Table structure for nghiepvu_noibo_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_noibo_survey`;
CREATE TABLE `nghiepvu_noibo_survey`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `hien_trang` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nhu_cau_tin_hoc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ten_nghiep_vu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 166 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nghiepvu_noibo_survey
-- ----------------------------
INSERT INTO `nghiepvu_noibo_survey` VALUES (1, 1, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (2, 1, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (3, 1, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (4, 1, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (5, 1, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (6, 1, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (7, 1, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (8, 1, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (9, 1, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (10, 1, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (11, 1, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (12, 1, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (13, 1, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (14, 1, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (15, 1, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (16, 2, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (17, 2, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (18, 2, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (19, 2, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (20, 2, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (21, 2, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (22, 2, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (23, 2, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (24, 2, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (25, 2, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (26, 2, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (27, 2, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (28, 2, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (29, 2, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (30, 2, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (31, 3, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (32, 3, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (33, 3, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (34, 3, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (35, 3, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (36, 3, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (37, 3, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (38, 3, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (39, 3, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (40, 3, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (41, 3, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (42, 3, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (43, 3, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (44, 3, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (45, 3, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (46, 4, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (47, 4, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (48, 4, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (49, 4, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (50, 4, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (51, 4, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (52, 4, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (53, 4, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (54, 4, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (55, 4, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (56, 4, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (57, 4, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (58, 4, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (59, 4, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (60, 4, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (61, 5, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (62, 5, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (63, 5, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (64, 5, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (65, 5, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (66, 5, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (67, 5, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (68, 5, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (69, 5, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (70, 5, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (71, 5, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (72, 5, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (73, 5, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (74, 5, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (75, 5, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (76, 6, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (77, 6, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (78, 6, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (79, 6, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (80, 6, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (81, 6, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (82, 6, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (83, 6, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (84, 6, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (85, 6, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (86, 6, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (87, 6, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (88, 6, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (89, 6, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (90, 6, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (91, 7, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (92, 7, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (93, 7, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (94, 7, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (95, 7, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (96, 7, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (97, 7, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (98, 7, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (99, 7, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (100, 7, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (101, 7, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (102, 7, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (103, 7, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (104, 7, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (105, 7, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (121, 9, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (122, 9, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (123, 9, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (124, 9, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (125, 9, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (126, 9, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (127, 9, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (128, 9, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (129, 9, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (130, 9, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (131, 9, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (132, 9, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (133, 9, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (134, 9, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (135, 9, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (136, 10, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (137, 10, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (138, 10, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (139, 10, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (140, 10, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (141, 10, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (142, 10, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (143, 10, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (144, 10, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (145, 10, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (146, 10, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (147, 10, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (148, 10, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (149, 10, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (150, 10, '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES (151, 8, '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES (152, 8, '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES (153, 8, '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES (154, 8, '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES (155, 8, '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (156, 8, '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES (157, 8, '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES (158, 8, '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES (159, 8, '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES (160, 8, '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES (161, 8, '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES (162, 8, '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES (163, 8, '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES (164, 8, '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES (165, 8, '', '1', '');

-- ----------------------------
-- Table structure for nghiepvu_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_survey`;
CREATE TABLE `nghiepvu_survey`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `hien_trang` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nhu_cau_tin_hoc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ten_nghiep_vu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 166 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nghiepvu_survey
-- ----------------------------
INSERT INTO `nghiepvu_survey` VALUES (1, 1, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (2, 1, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (3, 1, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (4, 1, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (5, 1, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (6, 1, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (7, 1, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (8, 1, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (9, 1, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (10, 1, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (11, 1, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (12, 1, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (13, 1, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (14, 1, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (15, 1, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (16, 2, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (17, 2, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (18, 2, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (19, 2, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (20, 2, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (21, 2, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (22, 2, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (23, 2, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (24, 2, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (25, 2, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (26, 2, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (27, 2, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (28, 2, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (29, 2, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (30, 2, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (31, 3, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (32, 3, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (33, 3, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (34, 3, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (35, 3, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (36, 3, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (37, 3, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (38, 3, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (39, 3, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (40, 3, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (41, 3, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (42, 3, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (43, 3, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (44, 3, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (45, 3, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (46, 4, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (47, 4, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (48, 4, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (49, 4, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (50, 4, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (51, 4, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (52, 4, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (53, 4, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (54, 4, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (55, 4, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (56, 4, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (57, 4, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (58, 4, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (59, 4, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (60, 4, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (61, 5, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (62, 5, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (63, 5, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (64, 5, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (65, 5, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (66, 5, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (67, 5, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (68, 5, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (69, 5, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (70, 5, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (71, 5, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (72, 5, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (73, 5, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (74, 5, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (75, 5, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (76, 6, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (77, 6, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (78, 6, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (79, 6, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (80, 6, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (81, 6, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (82, 6, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (83, 6, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (84, 6, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (85, 6, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (86, 6, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (87, 6, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (88, 6, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (89, 6, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (90, 6, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (91, 7, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (92, 7, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (93, 7, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (94, 7, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (95, 7, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (96, 7, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (97, 7, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (98, 7, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (99, 7, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (100, 7, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (101, 7, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (102, 7, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (103, 7, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (104, 7, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (105, 7, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (121, 9, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (122, 9, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (123, 9, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (124, 9, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (125, 9, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (126, 9, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (127, 9, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (128, 9, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (129, 9, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (130, 9, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (131, 9, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (132, 9, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (133, 9, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (134, 9, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (135, 9, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (136, 10, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (137, 10, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (138, 10, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (139, 10, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (140, 10, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (141, 10, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (142, 10, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (143, 10, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (144, 10, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (145, 10, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (146, 10, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (147, 10, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (148, 10, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (149, 10, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (150, 10, '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES (151, 8, '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES (152, 8, '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES (153, 8, '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES (154, 8, '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES (155, 8, '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES (156, 8, '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES (157, 8, '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES (158, 8, '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES (159, 8, '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES (160, 8, '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES (161, 8, '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES (162, 8, '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES (163, 8, '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES (164, 8, '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES (165, 8, '1', '1', '');

-- ----------------------------
-- Table structure for ungdungcntt_dangtrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_dangtrienkhai`;
CREATE TABLE `ungdungcntt_dangtrienkhai`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_duan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `muctieu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `quymo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tongmucdautu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `noidung` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ghichu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `thoigianthuchien` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ungdungcntt_dangtrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES (1, '', '', 1, '', '', '', '', NULL);
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES (2, '', '', 7, '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES (4, '', '', 9, '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES (5, '', '', 10, '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES (6, '', '', 8, '', '', '', '', '');

-- ----------------------------
-- Table structure for ungdungcntt_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_datrienkhai`;
CREATE TABLE `ungdungcntt_datrienkhai`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phan_mem` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `mo_ta_chung` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `doituongsudung` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nhucau` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nguyennhan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ungdungcntt_datrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_datrienkhai` VALUES (1, '', '', 1, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (2, '', '', 2, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (3, '', '', 3, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (4, '', '', 4, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (5, '', '', 5, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (6, '', '', 6, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (7, '', '', 7, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (9, '', '', 9, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (10, '', '', 10, '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES (11, '', '', 8, '', '', '');

-- ----------------------------
-- Table structure for ungdungcntt_yeucau
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_yeucau`;
CREATE TABLE `ungdungcntt_yeucau`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yeucau` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ungdungdexuat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ungdungcntt_yeucau
-- ----------------------------
INSERT INTO `ungdungcntt_yeucau` VALUES (1, '', '', 1);
INSERT INTO `ungdungcntt_yeucau` VALUES (2, '', '', 2);
INSERT INTO `ungdungcntt_yeucau` VALUES (3, '', '', 3);
INSERT INTO `ungdungcntt_yeucau` VALUES (4, '', '', 5);
INSERT INTO `ungdungcntt_yeucau` VALUES (5, '', '', 6);
INSERT INTO `ungdungcntt_yeucau` VALUES (6, '', '', 7);
INSERT INTO `ungdungcntt_yeucau` VALUES (8, '', '', 9);
INSERT INTO `ungdungcntt_yeucau` VALUES (9, '', '', 10);
INSERT INTO `ungdungcntt_yeucau` VALUES (10, '', '', 8);

-- ----------------------------
-- Table structure for userkhaosat
-- ----------------------------
DROP TABLE IF EXISTS `userkhaosat`;
CREATE TABLE `userkhaosat`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `donvikhaosat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `thoigian` timestamp(0) NULL DEFAULT NULL,
  `so_dien_thoai` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bo_phan_khao_sat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `dai_dien` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `chuc_vu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `danh_sach_chuc_nang_nghiep_vu_file` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `danh_sach_chuc_nang_nghiep_vu_txt` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `kho_khan_nghiep_vu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_dich_vu_truc_tuyen` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_phan_mem_thu_dien_tu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_quy_che_thu_dien_tu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_so_luong_cap_thu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_ty_le_dung_thu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_ty_le_phan_tram_thu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `hai_thu_cong_cong` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `phong_may_chu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `moi_truong_du_phong` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `may_chu_mo_rong` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `may_chu_sao_luu` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `nam_bo_phan_chuyen_trach` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tong_so_cb_chuyen_trach` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tong_so_cb_kiem_nhiem` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tong_so_cntt_kiem_nhiem` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `su_dung_pm_van_phong` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tiensi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `thacsi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `daihoc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `caodang` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `trungcap` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ykien_khokhan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ykien_thuanloi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `ykien_dexuat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of userkhaosat
-- ----------------------------
INSERT INTO `userkhaosat` VALUES (1, 'gdfgdfgdfgdfg', 'fggdfgdf', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (2, 'dfgdfgdfgdfg', 'sdfgsdg', '0000-00-00 00:00:00', 'dfgdfgdfg', 'doxuan_dat@yahoo.com', 'dfgdfg', 'dfgdfg', 'dfgdfg', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (3, 'sdfsdf', 'sdfsdf', '0000-00-00 00:00:00', 'sdfsd', 'fsdfsdf', 'sdffsdf', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (4, 'sdfsdf', 'sdfsdf', '0000-00-00 00:00:00', 'sdfsd', 'fsdfsdf', 'sdffsdf', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (5, 'sdfsdf', 'sdfsdf', '0000-00-00 00:00:00', 'sdfsd', 'fsdfsdf', 'sdffsdf', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (6, 'sdfsdf', 'sdfsdf', '0000-00-00 00:00:00', 'sdfsd', 'fsdfsdf', 'sdffsdf', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (7, 'sdfsdf', 'sdfsdf', '0000-00-00 00:00:00', 'sdfsd', 'fsdfsdf', 'sdffsdf', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (8, 'dfgdfg', 'fgdfg', '0000-00-00 00:00:00', 'dfgdfg', 'doxuan_dat@yahoo.com', 'dsfsdf', 'sdfsdf', 'sdfsdf', '', 'sdfsdfsdfsdfsdf', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (9, 'dfgdfg', 'fgdfg', '0000-00-00 00:00:00', 'dfgdfg', 'doxuan_dat@yahoo.com', 'dsfsdf', 'sdfsdf', 'sdfsdf', '', 'sdfsdfsdfsdfsdf', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES (10, 'sdfsdf', 'dsfsdf', '0000-00-00 00:00:00', 'sdfsdf', 'doxuan_dat@yahoo.com', 'sdfsd', 'sdfsd', 'fsdfsdf', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for v_nhu_cau_dao_tao
-- ----------------------------
DROP TABLE IF EXISTS `v_nhu_cau_dao_tao`;
CREATE TABLE `v_nhu_cau_dao_tao`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_daotao` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `muc_do_uu_tien` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_id_answer` int(11) NULL DEFAULT NULL,
  `soluong_hocvien` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of v_nhu_cau_dao_tao
-- ----------------------------
INSERT INTO `v_nhu_cau_dao_tao` VALUES (1, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (2, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (3, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (4, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (5, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (6, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (7, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (8, '', '', 1, NULL);
INSERT INTO `v_nhu_cau_dao_tao` VALUES (9, 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (10, '', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (11, '', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (12, '', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (13, 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (14, '', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (15, '', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (16, '', '', 7, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (25, 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (26, '', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (27, '', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (28, '', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (29, 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (30, '', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (31, '', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (32, '', '', 9, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (33, 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (34, '', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (35, '', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (36, '', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (37, 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (38, '', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (39, '', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (40, '', '', 10, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (41, 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (42, '', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (43, '', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (44, '', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (45, 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (46, '', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (47, '', '', 8, '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES (48, '', '', 8, '');

SET FOREIGN_KEY_CHECKS = 1;
