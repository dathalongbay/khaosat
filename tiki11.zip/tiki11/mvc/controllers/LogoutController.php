<?php

namespace MVC\Controllers;

use MVC\Models\EmployeeModel;

class LogoutController {


    public function logout() {

        // remove all session variables
        session_unset();

        // destroy the session
        session_destroy();

        header("Location: index.php?controller=beadmin&action=login");
        exit;

    }

}