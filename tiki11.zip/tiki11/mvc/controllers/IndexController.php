<?php

namespace MVC\Controllers;

class IndexController {


    public function index() {

        $nghiepvusDefault = [
            "Quản lý hành chính điện tử - các hệ thống báo cáo số liệu",
            "Quản lý Tuyển sinh",
            "Quản lý Thời khóa biểu – kế hoạch giảng dạy",
            "Quản lý Công tác Sinh viên",
            "Quản lý học vụ",
            "Quản lý khảo thí – Trác nghiệm",
            "Quản lý Tài chính ",
            "Quản lý Lý túc xá",
            "Quản lý Nhân sự thỉnh giảng – Tiền Công",
            "Quản lý Tài sản – Thiết bị",
            "Quản lý nghiên cứu khoa học",
            "kết nối cộng đồng phụ huynh- sinh viên – nhà trường",
            "Hóa đơn điện tử",
            "Quản lý chuyển phát, điều hành xe"
        ];

        include_once "mvc/view/index/index.php";
    }
}