<?php

namespace MVC\Controllers;

use MVC\Models\EmployeeModel;

class BequestionController {


    public function indexAction() {


        /*
         * câu hỏi
         * id
         * question
         * create
         * edit
         * status
         *
         * câu trả lời mới khó
         * 
         *
         *
         */
    }




}