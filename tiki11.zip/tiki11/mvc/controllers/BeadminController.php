<?php

namespace MVC\Controllers;

use MVC\Models\EmployeeModel;

class BeadminController {

    public function __construct()
    {

    }


    public function index() {
        if (!isset($_SESSION["loggedin"])) {
            header("Location: index.php?controller=beadmin&action=login");
            exit;
        }

        include_once "mvc/view/beadmin/index.php";
    }


    public function login() {
        include_once "mvc/view/beadmin/login.php";
    }


    public function logged() {
        $errors = [];

        echo "<pre>";
        print_r($_POST);
        echo "</pre>";
        if (isset($_POST) && !empty($_POST)) {

            if (!isset($_POST["username"]) || empty($_POST["username"])) {
                $errors[] = "Chưa nhập username";
            }
            if (!isset($_POST["password"]) || empty($_POST["password"])) {
                $errors[] = "Chưa nhập password";
            }

            /**
             * Nếu mảng $errors bị rỗng tức là không có lỗi đăng nhập
             */
            if (is_array($errors) && empty($errors)) {

                $connection = new \PDO("mysql:host=localhost;dbname=tiki1", "root", "");
                // set the PDO error mode to exception
                $connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

                $username = $_POST["username"];
                $password = md5($_POST["password"]);

                $sqlLogin = "SELECT * FROM admin WHERE username = ? AND password = ?";

                $stmt = $connection->prepare($sqlLogin);
                $stmt->execute([$username,$password]);

                // set the resulting array to associative
                $stmt->setFetchMode(\PDO::FETCH_ASSOC);
                $results = $stmt->fetchAll();
                $res = isset($results[0]) ? $results[0] : [];




                if (isset($res['id']) && ($res['id'] > 0)) {

                    /**
                     * Nếu tồn tại bản ghi
                     * thì sẽ tạo ra session đăng nhập
                     */
                    $_SESSION["loggedin"] = true;
                    $_SESSION["username"] = $res['username'];

                    header("Location: index.php?controller=beadmin&action=index");
                    exit;
                } else {
                    $errors[] = "Dữ liệu đăng nhập không đúng";

                    header("Location: index.php?controller=beadmin&action=login");
                    exit;
                }

            }

        }
    }





}