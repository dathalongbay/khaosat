<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo BASE_URL ?>template/backend/sbadmin/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content" >



            <!-- Begin Page Content -->
            <div class="container-fluid" style="padding-top: 50px">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Thông tin khảo sát</h1>

                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Thông tin khảo sát</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <form name="survey" method="post" action="<?php echo BASE_URL."index.php?controller=besurvey&action=store" ?>">
                                <div class="form-group">
                                    <label>Đơn vị được khảo sát:</label>
                                    <input type="text" required class="form-control" name="donvikhaosat" value="">
                                </div>
                                <div class="form-group">
                                    <label>Cán bộ thực hiện khảo sát:</label>
                                    <input type="text" required class="form-control" name="ten" value="">
                                </div>
                                <div class="form-group">
                                    <label>Số điện thoại:</label>
                                    <input type="text" class="form-control" name="so_dien_thoai" value="">
                                </div>
                                <div class="form-group">
                                    <label>Email:</label>
                                    <input type="text" class="form-control" name="email" value="">
                                </div>

                                <div class="form-group">
                                    <label>Cán bộ khảo sát thuộc bộ phận:</label>
                                    <input type="text" class="form-control" name="bo_phan_khao_sat" value="">
                                </div>
                                <div class="form-group">
                                    <label>Đại diện đơn vị khảo sát:</label>
                                    <input type="text" class="form-control" name="dai_dien" value="">
                                </div>
                                <div class="form-group">
                                    <label>Chức vụ:</label>
                                    <input type="text" class="form-control" name="chuc_vu" value="">
                                </div>
                                <div class="form-group">
                                    <label>Thời gian thực hiện khảo sát:</label>
                                    <input type="text" class="form-control" name="thoigian" value="">
                                </div>

                                <div>
                                    <h2>A. MỤC TIÊU CỦA TÀI LIỆU</h2>
                                    - Khảo sát về hiện trạng ứng dụng phần mềm quản lý và hạ tầng kỹ thuật CNTT, các hệ thống ứng dụng CNTT, các dòng nghiệp vụ/nghiệp vụ, thủ tục hành chính cùng các yêu cầu, đề xuất, kiến nghị (nếu có) tại các cơ sở giáo dục thuộc Bộ Văn hóa Thể thao và Du lịch
                                    - Các thông tin thu thập được qua phiếu khảo sát (bao gồm cả các tài liệu do Đơn vị được khảo sát cung cấp) sẽ được tổng hợp, phân tích, đánh giá chi tiết để làm cơ sở xây dựng Kiến trúc hệ thống phầm mềm quản trị tích hợp của Bộ
                                    <h2>B.	NỘI DUNG KHẢO SÁT</h2>

                                    <h3>I.	KHẢO SÁT VỀ NGHIỆP VỤ</h3>
                                    1. Quý đơn vị vui lòng cung cấp danh sách các chức năng nhiệm vụ, nghiệp vụ đang có hiệu lực hoặc chuẩn bị có hiệu lực (nếu có) của Quý đơn vị? (cán bộ làm khảo sát có thể mô tả xuống dưới hoặc chọn chức năng tải văn bản lên
                                    <div class="form-group">
                                        <label>Tải văn bản lên:</label>
                                        <input type="file" name="danh_sach_chuc_nang_nghiep_vu_file">
                                    </div>

                                    hoặc mô tả dưới đây :

                                    <div class="form-group">
                                        <textarea name="danh_sach_chuc_nang_nghiep_vu_txt" class="form-control" rows="5"></textarea>
                                    </div>
                                    2. Toàn bộ các chức năng nghiệp vụ do Quý đơn vị cung cấp đã được tin học hóa thành phần mềm quản trị chưa? Nếu có, vui lòng chuyển sang mục
                                    3. Nếu chưa, xin vui lòng cung cấp các thông tin sau

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Tên nghiệp vụ quản trị</th>
                                            <th>Hiện trạng tin học hóa</th>
                                            <th>Nhu cầu tin học hóa</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $i1 = 1;
                                        foreach($nghiepvusDefault as $nghiepvusDefaultItem) : ?>
                                            <tr>
                                                <td><?php echo $i1 ?></td>
                                                <td>
                                                    <?php echo $nghiepvusDefaultItem ?>
                                                    <textarea style="display: none" name="nghiepvu[ten_nghiep_vu][]" class="form-control" rows="5"><?php echo $nghiepvusDefaultItem ?></textarea>
                                                </td>
                                                <td>
                                                    <select name="nghiepvu[hien_trang][]" class="form-control">
                                                        <option value="1">Chưa tin học hóa</option>
                                                        <option value="2">Đã tin học hóa</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select name="nghiepvu[nhu_cau_tin_hoc][]" class="form-control">
                                                        <option value="1">Cao</option>
                                                        <option value="2">Bình thường</option>
                                                        <option value="3">Thấp</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <?php $i1++; ?>
                                        <?php endforeach; ?>


                                        <tr>
                                            <td>
                                                <span class="tr-idx"><?php echo $i1; ?></span> <br>
                                                <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>
                                            </td>
                                            <td>
                                                <textarea name="nghiepvu[ten_nghiep_vu][]" class="form-control" rows="5"></textarea>
                                            </td>
                                            <td>
                                                <select name="nghiepvu[hien_trang][]" class="form-control">
                                                    <option value="1">Chưa tin học hóa</option>
                                                    <option value="2">Đã tin học hóa</option>
                                                </select>
                                            </td>
                                            <td>
                                                <select name="nghiepvu[nhu_cau_tin_hoc][]" class="form-control">
                                                    <option value="1">Cao</option>
                                                    <option value="2">Bình thường</option>
                                                    <option value="3">Thấp</option>
                                                </select>
                                            </td>
                                        </tr>


                                        <tr>
                                            <td colspan="4" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="1a1" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>


                                        </tbody>
                                    </table>

                                    3. Quý đơn vị vui lòng cung cấp thông tin hiện trạng liên thông phối hợp từ các bộ phận liên quan trong chuỗi quy trình nghiệp vụ quản lý có nhu cầu tin học hóa theo các nội dung sau đây.

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Tên nghiệp vụ</th>
                                            <th>Cơ quan/bộ phận liên quan</th>
                                            <th>Mô tả hiện trạng tin học hóa</th>
                                            <th>Nhu cầu tin học hóa việc liên thông nghiệp vụ</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        $i2 = 1;
                                        foreach($nghiepvusDefault as $nghiepvusDefaultItem) : ?>
                                            <tr>
                                                <td><?php echo $i2 ?></td>
                                                <td>
                                                    <?php echo $nghiepvusDefaultItem ?>
                                                    <textarea style="display: none" name="nghiepvulienthong[ten_nghiep_vu][]" class="form-control" rows="5"><?php echo $nghiepvusDefaultItem ?></textarea>
                                                </td>
                                                <td><textarea name="nghiepvulienthong[coquan][]" class="form-control" rows="5"></textarea></td>
                                                <td><select name="nghiepvulienthong[hien_trang][]" class="form-control">
                                                        <option value="1">Tin học hóa</option>
                                                        <option value="2">Thủ công</option>
                                                    </select></td>
                                                <td><select name="nghiepvulienthong[nhu_cau_tin_hoc][]" class="form-control">
                                                        <option value="1">Cao</option>
                                                        <option value="2">Bình thường</option>
                                                        <option value="3">Thấp</option>
                                                    </select></td>
                                            </tr>
                                            <?php $i2++; ?>
                                        <?php endforeach; ?>


                                        <tr>
                                            <td><?php echo $i2; ?></td>
                                            <td><textarea name="nghiepvulienthong[ten_nghiep_vu][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nghiepvulienthong[coquan][]" class="form-control" rows="5"></textarea></td>
                                            <td><select name="nghiepvulienthong[hien_trang][]" class="form-control">
                                                    <option value="1">Tin học hóa</option>
                                                    <option value="2">Thủ công</option>
                                                </select></td>
                                            <td><select name="nghiepvulienthong[nhu_cau_tin_hoc][]" class="form-control">
                                                    <option value="1">Cao</option>
                                                    <option value="2">Bình thường</option>
                                                    <option value="3">Thấp</option>
                                                </select></td>
                                        </tr>


                                        <tr>
                                            <td colspan="5" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="1a2" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>


                                    4. Quý đơn vị vui lòng nêu khó khăn, bất cập liên quan đến công tác quản lý, hoặc sự phối hợp với các cơ quan liên quan trong việc xử lý các nghiệp vụ liên thông với các đơn vị khác? Nguyên nhân gây ra các khó khăn, bất cập?
                                    <div class="form-group">
                                        <textarea name="kho_khan_nghiep_vu" class="form-control" rows="5" placeholder="VD: Quản lý còn rời rạc, việc liên kết giữa các phòng ban chưa chặt chẽ…"></textarea>
                                    </div>

                                    5. Quý đơn vị vui lòng cung cấp các thông tin của các lĩnh vực nghiệp vụ nội bộ trong bảng sau?
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Tên nghiệp vụ</th>
                                            <th>Tình trạng tin học hóa</th>
                                            <th>Nhu cầu đầu tư</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                        $i3 = 1;
                                        foreach($nghiepvusDefault as $nghiepvusDefaultItem) : ?>

                                            <tr>
                                                <td><?php echo $i3; ?></td>
                                                <td>
                                                    <?php echo $nghiepvusDefaultItem ?>
                                                    <textarea style="display: none" name="nghiepvunoibo[ten_nghiep_vu][]" class="form-control" rows="5"><?php echo $nghiepvusDefaultItem ?></textarea></td>
                                                <td><textarea name="nghiepvunoibo[hien_trang][]" class="form-control" rows="5" placeholder="Mô tả tóm tắt về hiện trạng ứng dụng CNTT để thực hiện các nghiệp vụ này. Nếu chưa, ghi “Chưa đầu tư ứng dụng CNTT”."></textarea></td>
                                                <td><select name="nghiepvunoibo[nhu_cau_tin_hoc][]" class="form-control">
                                                        <option value="1">Có</option>
                                                        <option value="2">Không</option>
                                                        <option value="3">Cần nâng cấp, bổ sung</option>
                                                    </select></td>
                                            </tr>
                                            <?php $i3++; ?>
                                        <?php endforeach; ?>

                                        <tr>
                                            <td><?php echo $i3; ?></td>
                                            <td><textarea name="nghiepvunoibo[ten_nghiep_vu][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nghiepvunoibo[hien_trang][]" class="form-control" rows="5" placeholder="Mô tả tóm tắt về hiện trạng ứng dụng CNTT để thực hiện các nghiệp vụ này. Nếu chưa, ghi “Chưa đầu tư ứng dụng CNTT”."></textarea></td>
                                            <td><select name="nghiepvunoibo[nhu_cau_tin_hoc][]" class="form-control">
                                                    <option value="1">Có</option>
                                                    <option value="2">Không</option>
                                                    <option value="3">Cần nâng cấp, bổ sung</option>
                                                </select></td>
                                        </tr>

                                        <tr>
                                            <td colspan="5" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="1a3" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>


                                        </tbody>
                                    </table>

                                    <h3>II.	KHẢO SÁT VỀ CÁC ỨNG DỤNG CNTT</h3>

                                    1. Quý đơn vị cung cấp các thông tin dịch vụ trực tuyến đối với sinh viên – học viên thông qua các kênh truy cập hoặc công cụ nào (ví dụ: Cổng thông tin điện tử của trường/Trang thông tin điện tử)? Xin vui lòng cung cấp địa chỉ hoặc đường dẫn.
                                    <div class="form-group">
                                        <textarea name="hai_dich_vu_truc_tuyen" class="form-control" rows="5"></textarea>
                                    </div>

                                    2. Quý đơn vị có hệ thống Thư điện tử dùng riêng không? Nếu có, xin vui lòng trả lời thêm một số câu hỏi sau:
                                    <br>
                                    Tên phần mềm Thư điện tử đang sử dụng:
                                    <div class="form-group">
                                        <input name="hai_phan_mem_thu_dien_tu" class="form-control" value="">
                                    </div>
                                    -	Đơn vị đã có quy chế sử dụng hệ thống thư điện tử chưa?
                                    <div class="form-group">
                                        <input name="hai_quy_che_thu_dien_tu" class="form-control" value="">
                                    </div>
                                    -	Tổng số cán bộ, đã được cấp hộp thư điện tử:
                                    <div class="form-group">
                                        <input name="hai_so_luong_cap_thu" class="form-control" value="">
                                    </div>
                                    -	Tỷ lệ cán bộ sử dụng hệ thống thư điện tử:
                                    <div class="form-group">
                                        <input name="hai_ty_le_dung_thu" class="form-control" value="">
                                    </div>
                                    -	Tỷ lệ % văn bản được trao đổi qua hệ thống thư điện tử: …%.
                                    <div class="form-group">
                                        <input name="hai_ty_le_phan_tram_thu" class="form-control" value="">
                                    </div>
                                    Ngoài thư điện tử công vụ, Quý đơn vị có sử dụng thư điện tử công cộng (Gmail, Yahoo, Hotmail…) để trao đổi, làm việc không?
                                    <div class="form-group">
                                        <input name="hai_thu_cong_cong" class="form-control" value="">
                                    </div>
                                    3. Quý đơn vị vui lòng cung cấp thông tin về các ứng dụng CNTT đã triển khai theo  bảng sau.

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Tên phần mềm</th>
                                            <th>Mô tả chung</th>
                                            <th>Đối tượng sử dụng</th>
                                            <th>Nhu cầu sửa đổi, nâng cấp</th>
                                            <th>Nguyên nhân</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><textarea name="udcnttdatrienkhai[ten_phan_mem][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdatrienkhai[mo_ta_chung][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdatrienkhai[doituongsudung][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdatrienkhai[nhucau][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdatrienkhai[nguyennhan][]" class="form-control" rows="5"></textarea></td>
                                        </tr>

                                        <tr>
                                            <td colspan="6" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="2a1" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>

                                    4. Quý đơn vị vui lòng cung cấp các thông tin về nhu cầu ứng dụng CNTT để xử lý các yêu cầu nghiệp vụ tại Quý đơn vị theo bảng sau theo thứ tự ưu tiên từ trên xuống dưới.
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Yêu cầu ứng dụng CNTT</th>
                                            <th>Tên ứng dụng đề xuất</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><textarea name="udcnttyeucau[yeucau][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttyeucau[ungdungdexuat][]" class="form-control" rows="5"></textarea></td>
                                        </tr>

                                        <tr>
                                            <td colspan="3" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="2a2" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>

                                    5. Quý đơn vị vui lòng cung cấp thông tin về các dự án ứng dụng CNTT đang triển khai (bao gồm cả các dự án đang trong giai đoạn chuẩn bị đầu tư) theo bảng sau? (Bỏ qua nếu không có)

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Tên dự án</th>
                                            <th>Mục tiêu tổng quát</th>
                                            <th>Quy mô</th>
                                            <th>Tổng mức đầu tư</th>
                                            <th>Nội dung thực hiện</th>
                                            <th>Thời gian thực hiện dự kiến</th>
                                            <th>Ghi chú</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><textarea name="udcnttdangtrienkhai[ten_duan][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdangtrienkhai[muctieu][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdangtrienkhai[quymo][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdangtrienkhai[tongmucdautu][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdangtrienkhai[noidung][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdangtrienkhai[thoigianthuchien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="udcnttdangtrienkhai[ghichu][]" class="form-control" rows="5"></textarea></td>
                                        </tr>

                                        <tr>
                                            <td colspan="7" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="2a3" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>

                                    <h3>III.	KHẢO SÁT VỀ CƠ SỞ DỮ LIỆU</h3>
                                    1. Quý đơn vị vui lòng cung cấp thông tin về các các CSDL đã được triển khai tại Quý đơn vị theo bảng sau.

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Tên cơ sở dữ liệu</th>
                                            <th>Hệ quản trị cơ sở dữ liệu</th>
                                            <th>Tình trạng bản quyền</th>
                                            <th>Năm đầu tư</th>
                                            <th>Hệ điều hành cài đặt CSDL</th>
                                            <th>Nhu cầu nâng cấp, sửa đổi</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><textarea name="csdldatrienkhai[ten_csdl][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdldatrienkhai[he_csdl][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdldatrienkhai[ban_quyen][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdldatrienkhai[nam_dau_tu][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdldatrienkhai[he_dieu_hanh][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdldatrienkhai[nhucau][]" class="form-control" rows="5"></textarea></td>
                                        </tr>

                                        <tr>
                                            <td colspan="7" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="3a1" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                    2. Quý đơn vị vui lòng cung cấp các thông tin về việc trao đổi, chia sẻ dữ liệu hiện nay theo bảng sau.

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Lĩnh vực nghiệp vụ</th>
                                            <th>Đơn vị liên quan</th>
                                            <th>Thông tin, dữ liệu trao đổi</th>
                                            <th>Tần suất trao đổi</th>
                                            <th>Phương thức trao đổi</th>
                                            <th>Ghi chú</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><textarea name="csdltraodoi[linh_vuc][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdltraodoi[don_vi_lien_quan][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdltraodoi[thong_tin_trao_doi][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdltraodoi[tan_suat][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdltraodoi[phuong_thuc][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="csdltraodoi[ghi_chu][]" class="form-control" rows="5"></textarea></td>
                                        </tr>

                                        <tr>
                                            <td colspan="7" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="3a2" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>

                                    <h3>IV.	HẠ TẦNG KỸ THUẬT CNTT </h3>

                                    1. Quý đơn vị đã có Trung tâm dữ liệu hoặc phòng máy chủ chưa?

                                    <div class="form-group">
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="phong_may_chu" value="1">Có
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="phong_may_chu" value="2">Không
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="phong_may_chu" value="3">Đang đầu từ
                                            </label>
                                        </div>
                                    </div>

                                    Nếu có: <br>
                                    a) Trung tâm dữ liệu hoặc phòng máy chủ đó có môi trường dự phòng không?

                                    <div class="form-group">
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="moi_truong_du_phong" value="1">Có
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="moi_truong_du_phong" value="2">Không
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="moi_truong_du_phong" value="3">Đang đầu từ
                                            </label>
                                        </div>
                                    </div>

                                    b) Trung tâm dữ liệu hoặc phòng máy chủ có khả năng mở rộng hoặc lắp đặt các thiết bị mới không?

                                    <div class="form-group">
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="may_chu_mo_rong" value="1">Có
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="may_chu_mo_rong" value="2">Không
                                            </label>
                                        </div>
                                    </div>

                                    2. Quý đơn vị vui lòng cung cấp các thông tin về các máy chủ vật lý hiện có.

                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Model</th>
                                            <th>Số lượng</th>
                                            <th>Thông số kỹ thuật</th>
                                            <th>Năm đầu tư</th>
                                            <th>Tình trạng</th>
                                            <th>Ghi chú</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><textarea name="maychuvatly[model][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="maychuvatly[soluong][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="maychuvatly[thong_so][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="maychuvatly[nam_dau_tu][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="maychuvatly[tinh_trang][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="maychuvatly[ghi_chu][]" class="form-control" rows="5"></textarea></td>
                                        </tr>

                                        <tr>
                                            <td colspan="7" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="4a1" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>

                                    3. Quý đơn vị có trang bị hệ thống lưu trữ, sao lưu dữ liệu không?

                                    <div class="form-group">
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="may_chu_sao_luu" value="1">Có
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="may_chu_sao_luu" value="2">Không
                                            </label>
                                        </div>
                                    </div>

                                    <h3>V.	NGUỒN NHÂN LỰC VÀ NHU CẦU ĐÀO TẠO</h3>
                                    1. Quý đơn vị vui lòng trả lời các câu hỏi về nguồn nhân lực theo bảng sau.
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Nội dung</th>
                                            <th>Trả lời</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Đơn vị có bộ phận chuyên trách CNTT không?</td>
                                            <td><textarea name="nam_bo_phan_chuyen_trach" class="form-control" rows="5"></textarea></td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>Tổng số cán bộ chuyên trách CNTT (nếu có)</td>
                                            <td><textarea name="tong_so_cb_chuyen_trach" class="form-control" rows="5"></textarea></td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Tổng số cán bộ khác kiêm nhiệm cán bộ CNTT (nếu có)</td>
                                            <td><textarea name="tong_so_cb_kiem_nhiem" class="form-control" rows="5"></textarea></td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td>Tổng số cán bộ CNTT kiêm nhiệm vị trí khác (nếu có)</td>
                                            <td><textarea name="tong_so_cntt_kiem_nhiem" class="form-control" rows="5"></textarea></td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td>Thống kê trình độ các cán bộ có bằng cấp trình độ về CNTT?</td>
                                            <td>
                                                <p>Tiến sĩ <input name="tiensi" class="form-control" style="width: 100px; display: inline-block" value=""> cán bộ</p>
                                                <p>Thạc sĩ <input name="thacsi" class="form-control" style="width: 100px; display: inline-block" value=""> cán bộ</p>
                                                <p>Đại học hoặc tương đương <input name="daihoc" class="form-control" style="width: 100px; display: inline-block" value=""> cán bộ</p>
                                                <p>Cao đẳng <input name="caodang" class="form-control" style="width: 100px; display: inline-block" value=""> cán bộ</p>
                                                <p>Trung cấp <input name="trungcap" class="form-control" style="width: 100px; display: inline-block" value=""> cán bộ</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>6</td>
                                            <td>Các cán bộ hiện đang công tác Quý đơn vị đã sử dụng thành thạo các phần mềm văn phòng, hệ thống ứng dụng CNTT, CSDL chuyên ngành để xử lý công việc không?</td>
                                            <td><textarea name="su_dung_pm_van_phong" class="form-control" rows="5"></textarea></td>
                                        </tr>
                                        </tbody>
                                    </table>

                                    2. Quý đơn vị vui lòng cung cấp thông tin về nhu cầu đào tạo theo bảng sau.
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>TT</th>
                                            <th>Nội dung đào tạo</th>
                                            <th>Số lượng học viên dự kiến</th>
                                            <th>Mức độ ưu tiên</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>I</td>
                                            <td>
                                                Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ
                                                <textarea style="display: none" name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5">Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ</textarea>
                                            </td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr> <tr>
                                            <td></td>
                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr> <tr>
                                            <td></td>
                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr>
                                        <tr>
                                            <td colspan="4" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="5a1" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>II</td>
                                            <td>
                                                Đào tạo, bồi dưỡng nâng cao trình độ CNTT
                                                <textarea style="display: none" name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5">Đào tạo, bồi dưỡng nâng cao trình độ CNTT</textarea>
                                            </td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr><tr>
                                            <td></td>
                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr><tr>
                                            <td></td>
                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>
                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>

                                        </tr>
                                        <tr>
                                            <td colspan="4" style="text-align: center">
                                                <a class="btn btn-success add-control-dx" data-dx="5a2" style="color: white">Thêm +</a></td>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>

                                    <h3>VI.	CÁC Ý KIẾN, KIẾN NGHỊ VÀ ĐỀ XUẤT</h3>

                                    1. Khó khăn, vướng mắc

                                    <div class="form-group">
                                        <textarea name="ykien_khokhan" class="form-control" rows="5"></textarea>
                                    </div>

                                    2. Các thuận lợi

                                    <div class="form-group">
                                        <textarea name="ykien_thuanloi" class="form-control" rows="5"></textarea>
                                    </div>

                                    3. Các đề xuất, kiến nghị và ý kiến khác (nếu có)

                                    <div class="form-group">
                                        <textarea name="ykien_dexuat" class="form-control" rows="5"></textarea>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">Nộp khảo sát</button>
                                <button type="submit" class="btn btn-primary">Chỉ lưu</button>

                            </form>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2019</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="login.html">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/js/demo/datatables-demo.js"></script>

<script type="text/javascript">

    $("body").on("click", ".dx-del", function (e) {
        e.preventDefault();

        var t = $(this);
        var tb = $(this).closest("table");
        var tr = t.closest("tr");
        tr.remove();

        tb.find("tr").each(function(a,b){
            $(this).find('span.tr-idx').text(a);
        });
    });

    $("body").on("click", ".add-control-dx", function (e) {
        e.preventDefault();

        if ($(this).data("dx") == "4a1") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '        <td> <span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a> </td>\n' +
                '        <td><textarea name="maychuvatly[model][]" class="form-control" rows="5"></textarea></td>\n' +
                '        <td><textarea name="maychuvatly[soluong][]" class="form-control" rows="5"></textarea></td>\n' +
                '        <td><textarea name="maychuvatly[thong_so][]" class="form-control" rows="5"></textarea></td>\n' +
                '        <td><textarea name="maychuvatly[nam_dau_tu][]" class="form-control" rows="5"></textarea></td>\n' +
                '        <td><textarea name="maychuvatly[tinh_trang][]" class="form-control" rows="5"></textarea></td>\n' +
                '        <td><textarea name="maychuvatly[ghi_chu][]" class="form-control" rows="5"></textarea></td>\n' +
                '        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

        if ($(this).data("dx") == "3a1") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="csdldatrienkhai[ten_csdl][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdldatrienkhai[he_csdl][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdldatrienkhai[ban_quyen][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdldatrienkhai[nam_dau_tu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdldatrienkhai[he_dieu_hanh][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdldatrienkhai[nhucau][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

        if ($(this).data("dx") == "3a2") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="csdltraodoi[linh_vuc][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdltraodoi[don_vi_lien_quan][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdltraodoi[thong_tin_trao_doi][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdltraodoi[tan_suat][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdltraodoi[phuong_thuc][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="csdltraodoi[ghi_chu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

        if ($(this).data("dx") == "2a1") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="udcnttdatrienkhai[ten_phan_mem][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdatrienkhai[mo_ta_chung][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdatrienkhai[doituongsudung][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdatrienkhai[nhucau][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdatrienkhai[nguyennhan][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

        if ($(this).data("dx") == "2a2") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="udcnttyeucau[yeucau][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttyeucau[ungdungdexuat][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

        if ($(this).data("dx") == "2a3") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[ten_duan][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[muctieu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[quymo][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[tongmucdautu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[noidung][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[thoigianthuchien][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="udcnttdangtrienkhai[ghichu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }


        if ($(this).data("dx") == "1a1") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                                <td>\n' +
                '                                                    <span class="tr-idx">'+trNum+'</span> <br>\n' +
                '                                                    <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                                </td>\n' +
                '                                                <td>\n' +
                '                                                    <textarea name="nghiepvu[ten_nghiep_vu][]" class="form-control" rows="5"></textarea>\n' +
                '                                                </td>\n' +
                '                                                <td>\n' +
                '                                                    <select name="nghiepvu[hien_trang][]" class="form-control">\n' +
                '                                                        <option value="1">Chưa tin học hóa</option>\n' +
                '                                                        <option value="2">Đã tin học hóa</option>\n' +
                '                                                    </select>\n' +
                '                                                </td>\n' +
                '                                                <td>\n' +
                '                                                    <select name="nghiepvu[nhu_cau_tin_hoc][]" class="form-control">\n' +
                '                                                        <option value="1">Cao</option>\n' +
                '                                                        <option value="2">Bình thường</option>\n' +
                '                                                        <option value="3">Thấp</option>\n' +
                '                                                    </select>\n' +
                '                                                </td>\n' +
                '                                            </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }


        if ($(this).data("dx") == "1a2") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = ' <tr>\n' +
                '                                            <td><span class="tr-idx">'+trNum+'</span> <br>' +'\n' +
                '                                                                   <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="nghiepvulienthong[ten_nghiep_vu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="nghiepvulienthong[coquan][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><select name="nghiepvulienthong[hien_trang][]" class="form-control">\n' +
                '                                                    <option value="1">Tin học hóa</option>\n' +
                '                                                    <option value="2">Thủ công</option>\n' +
                '                                                </select></td>\n' +
                '                                            <td><select name="nghiepvulienthong[nhu_cau_tin_hoc][]" class="form-control">\n' +
                '                                                    <option value="1">Cao</option>\n' +
                '                                                    <option value="2">Bình thường</option>\n' +
                '                                                    <option value="3">Thấp</option>\n' +
                '                                                </select></td>\n' +
                '                                        </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }


        if ($(this).data("dx") == "1a3") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                                <td><span class="tr-idx">'+trNum+'</span> <br> <a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                                <td><textarea name="nghiepvunoibo[ten_nghiep_vu][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                                <td><textarea name="nghiepvunoibo[hien_trang][]" class="form-control" rows="5" placeholder="Mô tả tóm tắt về hiện trạng ứng dụng CNTT để thực hiện các nghiệp vụ này. Nếu chưa, ghi “Chưa đầu tư ứng dụng CNTT”."></textarea></td>\n' +
                '                                                <td><select name="nghiepvunoibo[nhu_cau_tin_hoc][]" class="form-control">\n' +
                '                                                        <option value="1">Có</option>\n' +
                '                                                        <option value="2">Không</option>\n' +
                '                                                        <option value="3">Cần nâng cấp, bổ sung</option>\n' +
                '                                                    </select></td>\n' +
                '                                            </tr>';
            var pos = $(this).closest("tr").before(dxhtml);
        }


        if ($(this).data("dx") == "5a1") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

        if ($(this).data("dx") == "5a2") {
            var trNum = $(this).closest("table").find("tr").length-1;
            var dxhtml = '<tr>\n' +
                '                                            <td><a class="btn btn-danger dx-del" style="color: white">Xóa</a></td>\n' +
                '                                            <td><textarea name="nhucaudaotao[noidung_daotao][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="nhucaudaotao[soluong_hocvien][]" class="form-control" rows="5"></textarea></td>\n' +
                '                                            <td><textarea name="nhucaudaotao[muc_do_uu_tien][]" class="form-control" rows="5" placeholder="VD : Cao/Bình thường/Thấp"></textarea></td>';
            var pos = $(this).closest("tr").before(dxhtml);
        }

    });
</script>

</body>

</html>
