<?php
namespace MVC\Models;

class Database {

    public $connection;

    const DATABASE_SERVER = "localhost";

    const DATABASE_USER = "root";

    const DATABASE_PASSWORD = "";

    const DATABASE_NAME = "tiki1";


    public function __construct()
    {
        /**
         * !$this->connection
         * Khi chưa có kết nối đến CSDL
         */
        if (!$this->connection) {
           /* $this->connection = mysqli_connect(self::DATABASE_SERVER, self::DATABASE_USER,
                self::DATABASE_PASSWORD, self::DATABASE_NAME);*/

            $servername = self::DATABASE_SERVER;
            $username = self::DATABASE_USER;
            $password = self::DATABASE_PASSWORD;
            $db = self::DATABASE_NAME;
            try {
                $this->connection = new \PDO("mysql:host=$servername;dbname=$db", $username, $password);
                // set the PDO error mode to exception
                $this->connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                echo "Connected successfully";
            }
            catch(\PDOException $e)
            {
                echo "Connection failed: " . $e->getMessage();
            }
        }

    }
}