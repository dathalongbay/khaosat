<?php

namespace MVC\Controllers;

use MVC\Models\EmployeeModel;

class BeadminController {


    public function indexAction() {

    }


    public function loginAction() {

    }


    public function logoutAction() {

    }

}