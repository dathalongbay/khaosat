<?php
/**
 * Created by PhpStorm.
 * User: T3H
 * Date: 6/11/2019
 * Time: 6:34 PM
 */

echo "<br>" . __FILE__;