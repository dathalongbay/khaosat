<?php
session_start();

/*ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);*/

define("ADMIN_PHONE", "0977565104");
define("QUYDINH_KS", "
Nếu có khó khăn vui lòng liên hệ số điện thoại <strong>0977565104</strong> để được giúp đỡ <br>
1. Cán bộ thực hiện khảo sát lựa chọn đơn vị mình phụ trách
<br>
2. Điền đầy đủ thông tin sau đó click và nút “Thực hiện khảo sát”. Lưu ý: Bắt buộc phải điền vào các ô bắt buộc (*)
<br>
3. Sau khi hoàn thành tất cả các câu hỏi khảo sát. Cán bộ thực hiện khảo sát click vào nút “Hoàn thành khảo sát” hệ thống sẽ tự động gửi dữ liệu về cơ quan bộ.
<br>
4. Để xem lại và chỉnh sửa  nội dung khảo sát click và nút “Chỉnh sửa lại khảo sát”. Để hoàn thành thực hiện theo thao tác mục 3.
");

define("BASE_PATH", dirname(__FILE__));
define("BASE_URL", "http://localhost/tiki/");

$danh_sach_truong_dh_const = [
    "1" => "Học viện Âm nhạc quốc gia Việt Nam",
    "2" => "Nhạc viện Thành phố Hồ Chí Minh",
    "3" => "Học viện Âm nhạc Huế",
    "4" => "Trường Đại học Văn hóa Hà Nội",
    "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
    "6" => "Trường Đại học Mỹ thuật Việt Nam",
    "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
    "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
    "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
    "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
    "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
    "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
    "13" => "Học viện Múa Việt Nam",
    "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
    "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
    "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
    "17" => "Trường Cao đẳng Du lịch Hà Nội",
    "18" => "Trường Cao đẳng Du lịch Hải Phòng",
    "19" => "Trường Cao đẳng Du lịch Huế",
    "20" => "Trường Cao đẳng Du lịch Nha Trang",
    "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
    "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
    "23" => "Trường Cao đẳng Du lịch Đà Lạt",
    "24" => "Trường Cao đẳng Du lịch Cần Thơ",
    "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
    "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
];

require 'vendor/autoload.php';
include_once "mvc/route.php";
include_once "mvc/models/Database.php";
include_once "mvc/models/SurveyModel.php";
include_once "mvc/controllers/BeadminController.php";
include_once "mvc/controllers/LogoutController.php";
include_once "mvc/controllers/BesurveyController.php";
include_once "mvc/controllers/IndexController.php";
include_once "mvc/controllers/ErrorController.php";

$route = new \MVC\Route();

$route->run();

