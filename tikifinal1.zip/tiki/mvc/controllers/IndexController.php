<?php

namespace MVC\Controllers;

use MVC\Models\SurveyModel;

class IndexController {

    public function uploadFile() {

        $target_dir = "uploadstla/";
        $target_file = $target_dir . "dxa" . time() .basename($_FILES["danh_sach_chuc_nang_nghiep_vu_file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $imageFileMimeAccept = ["image/jpeg", "image/gif", "image/png"];
        $imageFileAccept = ["doc", "docx"];
        $errorUpload = [];

        if(isset($_POST["submit"]) && isset($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']) && !empty($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name'])) {

            $mimetype = mime_content_type($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']);
            if(!in_array($mimetype, $imageFileMimeAccept)) {
                $errorUpload[] = "Kiểu file không hợp lệ chỉ upload file đuôi .doc hoặc .docx";
                $uploadOk = 0;
            }
        }

        if ($_FILES["danh_sach_chuc_nang_nghiep_vu_file"]["size"] > 20000000) {
            $errorUpload[] = "Kích cỡ file quá lớn vui lòng chỉ upload tối đa 16MB";
            $uploadOk = 0;
        }

        if(!in_array($imageFileType, $imageFileAccept)) {
            $errorUpload[] = "Kiểu file không hợp lệ chỉ upload file đuôi .doc hoặc .docx";
            $uploadOk = 0;
        }

        if ($uploadOk == 1) {
            if (!move_uploaded_file($_FILES["danh_sach_chuc_nang_nghiep_vu_file"]["tmp_name"], $target_file)) {
                $errorUpload[] = "Xảy ra lỗi trong quá trình upload file";
                $uploadOk = 0;
            }
        }

        if ($uploadOk == 0) {
            $errorUpload[] = "Xin lỗi không thể upload file này";
            $_SESSION["upload_error"] = $errorUpload;
            return false;
        }

        return $target_file;
    }


    public function index() {

        $danh_sach_truong_dh_const = [
            "1" => "Học viện Âm nhạc quốc gia Việt Nam",
            "2" => "Nhạc viện Thành phố Hồ Chí Minh",
            "3" => "Học viện Âm nhạc Huế",
            "4" => "Trường Đại học Văn hóa Hà Nội",
            "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
            "6" => "Trường Đại học Mỹ thuật Việt Nam",
            "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
            "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
            "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
            "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
            "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
            "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
            "13" => "Học viện Múa Việt Nam",
            "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
            "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
            "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
            "17" => "Trường Cao đẳng Du lịch Hà Nội",
            "18" => "Trường Cao đẳng Du lịch Hải Phòng",
            "19" => "Trường Cao đẳng Du lịch Huế",
            "20" => "Trường Cao đẳng Du lịch Nha Trang",
            "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
            "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
            "23" => "Trường Cao đẳng Du lịch Đà Lạt",
            "24" => "Trường Cao đẳng Du lịch Cần Thơ",
            "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
            "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
        ];

        include_once "mvc/view/index/index.php";
    }


    /**
     * @todo xử lý bảo mật
     */
    public function thuchienkhaosat() {
        $data = $_POST;

        if (isset($_POST["donvikhaosat"]) && isset($_POST["ten"]) && isset($_POST["so_dien_thoai"]) && isset($_POST["email"]) && isset($_POST["bo_phan_khao_sat"]) && isset($_POST["dai_dien"]) && isset($_POST["chuc_vu"]) && isset($_POST["thoigian"]) && isset($_POST["password"])  && (strlen($_POST["ten"]) > 1) && (strlen($_POST["so_dien_thoai"]) > 1) && (strlen($_POST["email"]) > 1) && (strlen($_POST["bo_phan_khao_sat"]) > 1) && (strlen($_POST["dai_dien"]) > 1) && (strlen($_POST["chuc_vu"]) > 1) && (strlen($_POST["thoigian"]) > 1) && (strlen($_POST["password"]) > 1) ) {
            $data["donvikhaosat"] = strip_tags(trim($_POST["donvikhaosat"]));
            $data["ten"] = strip_tags(trim($_POST["ten"]));
            $data["so_dien_thoai"] = strip_tags(trim($_POST["so_dien_thoai"]));
            $data["email"] = strip_tags(trim($_POST["email"]));
            $data["bo_phan_khao_sat"] = strip_tags(trim($_POST["bo_phan_khao_sat"]));
            $data["dai_dien"] = strip_tags(trim($_POST["dai_dien"]));
            $data["chuc_vu"] = strip_tags(trim($_POST["chuc_vu"]));
            $data["thoigian"] = strip_tags(trim($_POST["thoigian"]));
            $data["password"] = strip_tags(trim($_POST["password"]));
            $data["matkhau"] = md5($data["password"]);

            $model = new SurveyModel();
            /**
             * Kiểm tra xem tài khoản đã có sẵn hay chưa
             */
            $userSurvey = $model->checkExistEmail($data["email"]);

            if (isset($userSurvey["id"]) && ($userSurvey["id"] > 0)) {
                $_SESSION["common_error"] = "Tài khoản với email " . $data["email"] . " này đã tồn tại vui lòng đăng nhập để chỉnh sửa khảo sát thay vì tạo khảo sát mới";

                header("Location: index.php?controller=index&action=xayraloi");
                exit();
            } else {
                $model->insertSurvey($data);
                $surveyUser = $model->getSurvey($data["email"],$data["matkhau"]);

                if (isset($surveyUser["id"]) && ($surveyUser["id"] > 0)) {
                    $_SESSION["surveyUser"] = $surveyUser;
                    header("Location: index.php?controller=index&action=lamkhaosatmoi");
                    exit();
                }
            }
        }

        $_SESSION["common_error"] = "Vui lòng nhập đủ thông tin và thử lại";

        /**
         * Thông báo xảy ra lỗi
         */
        header("Location: index.php?controller=index&action=xayraloi");
        exit();
    }


    public function lamkhaosatmoi() {

        $danh_sach_truong_dh_const = [
            "1" => "Học viện Âm nhạc quốc gia Việt Nam",
            "2" => "Nhạc viện Thành phố Hồ Chí Minh",
            "3" => "Học viện Âm nhạc Huế",
            "4" => "Trường Đại học Văn hóa Hà Nội",
            "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
            "6" => "Trường Đại học Mỹ thuật Việt Nam",
            "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
            "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
            "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
            "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
            "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
            "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
            "13" => "Học viện Múa Việt Nam",
            "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
            "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
            "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
            "17" => "Trường Cao đẳng Du lịch Hà Nội",
            "18" => "Trường Cao đẳng Du lịch Hải Phòng",
            "19" => "Trường Cao đẳng Du lịch Huế",
            "20" => "Trường Cao đẳng Du lịch Nha Trang",
            "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
            "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
            "23" => "Trường Cao đẳng Du lịch Đà Lạt",
            "24" => "Trường Cao đẳng Du lịch Cần Thơ",
            "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
            "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
        ];

        $nghiepvusDefault = [
            "Quản lý hành chính điện tử - các hệ thống báo cáo số liệu",
            "Quản lý Tuyển sinh",
            "Quản lý Thời khóa biểu – kế hoạch giảng dạy",
            "Quản lý Công tác Sinh viên",
            "Quản lý học vụ",
            "Quản lý khảo thí – Trác nghiệm",
            "Quản lý Tài chính ",
            "Quản lý Lý túc xá",
            "Quản lý Nhân sự thỉnh giảng – Tiền Công",
            "Quản lý Tài sản – Thiết bị",
            "Quản lý nghiên cứu khoa học",
            "kết nối cộng đồng phụ huynh- sinh viên – nhà trường",
            "Hóa đơn điện tử",
            "Quản lý chuyển phát, điều hành xe"
        ];

        $survey = $_SESSION["surveyUser"];

        if (isset($survey["id"]) && ($survey["id"])) {
            include_once "mvc/view/index/lamkhaosatmoi.php";
            return;
        }

        header("Location: index.php?controller=index&action=xayraloi");
        exit();
    }

    public function hoanthanhkhaosat() {

        $model = new SurveyModel();

        $survey = $_SESSION["surveyUser"];
        $lastId = (int) $survey["id"];

        if ($lastId > 0) {
            $currentSurvey = $model->getSurveyById($lastId);

            if (isset($currentSurvey["id"]) && ($currentSurvey["id"] > 0)) {
                $dataNew = $_POST;

                $dataNew["matkhau"] = $currentSurvey["matkhau"];
                $dataNew["email"] = $currentSurvey["email"];

                if (isset($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']) && !empty($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name'])) {

                    $uploadF = $this->uploadFile();
                    if ($uploadF != false) {
                        $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = strval($uploadF);
                    } else {
                        $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                    }
                } else {
                    $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                }

                $model->updateSurvey($dataNew, $lastId);
            }

            $idx_nghiepvu = 0;
            foreach ($_POST["nghiepvu"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvu"]["ten_nghiep_vu"][$idx_nghiepvu];
                $data['hien_trang'] = $_POST["nghiepvu"]["hien_trang"][$idx_nghiepvu];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvu"]["nhu_cau_tin_hoc"][$idx_nghiepvu];
                $model->updateNghiepVu($data);
                $idx_nghiepvu++;
            }

            $idx_nghiepvulienthong = 0;
            foreach ($_POST["nghiepvulienthong"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvulienthong"]["ten_nghiep_vu"][$idx_nghiepvulienthong];
                $data['coquan'] = $_POST["nghiepvulienthong"]["coquan"][$idx_nghiepvulienthong];
                $data['hien_trang'] = $_POST["nghiepvulienthong"]["hien_trang"][$idx_nghiepvulienthong];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvulienthong"]["nhu_cau_tin_hoc"][$idx_nghiepvulienthong];
                $model->updateNghiepVuLienThong($data);
                $idx_nghiepvulienthong++;
            }

            $idx_nghiepvunoibo = 0;
            foreach ($_POST["nghiepvunoibo"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvunoibo"]["ten_nghiep_vu"][$idx_nghiepvunoibo];
                $data['hien_trang'] = $_POST["nghiepvunoibo"]["hien_trang"][$idx_nghiepvunoibo];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvunoibo"]["nhu_cau_tin_hoc"][$idx_nghiepvunoibo];
                $model->updateNghiepVuNoiBo($data);
                $idx_nghiepvunoibo++;
            }

            $idx_udcnttdatrienkhai = 0;
            foreach ($_POST["udcnttdatrienkhai"]["ten_phan_mem"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_phan_mem'] = $_POST["udcnttdatrienkhai"]["ten_phan_mem"][$idx_udcnttdatrienkhai];
                $data['mo_ta_chung'] = $_POST["udcnttdatrienkhai"]["mo_ta_chung"][$idx_udcnttdatrienkhai];
                $data['doituongsudung'] = $_POST["udcnttdatrienkhai"]["doituongsudung"][$idx_udcnttdatrienkhai];
                $data['nhucau'] = $_POST["udcnttdatrienkhai"]["nhucau"][$idx_udcnttdatrienkhai];
                $data['nguyennhan'] = $_POST["udcnttdatrienkhai"]["nguyennhan"][$idx_udcnttdatrienkhai];
                $model->updateUDCNTTDaTrienKhai($data);
                $idx_udcnttdatrienkhai++;
            }

            $idx_udcnttyeucau = 0;
            foreach ($_POST["udcnttyeucau"]["yeucau"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['yeucau'] = $_POST["udcnttyeucau"]["yeucau"][$idx_udcnttyeucau];
                $data['ungdungdexuat'] = $_POST["udcnttyeucau"]["ungdungdexuat"][$idx_udcnttyeucau];
                $model->updateUDCNTTNhuCau($data);
                $idx_udcnttyeucau++;
            }

            $idx_udcnttdangtrienkhai = 0;
            foreach ($_POST["udcnttdangtrienkhai"]["ten_duan"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_duan'] = $_POST["udcnttdangtrienkhai"]["ten_duan"][$idx_udcnttdangtrienkhai];
                $data['muctieu'] = $_POST["udcnttdangtrienkhai"]["muctieu"][$idx_udcnttdangtrienkhai];
                $data['quymo'] = $_POST["udcnttdangtrienkhai"]["quymo"][$idx_udcnttdangtrienkhai];
                $data['tongmucdautu'] = $_POST["udcnttdangtrienkhai"]["tongmucdautu"][$idx_udcnttdangtrienkhai];
                $data['noidung'] = $_POST["udcnttdangtrienkhai"]["noidung"][$idx_udcnttdangtrienkhai];
                $data['thoigianthuchien'] = $_POST["udcnttdangtrienkhai"]["thoigianthuchien"][$idx_udcnttdangtrienkhai];
                $data['ghichu'] = $_POST["udcnttdangtrienkhai"]["ghichu"][$idx_udcnttdangtrienkhai];
                $model->updateUDCNTTDangTrienKhai($data);
                $idx_udcnttdangtrienkhai++;
            }

            $idx_maychuvatly = 0;
            foreach ($_POST["maychuvatly"]["model"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['model'] = $_POST["maychuvatly"]["model"][$idx_maychuvatly];
                $data['soluong'] = $_POST["maychuvatly"]["soluong"][$idx_maychuvatly];
                $data['thong_so'] = $_POST["maychuvatly"]["thong_so"][$idx_maychuvatly];
                $data['nam_dau_tu'] = $_POST["maychuvatly"]["nam_dau_tu"][$idx_maychuvatly];
                $data['tinh_trang'] = $_POST["maychuvatly"]["tinh_trang"][$idx_maychuvatly];
                $data['ghi_chu'] = $_POST["maychuvatly"]["ghi_chu"][$idx_maychuvatly];
                $model->updateMayChuVatLy($data);
                $idx_maychuvatly++;
            }

            $idx_csdldatrienkhai = 0;
            foreach ($_POST["csdldatrienkhai"]["ten_csdl"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_csdl'] = $_POST["csdldatrienkhai"]["ten_csdl"][$idx_csdldatrienkhai];
                $data['he_csdl'] = $_POST["csdldatrienkhai"]["he_csdl"][$idx_csdldatrienkhai];
                $data['ban_quyen'] = $_POST["csdldatrienkhai"]["ban_quyen"][$idx_csdldatrienkhai];
                $data['nam_dau_tu'] = $_POST["csdldatrienkhai"]["nam_dau_tu"][$idx_csdldatrienkhai];
                $data['he_dieu_hanh'] = $_POST["csdldatrienkhai"]["he_dieu_hanh"][$idx_csdldatrienkhai];
                $data['nhucau'] = $_POST["csdldatrienkhai"]["nhucau"][$idx_csdldatrienkhai];
                $model->updateCSDLDaTrienKhai($data);
                $idx_csdldatrienkhai++;
            }

            $idx_csdltraodoi = 0;
            foreach ($_POST["csdltraodoi"]["linh_vuc"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['linh_vuc'] = $_POST["csdltraodoi"]["linh_vuc"][$idx_csdltraodoi];
                $data['don_vi_lien_quan'] = $_POST["csdltraodoi"]["don_vi_lien_quan"][$idx_csdltraodoi];
                $data['thong_tin_trao_doi'] = $_POST["csdltraodoi"]["thong_tin_trao_doi"][$idx_csdltraodoi];
                $data['tan_suat'] = $_POST["csdltraodoi"]["tan_suat"][$idx_csdltraodoi];
                $data['phuong_thuc'] = $_POST["csdltraodoi"]["phuong_thuc"][$idx_csdltraodoi];
                $data['ghi_chu'] = $_POST["csdltraodoi"]["ghi_chu"][$idx_csdltraodoi];
                $model->updateCSDLTraoDoi($data);
                $idx_csdltraodoi++;
            }

            $idx_nhucaudaotao = 0;
            foreach ($_POST["nhucaudaotao"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao"]["noidung_daotao"][$idx_nhucaudaotao];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao"]["soluong_hocvien"][$idx_nhucaudaotao];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao"]["muc_do_uu_tien"][$idx_nhucaudaotao];

                $model->updateNhuCauDaoTao($data);
                $idx_nhucaudaotao++;
            }

            $idx_nhucaudaotao_ext = 0;
            foreach ($_POST["nhucaudaotao_ext"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao_ext"]["noidung_daotao"][$idx_nhucaudaotao_ext];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao_ext"]["soluong_hocvien"][$idx_nhucaudaotao_ext];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao_ext"]["muc_do_uu_tien"][$idx_nhucaudaotao_ext];

                $model->updateNhuCauDaoTao($data);
                $idx_nhucaudaotao_ext++;
            }
        }
        header("Location: index.php?controller=index&action=thongbaoketqua");
        exit();
    }


    public function thongbaoketqua() {

        include_once "mvc/view/index/thongbaoketqua.php";
    }

    public function xayraloi() {

        $common_error = $_SESSION["common_error"];
        $_SESSION["common_error"] = "";

        include_once "mvc/view/index/xayraloi.php";
    }


    public function viewdangnhapchinhsuakhaosat() {

        include_once "mvc/view/index/viewdangnhapchinhsuakhaosat.php";
    }


    public function viewchinhsuakhaosat() {
        $danh_sach_truong_dh_const = [
            "1" => "Học viện Âm nhạc quốc gia Việt Nam",
            "2" => "Nhạc viện Thành phố Hồ Chí Minh",
            "3" => "Học viện Âm nhạc Huế",
            "4" => "Trường Đại học Văn hóa Hà Nội",
            "5" => "Trường Đại học Văn hóa Thành phố Hồ Chí Minh",
            "6" => "Trường Đại học Mỹ thuật Việt Nam",
            "7" => "Trường Đại học Mỹ thuật Thành phố Hồ Chí Minh",
            "8" => "Trường Đại học Sân khấu - Điện ảnh Hà Nội",
            "9" => "Trường Đại học Sân khấu - Điện ảnh Thành phố Hồ Chí Minh",
            "10" => "Trường Đại học Thể dục thể thao Bắc Ninh",
            "11" => "Trường Đại học Thể dục thể thao Thành phố Hồ Chí Minh",
            "12" => "Trường Đại học Thể dục thể thao Đà Nẵng",
            "13" => "Học viện Múa Việt Nam",
            "14" => "Trường Cao đẳng Văn hóa Nghệ thuật Tây Bắc",
            "15" => "Trường Cao đẳng Văn hóa Nghệ thuật Việt Bắc",
            "16" => "Trường Cao đẳng Mỹ thuật trang trí Đồng Nai",
            "17" => "Trường Cao đẳng Du lịch Hà Nội",
            "18" => "Trường Cao đẳng Du lịch Hải Phòng",
            "19" => "Trường Cao đẳng Du lịch Huế",
            "20" => "Trường Cao đẳng Du lịch Nha Trang",
            "21" => "Trường Cao đẳng Du lịch Đà Nẵng",
            "22" => "Trường Cao đẳng Du lịch Vũng Tàu",
            "23" => "Trường Cao đẳng Du lịch Đà Lạt",
            "24" => "Trường Cao đẳng Du lịch Cần Thơ",
            "25" => "Trường Trung cấp Múa Thành phố Hồ Chí Minh",
            "26" => "Trường Trung cấp Nghệ thuật Xiếc và Tạp kỹ Việt Nam",
        ];

        $userSurvey = $_SESSION["surveyEditUser"];

        if (isset($userSurvey["id"]) && ($userSurvey["id"] > 0)) {
            $model = new SurveyModel();
            $id = (int)$userSurvey["id"];
            $survey = $model->getSingle($id);

            $nghiepvusDefault = [
                "Quản lý hành chính điện tử - các hệ thống báo cáo số liệu",
                "Quản lý Tuyển sinh",
                "Quản lý Thời khóa biểu – kế hoạch giảng dạy",
                "Quản lý Công tác Sinh viên",
                "Quản lý học vụ",
                "Quản lý khảo thí – Trác nghiệm",
                "Quản lý Tài chính ",
                "Quản lý Lý túc xá",
                "Quản lý Nhân sự thỉnh giảng – Tiền Công",
                "Quản lý Tài sản – Thiết bị",
                "Quản lý nghiên cứu khoa học",
                "kết nối cộng đồng phụ huynh- sinh viên – nhà trường",
                "Hóa đơn điện tử",
                "Quản lý chuyển phát, điều hành xe"
            ];

            include_once "mvc/view/index/viewchinhsuakhaosat.php";
        } else {
            header("Location: index.php?controller=index&action=xayraloi");
            exit();
        }
    }


    public function luusuakhaosat() {

        $model = new SurveyModel();

        $userSurvey = $_SESSION["surveyEditUser"];
        $lastId = $id = (int)$userSurvey["id"];

        if ($lastId > 0) {
            $currentSurvey = $model->getSurveyById($lastId);

            if (isset($currentSurvey["id"]) && ($currentSurvey["id"] > 0)) {
                $dataNew = $_POST;

                $dataNew["matkhau"] = $currentSurvey["matkhau"];
                $dataNew["email"] = $currentSurvey["email"];

                if (isset($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name']) && !empty($_FILES['danh_sach_chuc_nang_nghiep_vu_file']['tmp_name'])) {

                    $uploadF = $this->uploadFile();
                    if ($uploadF != false) {
                        $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = strval($uploadF);
                    } else {
                        $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                    }
                } else {
                    $dataNew["danh_sach_chuc_nang_nghiep_vu_file"] = $currentSurvey["danh_sach_chuc_nang_nghiep_vu_file"];
                }

                $model->updateSurvey($dataNew, $lastId);
            }

            $model->deleteRel($lastId);

            $idx_nghiepvu = 0;

            foreach ($_POST["nghiepvu"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvu"]["ten_nghiep_vu"][$idx_nghiepvu];
                $data['hien_trang'] = $_POST["nghiepvu"]["hien_trang"][$idx_nghiepvu];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvu"]["nhu_cau_tin_hoc"][$idx_nghiepvu];
                $model->updateNghiepVu($data);
                $idx_nghiepvu++;
            }

            $idx_nghiepvulienthong = 0;
            foreach ($_POST["nghiepvulienthong"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvulienthong"]["ten_nghiep_vu"][$idx_nghiepvulienthong];
                $data['coquan'] = $_POST["nghiepvulienthong"]["coquan"][$idx_nghiepvulienthong];
                $data['hien_trang'] = $_POST["nghiepvulienthong"]["hien_trang"][$idx_nghiepvulienthong];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvulienthong"]["nhu_cau_tin_hoc"][$idx_nghiepvulienthong];
                $model->updateNghiepVuLienThong($data);
                $idx_nghiepvulienthong++;
            }

            $idx_nghiepvunoibo = 0;
            foreach ($_POST["nghiepvunoibo"]["ten_nghiep_vu"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_nghiep_vu'] = $_POST["nghiepvunoibo"]["ten_nghiep_vu"][$idx_nghiepvunoibo];
                $data['hien_trang'] = $_POST["nghiepvunoibo"]["hien_trang"][$idx_nghiepvunoibo];
                $data['nhu_cau_tin_hoc'] = $_POST["nghiepvunoibo"]["nhu_cau_tin_hoc"][$idx_nghiepvunoibo];
                $model->updateNghiepVuNoiBo($data);
                $idx_nghiepvunoibo++;
            }



            $idx_udcnttdatrienkhai = 0;
            foreach ($_POST["udcnttdatrienkhai"]["ten_phan_mem"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_phan_mem'] = $_POST["udcnttdatrienkhai"]["ten_phan_mem"][$idx_udcnttdatrienkhai];
                $data['mo_ta_chung'] = $_POST["udcnttdatrienkhai"]["mo_ta_chung"][$idx_udcnttdatrienkhai];
                $data['doituongsudung'] = $_POST["udcnttdatrienkhai"]["doituongsudung"][$idx_udcnttdatrienkhai];
                $data['nhucau'] = $_POST["udcnttdatrienkhai"]["nhucau"][$idx_udcnttdatrienkhai];
                $data['nguyennhan'] = $_POST["udcnttdatrienkhai"]["nguyennhan"][$idx_udcnttdatrienkhai];
                $model->updateUDCNTTDaTrienKhai($data);
                $idx_udcnttdatrienkhai++;
            }

            $idx_udcnttyeucau = 0;
            foreach ($_POST["udcnttyeucau"]["yeucau"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['yeucau'] = $_POST["udcnttyeucau"]["yeucau"][$idx_udcnttyeucau];
                $data['ungdungdexuat'] = $_POST["udcnttyeucau"]["ungdungdexuat"][$idx_udcnttyeucau];
                $model->updateUDCNTTNhuCau($data);
                $idx_udcnttyeucau++;
            }

            $idx_udcnttdangtrienkhai = 0;
            foreach ($_POST["udcnttdangtrienkhai"]["ten_duan"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_duan'] = $_POST["udcnttdangtrienkhai"]["ten_duan"][$idx_udcnttdangtrienkhai];
                $data['muctieu'] = $_POST["udcnttdangtrienkhai"]["muctieu"][$idx_udcnttdangtrienkhai];
                $data['quymo'] = $_POST["udcnttdangtrienkhai"]["quymo"][$idx_udcnttdangtrienkhai];
                $data['tongmucdautu'] = $_POST["udcnttdangtrienkhai"]["tongmucdautu"][$idx_udcnttdangtrienkhai];
                $data['noidung'] = $_POST["udcnttdangtrienkhai"]["noidung"][$idx_udcnttdangtrienkhai];
                $data['thoigianthuchien'] = $_POST["udcnttdangtrienkhai"]["thoigianthuchien"][$idx_udcnttdangtrienkhai];
                $data['ghichu'] = $_POST["udcnttdangtrienkhai"]["ghichu"][$idx_udcnttdangtrienkhai];
                $model->updateUDCNTTDangTrienKhai($data);
                $idx_udcnttdangtrienkhai++;
            }

            $idx_maychuvatly = 0;
            foreach ($_POST["maychuvatly"]["model"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['model'] = $_POST["maychuvatly"]["model"][$idx_maychuvatly];
                $data['soluong'] = $_POST["maychuvatly"]["soluong"][$idx_maychuvatly];
                $data['thong_so'] = $_POST["maychuvatly"]["thong_so"][$idx_maychuvatly];
                $data['nam_dau_tu'] = $_POST["maychuvatly"]["nam_dau_tu"][$idx_maychuvatly];
                $data['tinh_trang'] = $_POST["maychuvatly"]["tinh_trang"][$idx_maychuvatly];
                $data['ghi_chu'] = $_POST["maychuvatly"]["ghi_chu"][$idx_maychuvatly];
                $model->updateMayChuVatLy($data);
                $idx_maychuvatly++;
            }





            $idx_csdldatrienkhai = 0;
            foreach ($_POST["csdldatrienkhai"]["ten_csdl"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['ten_csdl'] = $_POST["csdldatrienkhai"]["ten_csdl"][$idx_csdldatrienkhai];
                $data['he_csdl'] = $_POST["csdldatrienkhai"]["he_csdl"][$idx_csdldatrienkhai];
                $data['ban_quyen'] = $_POST["csdldatrienkhai"]["ban_quyen"][$idx_csdldatrienkhai];
                $data['nam_dau_tu'] = $_POST["csdldatrienkhai"]["nam_dau_tu"][$idx_csdldatrienkhai];
                $data['he_dieu_hanh'] = $_POST["csdldatrienkhai"]["he_dieu_hanh"][$idx_csdldatrienkhai];
                $data['nhucau'] = $_POST["csdldatrienkhai"]["nhucau"][$idx_csdldatrienkhai];
                $model->updateCSDLDaTrienKhai($data);
                $idx_csdldatrienkhai++;
            }



            $idx_csdltraodoi = 0;
            foreach ($_POST["csdltraodoi"]["linh_vuc"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['linh_vuc'] = $_POST["csdltraodoi"]["linh_vuc"][$idx_csdltraodoi];
                $data['don_vi_lien_quan'] = $_POST["csdltraodoi"]["don_vi_lien_quan"][$idx_csdltraodoi];
                $data['thong_tin_trao_doi'] = $_POST["csdltraodoi"]["thong_tin_trao_doi"][$idx_csdltraodoi];
                $data['tan_suat'] = $_POST["csdltraodoi"]["tan_suat"][$idx_csdltraodoi];
                $data['phuong_thuc'] = $_POST["csdltraodoi"]["phuong_thuc"][$idx_csdltraodoi];
                $data['ghi_chu'] = $_POST["csdltraodoi"]["ghi_chu"][$idx_csdltraodoi];
                $model->updateCSDLTraoDoi($data);
                $idx_csdltraodoi++;
            }



            $idx_nhucaudaotao = 0;
            foreach ($_POST["nhucaudaotao"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao"]["noidung_daotao"][$idx_nhucaudaotao];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao"]["soluong_hocvien"][$idx_nhucaudaotao];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao"]["muc_do_uu_tien"][$idx_nhucaudaotao];

                $model->updateNhuCauDaoTao($data);
                $idx_nhucaudaotao++;
            }

            $idx_nhucaudaotao_ext = 0;
            foreach ($_POST["nhucaudaotao_ext"]["noidung_daotao"] as $item) {
                $data = [];
                $data['user_id_answer'] = (int)$lastId;
                $data['noidung_daotao'] = $_POST["nhucaudaotao_ext"]["noidung_daotao"][$idx_nhucaudaotao_ext];
                $data['soluong_hocvien'] = $_POST["nhucaudaotao_ext"]["soluong_hocvien"][$idx_nhucaudaotao_ext];
                $data['muc_do_uu_tien'] = $_POST["nhucaudaotao_ext"]["muc_do_uu_tien"][$idx_nhucaudaotao_ext];

                $model->updateNhuCauDaoTao($data);
                $idx_nhucaudaotao_ext++;
            }
        }

        header("Location: index.php?controller=index&action=thongbaoketqua");
        exit();
    }

    public function kiemtramatkhau() {

        $_SESSION["common_error"] = "Email hoặc mật khẩu không đúng vui lòng liên hệ admin để được hỗ trợ";

        $model = new SurveyModel();
        if (isset($_POST["email"]) && isset($_POST["password"]) && ($_POST["email"]) && ($_POST["password"])) {
            $password = trim($_POST["password"]);
            $password = md5($password);
            $userSurvey = $model->getLoginSurvey($_POST["email"],$password);


            if (isset($userSurvey["id"]) && ($userSurvey["id"] > 0)) {
                $_SESSION["surveyEditUser"] = $userSurvey;

                header("Location: index.php?controller=index&action=viewchinhsuakhaosat");
                exit();
            }

        }

        header("Location: index.php?controller=index&action=xayraloi");
        exit();
    }

}