


<style type="text/css">

</style>

<div class="dx-header">
    <div class="logo"></div>
    <div class="header-main">
        <h1>BỘ VĂN HÓA, THỂ THAO VÀ DU LỊCH</h1>
        <h3>Khảo sát hiện trạng ứng dụng phần mềm công nghệ <br> thông tin tại các cơ sở đào tạo</h3>
    </div>
</div>