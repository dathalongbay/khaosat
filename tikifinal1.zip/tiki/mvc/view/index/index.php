<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Khảo sát hiện trạng ứng dụng phần mềm công nghệ thông tin tại các cơ sở đào tạo</title>

    <!-- Custom fonts for this template -->
    <link href="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo BASE_URL ?>template/backend/sbadmin/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">


    <link rel="stylesheet" href="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datetimepicker/jquery.datetimepicker.css">

    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>template/frontend/stylefe.css">

    <style type="text/css">
        ::-webkit-input-placeholder { /* Edge */
            color: #d9dae9 !important;
        }

        :-ms-input-placeholder { /* Internet Explorer */
            color: #d9dae9 !important;
        }

        ::placeholder {
            color: #d9dae9 !important;
        }

        table {
            color: black !important;
        }
    </style>
</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">



    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">


            <!-- Begin Page Content -->
            <div class="container1">

                <?php include_once "mvc/view/index/feheader.php"; ?>

                <!-- DataTales Example -->
                <div class="card">

                    <div class="card-body" style="width: 800px; margin: 0 auto;">
                        <div class="table-responsive">

                            <h4 style="text-align: center; font-size: 36px; font-weight: bold; padding: 10px 0">THÔNG TIN ĐƠN VỊ KHẢO SÁT</h4>
                            <form name="survey" method="post" action="<?php echo BASE_URL."index.php?controller=index&action=thuchienkhaosat" ?>">

                                <div class="form-group">
                                    <label>Đơn vị được khảo sát: <span style="color:red">*</span></label>
                                    <select name="donvikhaosat" required class="form-control">
                                        <option value="">-- Chọn đơn vị được khảo sát--</option>
                                        <?php foreach ($danh_sach_truong_dh_const as $danh_sach_truong_dh_const_key => $danh_sach_truong_dh_const_item) : ?>
                                        <option value="<?php echo $danh_sach_truong_dh_const_key ?>"><?php echo $danh_sach_truong_dh_const_item ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Cán bộ thực hiện khảo sát: <span style="color:red">*</span></label>
                                    <input type="text" required class="form-control" name="ten" placeholder="VD: Nguyễn văn A" value="" autocomplete="off">
                                </div>

                                <div class="form-group">
                                    <label>Số điện thoại: <span style="color:red">*</span></label>
                                    <input type="text" required class="form-control" name="so_dien_thoai"  placeholder="VD: 0981234567" value="" autocomplete="off">
                                </div>

                                <div class="form-group">
                                    <label>Email: <span style="color:red">*</span></label>
                                    <input type="text" required class="form-control" name="email" placeholder="VD: abc@gmail.com" value="" autocomplete="off">
                                </div>

                                <div class="form-group">
                                    <label>Cán bộ khảo sát thuộc bộ phận: <span style="color:red">*</span></label>
                                    <input type="text" required class="form-control" name="bo_phan_khao_sat" placeholder="VD: Phòng công nghệ thông tin" value="" autocomplete="off">
                                </div>

                                <div class="form-group">
                                    <label>Đại diện đơn vị khảo sát: <span style="color:red">*</span></label>
                                    <input type="text" required class="form-control" name="dai_dien" value="" placeholder="VD: Nguyễn văn B" autocomplete="off">
                                </div>

                                <div class="form-group">
                                    <label>Chức vụ: <span style="color:red">*</span></label>
                                    <input type="text" required class="form-control" name="chuc_vu" value="" placeholder="VD: Hiệu trưởng trường ĐH VH TT&DL" autocomplete="off">
                                </div>

                                <div class="form-group">
                                    <label>Thời gian thực hiện khảo sát: <span style="color:red">*</span></label>
                                    <input id="thoigian" required type="text" class="form-control" name="thoigian" value="" placeholder="VD: 21/03/2020 21:15" autocomplete="off" readonly>
                                    <p style="color: lightgrey; font-size: 14px; margin: 10px">Vui lòng nhấp chuột vào ô nhập liệu để chọn thời gian</p>
                                </div>

                                <div class="form-group">
                                    <label>Đăng ký mật khẩu mới dùng khi cần chỉnh sửa khảo sát sau này: <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" name="password" placeholder="Ví dụ : hanoi@751!" value="" autocomplete="off">
                                    <p style="color: lightgrey; font-size: 14px; margin: 10px">Mật khẩu phải trên 5 ký tự. Mật khẩu này sẽ được sử dụng để đăng nhập khi bạn cần chỉnh sửa khảo sát sau khi đã gửi khảo sát</p>
                                </div>

                                <div style="text-align: center">

                                    <span class="btn submitf" style="background-color: #195db0; color: white;">Thực hiện khảo sát</span>


                                </div>


                                <button id="targetSubmitBtn" type="submit" style="background-color: #195db0; color: white;display: none">Thực hiện khảo sát</button>


                            </form>

                            <div style="padding: 40px 0">
                                <h4 style="text-align: center;">HƯỚNG DẪN THỰC HIỆN KHẢO SÁT</h4>

                                <div >
                                    <?php echo QUYDINH_KS ?>
                                </div>
                            </div>


                            <div style="text-align: center">
                                <a href="<?php echo BASE_URL."index.php?controller=index&action=viewdangnhapchinhsuakhaosat" ?>" class="btn" style="background-color: #195db0; color: white;">Chỉnh sửa khảo sát</a>
                            </div>


                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Bộ văn hóa, thể thao và du lịch</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<!-- Bootstrap core JavaScript-->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<!-- Page level custom scripts -->
<script src="<?php echo BASE_URL ?>template/backend/sbadmin/js/demo/datatables-demo.js"></script>

<script src="<?php echo BASE_URL ?>template/backend/sbadmin/vendor/datetimepicker/jquery.datetimepicker.full.min.js"></script>


<script type="text/javascript">
    jQuery('#thoigian').datetimepicker({
        format:'d/m/Y H:i',
        lang:'vi'
    });
</script>

<script type="text/javascript">
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    $(document).ready(function () {
        $("span.submitf").on("click", function (e) {

            console.log(111);
            e.preventDefault();

            var txt_error = "";

            // đơn vị khảo sát
            var donvikhaosat = $("select[name='donvikhaosat']").val();
            donvikhaosat = $.trim(donvikhaosat);

            if (!donvikhaosat) {
                txt_error += "Vui lòng nhập đủ thông tin đơn vị khảo sát";
            }

            // tên
            var ten = $("input[name='ten']").val();
            ten = $.trim(ten);
            if (ten.length < 2) {
                txt_error += "\nVui lòng nhập đủ thông tin tên người tham gia khảo sát";
            }

            // so_dien_thoai
            var so_dien_thoai = $("input[name='so_dien_thoai']").val();
            so_dien_thoai = $.trim(so_dien_thoai);
            if (so_dien_thoai.length < 10) {
                txt_error += "\nSố điện thoại phải từ 10 số trở lên";
            }

            if(isNaN(so_dien_thoai)){
                txt_error += "\nSố điện thoại chỉ được nhập số";
            }

            // email
            var email = $("input[name='email']").val();
            email = $.trim(email);
            if (email.length < 2) {
                txt_error += "\nEmail quá ngắn không hợp lệ";
            }

            if(!validateEmail(email)) {
                txt_error += "\nEmail có định dạng không hợp lệ";
            }

            // bo_phan_khao_sat
            var bo_phan_khao_sat = $("input[name='bo_phan_khao_sat']").val();
            bo_phan_khao_sat = $.trim(bo_phan_khao_sat);
            if (bo_phan_khao_sat.length < 2) {
                txt_error += "\nBộ phận khảo sát quá ngắn";
            }

            // dai_dien
            var dai_dien = $("input[name='dai_dien']").val();
            dai_dien = $.trim(dai_dien);
            if (dai_dien.length < 2) {
                txt_error += "\nThông tin đại điện khảo sát quá ngắn";
            }

            // chuc_vu
            var chuc_vu = $("input[name='chuc_vu']").val();
            chuc_vu = $.trim(chuc_vu);
            if (chuc_vu.length < 2) {
                txt_error += "\nThông tin chức vụ khảo sát quá ngắn";
            }

            // thoigian
            var thoigian = $("input[name='thoigian']").val();
            thoigian = $.trim(thoigian);
            if (thoigian.length < 2) {
                txt_error += "\nThời gian khảo sát quá ngắn không hợp lệ";
            }

            // password
            var password = $("input[name='password']").val();
            password = $.trim(password);
            if (password.length < 5) {
                txt_error += "\nMật khẩu phải trên 5 ký tự";
            }

            // submit form hay thông báo lỗi
            txt_error = $.trim(txt_error);
            console.log(txt_error);
            if (txt_error.length > 1) {
                alert(txt_error);
            } else {
                $("#targetSubmitBtn").trigger("click");
               // $("form[name='survey']").submit();
            }

        });
    });

</script>

</body>

</html>
