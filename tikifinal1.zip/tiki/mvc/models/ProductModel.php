<?php
namespace MVC\Models;

class ProductModel extends Database {

}