/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : tiki1

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-03-19 21:34:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('2', 'admin@gmail.com', 'ce3ac1807677ee36943b210356f517f9');

-- ----------------------------
-- Table structure for csdl_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `csdl_datrienkhai`;
CREATE TABLE `csdl_datrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_csdl` text DEFAULT NULL,
  `he_csdl` text DEFAULT NULL,
  `ban_quyen` text DEFAULT NULL,
  `nam_dau_tu` text DEFAULT NULL,
  `he_dieu_hanh` text DEFAULT NULL,
  `nhucau` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of csdl_datrienkhai
-- ----------------------------
INSERT INTO `csdl_datrienkhai` VALUES ('1', null, null, null, '', '', '', '1');
INSERT INTO `csdl_datrienkhai` VALUES ('2', null, null, null, '', '', '', '7');
INSERT INTO `csdl_datrienkhai` VALUES ('4', null, null, null, '', '', '', '9');
INSERT INTO `csdl_datrienkhai` VALUES ('5', '', '', '', '', '', '', '10');
INSERT INTO `csdl_datrienkhai` VALUES ('6', '', '', '', '', '', '', '8');
INSERT INTO `csdl_datrienkhai` VALUES ('7', '', '', '', '', '', '', '11');
INSERT INTO `csdl_datrienkhai` VALUES ('8', '', '', '', '', '', '', '12');
INSERT INTO `csdl_datrienkhai` VALUES ('13', 'csdldatrienkhai[ten_csdl][]', 'csdldatrienkhai[he_csdl][]', 'csdldatrienkhai[ban_quyen][]', 'csdldatrienkhai[nam_dau_tu][]', 'csdldatrienkhai[he_dieu_hanh][]', 'csdldatrienkhai[nhucau][]', '16');
INSERT INTO `csdl_datrienkhai` VALUES ('14', 'csdldatrienkhai[ten_csdl][]', 'csdldatrienkhai[he_csdl][]', 'csdldatrienkhai[ban_quyen][]', 'csdldatrienkhai[nam_dau_tu][]', 'csdldatrienkhai[he_dieu_hanh][]', 'csdldatrienkhai[nhucau][]', '16');

-- ----------------------------
-- Table structure for csdl_traodoi
-- ----------------------------
DROP TABLE IF EXISTS `csdl_traodoi`;
CREATE TABLE `csdl_traodoi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `linh_vuc` text DEFAULT NULL,
  `don_vi_lien_quan` text DEFAULT NULL,
  `thong_tin_trao_doi` text DEFAULT NULL,
  `tan_suat` text DEFAULT NULL,
  `phuong_thuc` text DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of csdl_traodoi
-- ----------------------------
INSERT INTO `csdl_traodoi` VALUES ('1', '1', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('2', '7', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('4', '9', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('5', '10', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('6', '8', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('7', '11', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('8', '12', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('13', '16', 'csdltraodoi[linh_vuc][]', 'csdltraodoi[don_vi_lien_quan][]', 'csdltraodoi[thong_tin_trao_doi][]', 'csdltraodoi[tan_suat][]', 'csdltraodoi[ghi_chu][]', 'csdltraodoi[ghi_chu][]');
INSERT INTO `csdl_traodoi` VALUES ('14', '16', 'csdltraodoi[linh_vuc][]', 'csdltraodoi[don_vi_lien_quan][]', 'csdltraodoi[thong_tin_trao_doi][]', 'csdltraodoi[tan_suat][]', 'csdltraodoi[ghi_chu][]', 'csdltraodoi[ghi_chu][]');

-- ----------------------------
-- Table structure for maychuvatly
-- ----------------------------
DROP TABLE IF EXISTS `maychuvatly`;
CREATE TABLE `maychuvatly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `model` text DEFAULT NULL,
  `soluong` text DEFAULT NULL,
  `thong_so` text DEFAULT NULL,
  `nam_dau_tu` text DEFAULT NULL,
  `tinh_trang` text DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of maychuvatly
-- ----------------------------
INSERT INTO `maychuvatly` VALUES ('1', '1', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('2', '7', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('4', '9', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('5', '10', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('6', '8', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('7', '11', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('8', '12', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('13', '16', 'maychuvatly[model][]', 'maychuvatly[soluong][]', 'maychuvatly[thong_so][]', 'maychuvatly[nam_dau_tu][]', 'maychuvatly[tinh_trang][]', 'maychuvatly[ghi_chu][]');
INSERT INTO `maychuvatly` VALUES ('14', '16', 'maychuvatly[model][]', 'maychuvatly[soluong][]', 'maychuvatly[thong_so][]', 'maychuvatly[nam_dau_tu][]', 'maychuvatly[tinh_trang][]', 'maychuvatly[ghi_chu][]');

-- ----------------------------
-- Table structure for nghiepvu_lienthong_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_lienthong_survey`;
CREATE TABLE `nghiepvu_lienthong_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text DEFAULT NULL,
  `nhu_cau_tin_hoc` text DEFAULT NULL,
  `coquan` text DEFAULT NULL,
  `ten_nghiep_vu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_lienthong_survey
-- ----------------------------
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('1', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('2', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('3', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('4', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('5', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('6', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('7', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('8', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('9', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('10', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('11', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('12', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('13', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('14', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('15', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('16', '2', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('17', '2', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('18', '2', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('19', '2', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('20', '2', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('21', '2', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('22', '2', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('23', '2', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('24', '2', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('25', '2', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('26', '2', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('27', '2', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('28', '2', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('29', '2', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('30', '2', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('31', '3', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('32', '3', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('33', '3', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('34', '3', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('35', '3', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('36', '3', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('37', '3', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('38', '3', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('39', '3', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('40', '3', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('41', '3', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('42', '3', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('43', '3', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('44', '3', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('45', '3', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('46', '4', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('47', '4', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('48', '4', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('49', '4', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('50', '4', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('51', '4', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('52', '4', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('53', '4', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('54', '4', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('55', '4', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('56', '4', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('57', '4', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('58', '4', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('59', '4', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('60', '4', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('61', '5', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('62', '5', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('63', '5', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('64', '5', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('65', '5', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('66', '5', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('67', '5', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('68', '5', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('69', '5', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('70', '5', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('71', '5', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('72', '5', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('73', '5', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('74', '5', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('75', '5', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('76', '6', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('77', '6', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('78', '6', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('79', '6', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('80', '6', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('81', '6', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('82', '6', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('83', '6', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('84', '6', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('85', '6', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('86', '6', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('87', '6', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('88', '6', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('89', '6', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('90', '6', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('91', '7', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('92', '7', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('93', '7', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('94', '7', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('95', '7', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('96', '7', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('97', '7', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('98', '7', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('99', '7', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('100', '7', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('101', '7', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('102', '7', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('103', '7', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('104', '7', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('105', '7', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('121', '9', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('122', '9', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('123', '9', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('124', '9', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('125', '9', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('126', '9', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('127', '9', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('128', '9', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('129', '9', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('130', '9', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('131', '9', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('132', '9', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('133', '9', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('134', '9', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('135', '9', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('136', '10', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('137', '10', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('138', '10', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('139', '10', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('140', '10', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('141', '10', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('142', '10', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('143', '10', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('144', '10', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('145', '10', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('146', '10', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('147', '10', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('148', '10', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('149', '10', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('150', '10', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('151', '8', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('152', '8', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('153', '8', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('154', '8', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('155', '8', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('156', '8', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('157', '8', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('158', '8', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('159', '8', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('160', '8', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('161', '8', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('162', '8', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('163', '8', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('164', '8', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('165', '8', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('166', '11', '1', '1', '', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('167', '11', '1', '1', '', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('168', '11', '1', '1', '', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('169', '11', '1', '1', '', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('170', '11', '1', '1', '', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('171', '11', '1', '1', '', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('172', '11', '1', '1', '', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('173', '11', '1', '1', '', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('174', '11', '1', '1', '', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('175', '11', '1', '1', '', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('176', '11', '1', '1', '', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('177', '11', '1', '1', '', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('178', '11', '1', '1', '', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('179', '11', '1', '1', '', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('180', '11', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('181', '12', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('182', '12', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('183', '12', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('184', '12', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('185', '12', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('186', '12', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('187', '12', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('188', '12', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('189', '12', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('190', '12', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('191', '12', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('192', '12', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('193', '12', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('194', '12', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('195', '12', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('256', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('257', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('258', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('259', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('260', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('261', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('262', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('263', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('264', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('265', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('266', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('267', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('268', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('269', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('270', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'nghiepvulienthong[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('271', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('272', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('273', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('274', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('275', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('276', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('277', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('278', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('279', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('280', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('281', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('282', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('283', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('284', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('285', '16', '1', '1', 'nghiepvulienthong[coquan][]', 'nghiepvulienthong[ten_nghiep_vu][]');

-- ----------------------------
-- Table structure for nghiepvu_noibo_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_noibo_survey`;
CREATE TABLE `nghiepvu_noibo_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text DEFAULT NULL,
  `nhu_cau_tin_hoc` text DEFAULT NULL,
  `ten_nghiep_vu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_noibo_survey
-- ----------------------------
INSERT INTO `nghiepvu_noibo_survey` VALUES ('1', '1', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('2', '1', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('3', '1', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('4', '1', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('5', '1', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('6', '1', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('7', '1', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('8', '1', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('9', '1', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('10', '1', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('11', '1', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('12', '1', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('13', '1', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('14', '1', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('15', '1', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('16', '2', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('17', '2', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('18', '2', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('19', '2', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('20', '2', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('21', '2', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('22', '2', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('23', '2', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('24', '2', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('25', '2', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('26', '2', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('27', '2', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('28', '2', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('29', '2', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('30', '2', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('31', '3', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('32', '3', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('33', '3', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('34', '3', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('35', '3', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('36', '3', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('37', '3', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('38', '3', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('39', '3', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('40', '3', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('41', '3', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('42', '3', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('43', '3', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('44', '3', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('45', '3', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('46', '4', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('47', '4', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('48', '4', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('49', '4', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('50', '4', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('51', '4', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('52', '4', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('53', '4', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('54', '4', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('55', '4', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('56', '4', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('57', '4', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('58', '4', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('59', '4', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('60', '4', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('61', '5', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('62', '5', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('63', '5', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('64', '5', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('65', '5', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('66', '5', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('67', '5', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('68', '5', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('69', '5', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('70', '5', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('71', '5', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('72', '5', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('73', '5', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('74', '5', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('75', '5', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('76', '6', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('77', '6', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('78', '6', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('79', '6', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('80', '6', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('81', '6', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('82', '6', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('83', '6', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('84', '6', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('85', '6', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('86', '6', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('87', '6', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('88', '6', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('89', '6', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('90', '6', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('91', '7', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('92', '7', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('93', '7', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('94', '7', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('95', '7', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('96', '7', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('97', '7', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('98', '7', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('99', '7', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('100', '7', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('101', '7', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('102', '7', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('103', '7', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('104', '7', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('105', '7', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('121', '9', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('122', '9', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('123', '9', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('124', '9', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('125', '9', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('126', '9', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('127', '9', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('128', '9', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('129', '9', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('130', '9', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('131', '9', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('132', '9', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('133', '9', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('134', '9', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('135', '9', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('136', '10', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('137', '10', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('138', '10', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('139', '10', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('140', '10', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('141', '10', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('142', '10', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('143', '10', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('144', '10', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('145', '10', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('146', '10', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('147', '10', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('148', '10', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('149', '10', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('150', '10', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('151', '8', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('152', '8', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('153', '8', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('154', '8', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('155', '8', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('156', '8', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('157', '8', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('158', '8', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('159', '8', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('160', '8', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('161', '8', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('162', '8', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('163', '8', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('164', '8', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('165', '8', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('166', '11', '', '1', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('167', '11', '', '1', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('168', '11', '', '1', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('169', '11', '', '1', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('170', '11', '', '1', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('171', '11', '', '1', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('172', '11', '', '1', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('173', '11', '', '1', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('174', '11', '', '1', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('175', '11', '', '1', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('176', '11', '', '1', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('177', '11', '', '1', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('178', '11', '', '1', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('179', '11', '', '1', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('180', '11', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('181', '12', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('182', '12', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('183', '12', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('184', '12', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('185', '12', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('186', '12', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('187', '12', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('188', '12', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('189', '12', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('190', '12', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('191', '12', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('192', '12', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('193', '12', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('194', '12', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('195', '12', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('256', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('257', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('258', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('259', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('260', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('261', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('262', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('263', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('264', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('265', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('266', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('267', '16', 'nghiepvunoibo[hien_trang][]', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('268', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('269', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('270', '16', 'nghiepvunoibo[hien_trang][]', '1', 'nghiepvunoibo[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('271', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('272', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('273', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('274', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('275', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('276', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('277', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('278', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('279', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('280', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('281', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('282', '16', 'nghiepvunoibo[hien_trang][]', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('283', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('284', '16', 'nghiepvunoibo[hien_trang][]', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('285', '16', 'nghiepvunoibo[hien_trang][]', '1', 'nghiepvunoibo[ten_nghiep_vu][]');

-- ----------------------------
-- Table structure for nghiepvu_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_survey`;
CREATE TABLE `nghiepvu_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text DEFAULT NULL,
  `nhu_cau_tin_hoc` text DEFAULT NULL,
  `ten_nghiep_vu` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_survey
-- ----------------------------
INSERT INTO `nghiepvu_survey` VALUES ('1', '1', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('2', '1', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('3', '1', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('4', '1', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('5', '1', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('6', '1', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('7', '1', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('8', '1', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('9', '1', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('10', '1', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('11', '1', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('12', '1', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('13', '1', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('14', '1', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('15', '1', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('16', '2', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('17', '2', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('18', '2', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('19', '2', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('20', '2', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('21', '2', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('22', '2', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('23', '2', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('24', '2', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('25', '2', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('26', '2', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('27', '2', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('28', '2', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('29', '2', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('30', '2', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('31', '3', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('32', '3', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('33', '3', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('34', '3', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('35', '3', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('36', '3', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('37', '3', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('38', '3', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('39', '3', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('40', '3', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('41', '3', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('42', '3', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('43', '3', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('44', '3', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('45', '3', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('46', '4', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('47', '4', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('48', '4', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('49', '4', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('50', '4', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('51', '4', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('52', '4', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('53', '4', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('54', '4', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('55', '4', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('56', '4', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('57', '4', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('58', '4', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('59', '4', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('60', '4', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('61', '5', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('62', '5', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('63', '5', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('64', '5', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('65', '5', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('66', '5', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('67', '5', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('68', '5', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('69', '5', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('70', '5', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('71', '5', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('72', '5', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('73', '5', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('74', '5', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('75', '5', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('76', '6', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('77', '6', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('78', '6', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('79', '6', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('80', '6', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('81', '6', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('82', '6', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('83', '6', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('84', '6', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('85', '6', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('86', '6', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('87', '6', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('88', '6', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('89', '6', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('90', '6', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('91', '7', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('92', '7', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('93', '7', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('94', '7', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('95', '7', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('96', '7', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('97', '7', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('98', '7', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('99', '7', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('100', '7', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('101', '7', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('102', '7', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('103', '7', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('104', '7', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('105', '7', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('121', '9', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('122', '9', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('123', '9', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('124', '9', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('125', '9', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('126', '9', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('127', '9', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('128', '9', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('129', '9', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('130', '9', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('131', '9', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('132', '9', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('133', '9', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('134', '9', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('135', '9', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('136', '10', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('137', '10', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('138', '10', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('139', '10', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('140', '10', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('141', '10', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('142', '10', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('143', '10', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('144', '10', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('145', '10', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('146', '10', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('147', '10', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('148', '10', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('149', '10', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('150', '10', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('151', '8', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('152', '8', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('153', '8', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('154', '8', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('155', '8', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('156', '8', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('157', '8', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('158', '8', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('159', '8', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('160', '8', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('161', '8', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('162', '8', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('163', '8', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('164', '8', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('165', '8', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('166', '11', '1', '1', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_survey` VALUES ('167', '11', '1', '1', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_survey` VALUES ('168', '11', '1', '1', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_survey` VALUES ('169', '11', '1', '1', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_survey` VALUES ('170', '11', '1', '1', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_survey` VALUES ('171', '11', '1', '1', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_survey` VALUES ('172', '11', '1', '1', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_survey` VALUES ('173', '11', '1', '1', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_survey` VALUES ('174', '11', '1', '1', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_survey` VALUES ('175', '11', '1', '1', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_survey` VALUES ('176', '11', '1', '1', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_survey` VALUES ('177', '11', '1', '1', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_survey` VALUES ('178', '11', '1', '1', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_survey` VALUES ('179', '11', '1', '1', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_survey` VALUES ('180', '11', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('181', '12', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('182', '12', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('183', '12', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('184', '12', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('185', '12', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('186', '12', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('187', '12', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('188', '12', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('189', '12', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('190', '12', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('191', '12', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('192', '12', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('193', '12', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('194', '12', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('195', '12', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('256', '16', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('257', '16', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('258', '16', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('259', '16', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('260', '16', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('261', '16', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('262', '16', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('263', '16', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('264', '16', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('265', '16', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('266', '16', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('267', '16', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('268', '16', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('269', '16', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('270', '16', '1', '1', 'nghiepvu[ten_nghiep_vu][]');
INSERT INTO `nghiepvu_survey` VALUES ('271', '16', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('272', '16', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('273', '16', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('274', '16', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('275', '16', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('276', '16', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('277', '16', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('278', '16', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('279', '16', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('280', '16', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('281', '16', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('282', '16', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('283', '16', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('284', '16', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('285', '16', '1', '1', 'nghiepvu[ten_nghiep_vu][]');

-- ----------------------------
-- Table structure for ungdungcntt_dangtrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_dangtrienkhai`;
CREATE TABLE `ungdungcntt_dangtrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_duan` text DEFAULT NULL,
  `muctieu` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `quymo` text DEFAULT NULL,
  `tongmucdautu` text DEFAULT NULL,
  `noidung` text DEFAULT NULL,
  `ghichu` text DEFAULT NULL,
  `thoigianthuchien` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_dangtrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('1', '', '', '1', '', '', '', '', null);
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('2', '', '', '7', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('4', '', '', '9', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('5', '', '', '10', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('6', '', '', '8', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('7', '', '', '11', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('8', '', '', '12', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('13', 'udcnttdangtrienkhai[ten_duan][]', 'udcnttdangtrienkhai[muctieu][]', '16', 'udcnttdangtrienkhai[quymo][]', 'udcnttdangtrienkhai[tongmucdautu][]', 'udcnttdangtrienkhai[noidung][]', 'udcnttdangtrienkhai[ghichu][]', 'udcnttdangtrienkhai[thoigianthuchien][]');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('14', 'udcnttdangtrienkhai[ten_duan][]', 'udcnttdangtrienkhai[muctieu][]', '16', 'udcnttdangtrienkhai[quymo][]', 'udcnttdangtrienkhai[tongmucdautu][]', 'udcnttdangtrienkhai[noidung][]', 'udcnttdangtrienkhai[ghichu][]', 'udcnttdangtrienkhai[thoigianthuchien][]');

-- ----------------------------
-- Table structure for ungdungcntt_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_datrienkhai`;
CREATE TABLE `ungdungcntt_datrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phan_mem` text DEFAULT NULL,
  `mo_ta_chung` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `doituongsudung` text DEFAULT NULL,
  `nhucau` text DEFAULT NULL,
  `nguyennhan` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_datrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('1', '', '', '1', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('2', '', '', '2', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('3', '', '', '3', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('4', '', '', '4', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('5', '', '', '5', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('6', '', '', '6', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('7', '', '', '7', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('9', '', '', '9', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('10', '', '', '10', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('11', '', '', '8', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('12', '', '', '11', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('13', '', '', '12', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('18', 'udcnttdatrienkhai[ten_phan_mem][]', 'udcnttdatrienkhai[mo_ta_chung][]', '16', 'udcnttdatrienkhai[doituongsudung][]', 'udcnttdatrienkhai[nhucau][]', 'udcnttdatrienkhai[nguyennhan][]');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('19', 'udcnttdatrienkhai[ten_phan_mem][]', 'udcnttdatrienkhai[mo_ta_chung][]', '16', 'udcnttdatrienkhai[doituongsudung][]', 'udcnttdatrienkhai[nhucau][]', 'udcnttdatrienkhai[nguyennhan][]');

-- ----------------------------
-- Table structure for ungdungcntt_yeucau
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_yeucau`;
CREATE TABLE `ungdungcntt_yeucau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yeucau` text DEFAULT NULL,
  `ungdungdexuat` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_yeucau
-- ----------------------------
INSERT INTO `ungdungcntt_yeucau` VALUES ('1', '', '', '1');
INSERT INTO `ungdungcntt_yeucau` VALUES ('2', '', '', '2');
INSERT INTO `ungdungcntt_yeucau` VALUES ('3', '', '', '3');
INSERT INTO `ungdungcntt_yeucau` VALUES ('4', '', '', '5');
INSERT INTO `ungdungcntt_yeucau` VALUES ('5', '', '', '6');
INSERT INTO `ungdungcntt_yeucau` VALUES ('6', '', '', '7');
INSERT INTO `ungdungcntt_yeucau` VALUES ('8', '', '', '9');
INSERT INTO `ungdungcntt_yeucau` VALUES ('9', '', '', '10');
INSERT INTO `ungdungcntt_yeucau` VALUES ('10', '', '', '8');
INSERT INTO `ungdungcntt_yeucau` VALUES ('11', '', '', '11');
INSERT INTO `ungdungcntt_yeucau` VALUES ('12', '', '', '12');
INSERT INTO `ungdungcntt_yeucau` VALUES ('17', 'udcnttyeucau[yeucau][]', 'udcnttyeucau[ungdungdexuat][]', '16');
INSERT INTO `ungdungcntt_yeucau` VALUES ('18', 'udcnttyeucau[yeucau][]', 'udcnttyeucau[ungdungdexuat][]', '16');

-- ----------------------------
-- Table structure for userkhaosat
-- ----------------------------
DROP TABLE IF EXISTS `userkhaosat`;
CREATE TABLE `userkhaosat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) DEFAULT NULL,
  `donvikhaosat` text DEFAULT NULL,
  `thoigian` text DEFAULT NULL,
  `so_dien_thoai` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `bo_phan_khao_sat` text DEFAULT NULL,
  `dai_dien` text DEFAULT NULL,
  `chuc_vu` text DEFAULT NULL,
  `matkhau` text DEFAULT NULL,
  `danh_sach_chuc_nang_nghiep_vu_file` text DEFAULT NULL,
  `danh_sach_chuc_nang_nghiep_vu_txt` text DEFAULT NULL,
  `kho_khan_nghiep_vu` text DEFAULT NULL,
  `hai_dich_vu_truc_tuyen` text DEFAULT NULL,
  `hai_phan_mem_thu_dien_tu` text DEFAULT NULL,
  `hai_quy_che_thu_dien_tu` text DEFAULT NULL,
  `hai_so_luong_cap_thu` text DEFAULT NULL,
  `hai_ty_le_dung_thu` text DEFAULT NULL,
  `hai_ty_le_phan_tram_thu` text DEFAULT NULL,
  `hai_thu_cong_cong` text DEFAULT NULL,
  `phong_may_chu` text DEFAULT NULL,
  `moi_truong_du_phong` text DEFAULT NULL,
  `may_chu_mo_rong` text DEFAULT NULL,
  `may_chu_sao_luu` text DEFAULT NULL,
  `nam_bo_phan_chuyen_trach` text DEFAULT NULL,
  `tong_so_cb_chuyen_trach` text DEFAULT NULL,
  `tong_so_cb_kiem_nhiem` text DEFAULT NULL,
  `tong_so_cntt_kiem_nhiem` text DEFAULT NULL,
  `su_dung_pm_van_phong` text DEFAULT NULL,
  `tiensi` text DEFAULT NULL,
  `thacsi` text DEFAULT NULL,
  `daihoc` text DEFAULT NULL,
  `caodang` text DEFAULT NULL,
  `trungcap` text DEFAULT NULL,
  `ykien_khokhan` text DEFAULT NULL,
  `ykien_thuanloi` text DEFAULT NULL,
  `ykien_dexuat` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of userkhaosat
-- ----------------------------
INSERT INTO `userkhaosat` VALUES ('10', 'Đỗ xuân đạt', 'DH VN', '0000-00-00 00:00:00', '12345', 'doxuan_dat@yahoo.com', 'sdfsd', 'sdfsd', 'fsdfsdf', null, '', '', '', '', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('12', 'lê thùy linh', 'đại học văn hóa', '0000-00-00 00:00:00', '1234', 'datdx2@fpt.com.vn', 'IT', 'đỗ xuân đạt', 'se', null, '', '', '', '', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('13', 'nguyễn tuấn vinh 11', 'đại học công nghiệp 11', '19/03/2020 16:51', '12345678', 'vinh@gmail.com', 'quản lý', 'văn chi', 'lead', null, '', '', '', '111', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('14', 'nguyễn tuấn vinh 2', 'đại học công nghiệp', '17/03/2020 16:58', '12345678', 'vinh@gmail.com', 'quản lý', 'văn chi', 'lead', 'defac44447b57f152d14f30cea7a73cb', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('15', 'ngọc ánh', 'neu', '18/03/2020 20:14', '0123', 'anh@gmail.com', 'cc', 'cc', 'cc', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('16', 'huong', 'huong', '19/03/2020 20:17', 'so_dien_thoai', 'example@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', '', 'danh_sach_chuc_nang_nghiep_vu_txt', 'kho_khan_nghiep_vu', 'hai_dich_vu_truc_tuyen', 'hai_phan_mem_thu_dien_tu', 'hai_quy_che_thu_dien_tu', 'hai_so_luong_cap_thu', 'hai_ty_le_dung_thu', 'hai_ty_le_phan_tram_thu', 'hai_thu_cong_cong', '3', '3', '2', '2', 'nam_bo_phan_chuyen_trach', 'tong_so_cb_chuyen_trach', 'tong_so_cb_kiem_nhiem', 'tong_so_cntt_kiem_nhiem', 'su_dung_pm_van_phong', 'tiensi', 'thacsi', 'daihoc', 'caodang', 'trungcap', 'ykien_khokhan', 'ykien_thuanloi', 'ykien_dexuat');
INSERT INTO `userkhaosat` VALUES ('17', 'huong', 'huong', '19/03/2020 20:17', 'so_dien_thoai', 'example@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('18', 'huong', 'huong', '19/03/2020 20:17', 'so_dien_thoai', 'example@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `userkhaosat` VALUES ('19', 'ten', 'fsdfsdf', 'thoigian', '0123455566', 'example11@example.com', 'bo_phan_khao_sat', 'dai_dien', 'chuc_vu', '202cb962ac59075b964b07152d234b70', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for v_nhu_cau_dao_tao
-- ----------------------------
DROP TABLE IF EXISTS `v_nhu_cau_dao_tao`;
CREATE TABLE `v_nhu_cau_dao_tao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_daotao` text DEFAULT NULL,
  `muc_do_uu_tien` text DEFAULT NULL,
  `user_id_answer` int(11) DEFAULT NULL,
  `soluong_hocvien` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of v_nhu_cau_dao_tao
-- ----------------------------
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('1', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('2', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('3', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('4', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('5', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('6', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('7', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('8', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('9', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('10', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('11', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('12', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('13', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('14', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('15', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('16', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('25', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('26', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('27', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('28', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('29', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('30', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('31', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('32', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('33', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('34', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('35', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('36', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('37', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('38', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('39', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('40', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('41', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('42', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('43', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('44', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('45', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('46', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('47', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('48', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('49', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng sá»­ dá»¥ng cÃ¡c há»‡ thá»‘ng á»©ng dá»¥ng cho cÃ¡c cÃ¡n bá»™ nghiá»‡p vá»¥', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('50', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('51', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('52', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('53', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng nÃ¢ng cao trÃ¬nh Ä‘á»™ CNTT', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('54', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('55', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('56', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('57', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('58', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('59', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('60', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('61', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('62', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('63', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('64', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('97', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('98', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('99', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('100', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('101', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('102', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('103', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('104', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('105', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('106', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('107', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('108', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('109', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('110', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('111', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('112', 'nhucaudaotao[noidung_daotao][]', 'nhucaudaotao[muc_do_uu_tien][]', '16', 'nhucaudaotao[soluong_hocvien][]');
