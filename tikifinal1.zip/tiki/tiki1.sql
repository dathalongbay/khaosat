/*
Navicat MySQL Data Transfer

Source Server         : 111
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : tiki1

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-03-19 17:35:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('2', 'admin@gmail.com', 'ce3ac1807677ee36943b210356f517f9');

-- ----------------------------
-- Table structure for csdl_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `csdl_datrienkhai`;
CREATE TABLE `csdl_datrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_csdl` text,
  `he_csdl` text,
  `ban_quyen` text,
  `nam_dau_tu` text,
  `he_dieu_hanh` text,
  `nhucau` text,
  `user_id_answer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of csdl_datrienkhai
-- ----------------------------
INSERT INTO `csdl_datrienkhai` VALUES ('1', null, null, null, '', '', '', '1');
INSERT INTO `csdl_datrienkhai` VALUES ('2', null, null, null, '', '', '', '7');
INSERT INTO `csdl_datrienkhai` VALUES ('4', null, null, null, '', '', '', '9');
INSERT INTO `csdl_datrienkhai` VALUES ('5', '', '', '', '', '', '', '10');
INSERT INTO `csdl_datrienkhai` VALUES ('6', '', '', '', '', '', '', '8');
INSERT INTO `csdl_datrienkhai` VALUES ('7', '', '', '', '', '', '', '11');
INSERT INTO `csdl_datrienkhai` VALUES ('8', '', '', '', '', '', '', '12');

-- ----------------------------
-- Table structure for csdl_traodoi
-- ----------------------------
DROP TABLE IF EXISTS `csdl_traodoi`;
CREATE TABLE `csdl_traodoi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `linh_vuc` text,
  `don_vi_lien_quan` text,
  `thong_tin_trao_doi` text,
  `tan_suat` text,
  `phuong_thuc` text,
  `ghi_chu` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of csdl_traodoi
-- ----------------------------
INSERT INTO `csdl_traodoi` VALUES ('1', '1', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('2', '7', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('4', '9', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('5', '10', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('6', '8', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('7', '11', '', '', '', '', '', '');
INSERT INTO `csdl_traodoi` VALUES ('8', '12', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for maychuvatly
-- ----------------------------
DROP TABLE IF EXISTS `maychuvatly`;
CREATE TABLE `maychuvatly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `model` text,
  `soluong` text,
  `thong_so` text,
  `nam_dau_tu` text,
  `tinh_trang` text,
  `ghi_chu` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of maychuvatly
-- ----------------------------
INSERT INTO `maychuvatly` VALUES ('1', '1', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('2', '7', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('4', '9', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('5', '10', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('6', '8', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('7', '11', '', '', '', '', '', '');
INSERT INTO `maychuvatly` VALUES ('8', '12', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for nghiepvu_lienthong_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_lienthong_survey`;
CREATE TABLE `nghiepvu_lienthong_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text,
  `nhu_cau_tin_hoc` text,
  `coquan` text,
  `ten_nghiep_vu` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_lienthong_survey
-- ----------------------------
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('1', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('2', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('3', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('4', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('5', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('6', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('7', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('8', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('9', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('10', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('11', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('12', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('13', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('14', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('15', '1', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('16', '2', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('17', '2', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('18', '2', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('19', '2', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('20', '2', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('21', '2', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('22', '2', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('23', '2', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('24', '2', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('25', '2', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('26', '2', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('27', '2', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('28', '2', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('29', '2', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('30', '2', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('31', '3', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('32', '3', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('33', '3', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('34', '3', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('35', '3', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('36', '3', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('37', '3', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('38', '3', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('39', '3', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('40', '3', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('41', '3', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('42', '3', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('43', '3', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('44', '3', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('45', '3', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('46', '4', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('47', '4', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('48', '4', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('49', '4', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('50', '4', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('51', '4', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('52', '4', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('53', '4', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('54', '4', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('55', '4', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('56', '4', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('57', '4', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('58', '4', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('59', '4', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('60', '4', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('61', '5', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('62', '5', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('63', '5', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('64', '5', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('65', '5', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('66', '5', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('67', '5', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('68', '5', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('69', '5', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('70', '5', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('71', '5', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('72', '5', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('73', '5', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('74', '5', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('75', '5', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('76', '6', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('77', '6', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('78', '6', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('79', '6', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('80', '6', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('81', '6', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('82', '6', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('83', '6', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('84', '6', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('85', '6', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('86', '6', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('87', '6', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('88', '6', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('89', '6', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('90', '6', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('91', '7', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('92', '7', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('93', '7', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('94', '7', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('95', '7', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('96', '7', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('97', '7', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('98', '7', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('99', '7', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('100', '7', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('101', '7', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('102', '7', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('103', '7', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('104', '7', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('105', '7', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('121', '9', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('122', '9', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('123', '9', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('124', '9', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('125', '9', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('126', '9', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('127', '9', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('128', '9', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('129', '9', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('130', '9', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('131', '9', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('132', '9', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('133', '9', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('134', '9', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('135', '9', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('136', '10', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('137', '10', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('138', '10', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('139', '10', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('140', '10', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('141', '10', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('142', '10', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('143', '10', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('144', '10', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('145', '10', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('146', '10', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('147', '10', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('148', '10', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('149', '10', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('150', '10', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('151', '8', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('152', '8', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('153', '8', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('154', '8', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('155', '8', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('156', '8', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('157', '8', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('158', '8', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('159', '8', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('160', '8', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('161', '8', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('162', '8', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('163', '8', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('164', '8', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('165', '8', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('166', '11', '1', '1', '', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('167', '11', '1', '1', '', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('168', '11', '1', '1', '', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('169', '11', '1', '1', '', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('170', '11', '1', '1', '', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('171', '11', '1', '1', '', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('172', '11', '1', '1', '', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('173', '11', '1', '1', '', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('174', '11', '1', '1', '', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('175', '11', '1', '1', '', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('176', '11', '1', '1', '', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('177', '11', '1', '1', '', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('178', '11', '1', '1', '', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('179', '11', '1', '1', '', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('180', '11', '1', '1', '', '');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('181', '12', '1', '1', '', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('182', '12', '1', '1', '', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('183', '12', '1', '1', '', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('184', '12', '1', '1', '', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('185', '12', '1', '1', '', 'Quản lý học vụ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('186', '12', '1', '1', '', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('187', '12', '1', '1', '', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('188', '12', '1', '1', '', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('189', '12', '1', '1', '', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('190', '12', '1', '1', '', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('191', '12', '1', '1', '', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('192', '12', '1', '1', '', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('193', '12', '1', '1', '', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('194', '12', '1', '1', '', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_lienthong_survey` VALUES ('195', '12', '1', '1', '', '');

-- ----------------------------
-- Table structure for nghiepvu_noibo_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_noibo_survey`;
CREATE TABLE `nghiepvu_noibo_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text,
  `nhu_cau_tin_hoc` text,
  `ten_nghiep_vu` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_noibo_survey
-- ----------------------------
INSERT INTO `nghiepvu_noibo_survey` VALUES ('1', '1', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('2', '1', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('3', '1', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('4', '1', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('5', '1', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('6', '1', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('7', '1', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('8', '1', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('9', '1', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('10', '1', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('11', '1', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('12', '1', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('13', '1', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('14', '1', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('15', '1', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('16', '2', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('17', '2', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('18', '2', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('19', '2', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('20', '2', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('21', '2', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('22', '2', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('23', '2', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('24', '2', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('25', '2', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('26', '2', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('27', '2', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('28', '2', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('29', '2', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('30', '2', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('31', '3', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('32', '3', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('33', '3', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('34', '3', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('35', '3', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('36', '3', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('37', '3', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('38', '3', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('39', '3', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('40', '3', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('41', '3', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('42', '3', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('43', '3', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('44', '3', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('45', '3', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('46', '4', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('47', '4', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('48', '4', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('49', '4', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('50', '4', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('51', '4', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('52', '4', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('53', '4', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('54', '4', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('55', '4', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('56', '4', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('57', '4', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('58', '4', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('59', '4', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('60', '4', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('61', '5', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('62', '5', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('63', '5', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('64', '5', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('65', '5', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('66', '5', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('67', '5', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('68', '5', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('69', '5', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('70', '5', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('71', '5', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('72', '5', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('73', '5', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('74', '5', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('75', '5', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('76', '6', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('77', '6', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('78', '6', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('79', '6', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('80', '6', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('81', '6', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('82', '6', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('83', '6', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('84', '6', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('85', '6', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('86', '6', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('87', '6', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('88', '6', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('89', '6', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('90', '6', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('91', '7', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('92', '7', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('93', '7', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('94', '7', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('95', '7', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('96', '7', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('97', '7', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('98', '7', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('99', '7', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('100', '7', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('101', '7', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('102', '7', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('103', '7', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('104', '7', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('105', '7', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('121', '9', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('122', '9', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('123', '9', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('124', '9', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('125', '9', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('126', '9', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('127', '9', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('128', '9', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('129', '9', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('130', '9', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('131', '9', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('132', '9', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('133', '9', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('134', '9', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('135', '9', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('136', '10', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('137', '10', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('138', '10', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('139', '10', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('140', '10', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('141', '10', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('142', '10', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('143', '10', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('144', '10', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('145', '10', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('146', '10', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('147', '10', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('148', '10', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('149', '10', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('150', '10', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('151', '8', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('152', '8', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('153', '8', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('154', '8', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('155', '8', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('156', '8', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('157', '8', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('158', '8', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('159', '8', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('160', '8', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('161', '8', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('162', '8', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('163', '8', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('164', '8', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('165', '8', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('166', '11', '', '1', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('167', '11', '', '1', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('168', '11', '', '1', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('169', '11', '', '1', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('170', '11', '', '1', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('171', '11', '', '1', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('172', '11', '', '1', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('173', '11', '', '1', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('174', '11', '', '1', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('175', '11', '', '1', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('176', '11', '', '1', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('177', '11', '', '1', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('178', '11', '', '1', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('179', '11', '', '1', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('180', '11', '', '1', '');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('181', '12', '', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('182', '12', '', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('183', '12', '', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('184', '12', '', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('185', '12', '', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('186', '12', '', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('187', '12', '', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('188', '12', '', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('189', '12', '', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('190', '12', '', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('191', '12', '', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('192', '12', '', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('193', '12', '', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('194', '12', '', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_noibo_survey` VALUES ('195', '12', '', '1', '');

-- ----------------------------
-- Table structure for nghiepvu_survey
-- ----------------------------
DROP TABLE IF EXISTS `nghiepvu_survey`;
CREATE TABLE `nghiepvu_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id_answer` int(11) DEFAULT NULL,
  `hien_trang` text,
  `nhu_cau_tin_hoc` text,
  `ten_nghiep_vu` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of nghiepvu_survey
-- ----------------------------
INSERT INTO `nghiepvu_survey` VALUES ('1', '1', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('2', '1', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('3', '1', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('4', '1', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('5', '1', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('6', '1', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('7', '1', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('8', '1', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('9', '1', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('10', '1', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('11', '1', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('12', '1', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('13', '1', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('14', '1', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('15', '1', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('16', '2', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('17', '2', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('18', '2', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('19', '2', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('20', '2', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('21', '2', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('22', '2', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('23', '2', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('24', '2', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('25', '2', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('26', '2', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('27', '2', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('28', '2', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('29', '2', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('30', '2', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('31', '3', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('32', '3', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('33', '3', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('34', '3', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('35', '3', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('36', '3', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('37', '3', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('38', '3', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('39', '3', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('40', '3', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('41', '3', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('42', '3', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('43', '3', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('44', '3', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('45', '3', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('46', '4', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('47', '4', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('48', '4', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('49', '4', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('50', '4', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('51', '4', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('52', '4', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('53', '4', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('54', '4', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('55', '4', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('56', '4', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('57', '4', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('58', '4', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('59', '4', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('60', '4', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('61', '5', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('62', '5', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('63', '5', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('64', '5', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('65', '5', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('66', '5', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('67', '5', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('68', '5', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('69', '5', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('70', '5', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('71', '5', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('72', '5', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('73', '5', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('74', '5', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('75', '5', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('76', '6', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('77', '6', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('78', '6', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('79', '6', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('80', '6', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('81', '6', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('82', '6', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('83', '6', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('84', '6', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('85', '6', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('86', '6', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('87', '6', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('88', '6', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('89', '6', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('90', '6', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('91', '7', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('92', '7', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('93', '7', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('94', '7', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('95', '7', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('96', '7', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('97', '7', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('98', '7', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('99', '7', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('100', '7', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('101', '7', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('102', '7', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('103', '7', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('104', '7', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('105', '7', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('121', '9', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('122', '9', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('123', '9', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('124', '9', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('125', '9', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('126', '9', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('127', '9', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('128', '9', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('129', '9', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('130', '9', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('131', '9', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('132', '9', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('133', '9', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('134', '9', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('135', '9', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('136', '10', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('137', '10', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('138', '10', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('139', '10', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('140', '10', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('141', '10', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('142', '10', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('143', '10', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('144', '10', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('145', '10', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('146', '10', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('147', '10', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('148', '10', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('149', '10', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('150', '10', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('151', '8', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('152', '8', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('153', '8', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('154', '8', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('155', '8', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('156', '8', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('157', '8', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('158', '8', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('159', '8', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('160', '8', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('161', '8', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('162', '8', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('163', '8', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('164', '8', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('165', '8', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('166', '11', '1', '1', 'Quáº£n lÃ½ hÃ nh chÃ­nh Ä‘iá»‡n tá»­ - cÃ¡c há»‡ thá»‘ng bÃ¡o cÃ¡o sá»‘ liá»‡u');
INSERT INTO `nghiepvu_survey` VALUES ('167', '11', '1', '1', 'Quáº£n lÃ½ Tuyá»ƒn sinh');
INSERT INTO `nghiepvu_survey` VALUES ('168', '11', '1', '1', 'Quáº£n lÃ½ Thá»i khÃ³a biá»ƒu â€“ káº¿ hoáº¡ch giáº£ng dáº¡y');
INSERT INTO `nghiepvu_survey` VALUES ('169', '11', '1', '1', 'Quáº£n lÃ½ CÃ´ng tÃ¡c Sinh viÃªn');
INSERT INTO `nghiepvu_survey` VALUES ('170', '11', '1', '1', 'Quáº£n lÃ½ há»c vá»¥');
INSERT INTO `nghiepvu_survey` VALUES ('171', '11', '1', '1', 'Quáº£n lÃ½ kháº£o thÃ­ â€“ TrÃ¡c nghiá»‡m');
INSERT INTO `nghiepvu_survey` VALUES ('172', '11', '1', '1', 'Quáº£n lÃ½ TÃ i chÃ­nh ');
INSERT INTO `nghiepvu_survey` VALUES ('173', '11', '1', '1', 'Quáº£n lÃ½ LÃ½ tÃºc xÃ¡');
INSERT INTO `nghiepvu_survey` VALUES ('174', '11', '1', '1', 'Quáº£n lÃ½ NhÃ¢n sá»± thá»‰nh giáº£ng â€“ Tiá»n CÃ´ng');
INSERT INTO `nghiepvu_survey` VALUES ('175', '11', '1', '1', 'Quáº£n lÃ½ TÃ i sáº£n â€“ Thiáº¿t bá»‹');
INSERT INTO `nghiepvu_survey` VALUES ('176', '11', '1', '1', 'Quáº£n lÃ½ nghiÃªn cá»©u khoa há»c');
INSERT INTO `nghiepvu_survey` VALUES ('177', '11', '1', '1', 'káº¿t ná»‘i cá»™ng Ä‘á»“ng phá»¥ huynh- sinh viÃªn â€“ nhÃ  trÆ°á»ng');
INSERT INTO `nghiepvu_survey` VALUES ('178', '11', '1', '1', 'HÃ³a Ä‘Æ¡n Ä‘iá»‡n tá»­');
INSERT INTO `nghiepvu_survey` VALUES ('179', '11', '1', '1', 'Quáº£n lÃ½ chuyá»ƒn phÃ¡t, Ä‘iá»u hÃ nh xe');
INSERT INTO `nghiepvu_survey` VALUES ('180', '11', '1', '1', '');
INSERT INTO `nghiepvu_survey` VALUES ('181', '12', '1', '1', 'Quản lý hành chính điện tử - các hệ thống báo cáo số liệu');
INSERT INTO `nghiepvu_survey` VALUES ('182', '12', '1', '1', 'Quản lý Tuyển sinh');
INSERT INTO `nghiepvu_survey` VALUES ('183', '12', '1', '1', 'Quản lý Thời khóa biểu – kế hoạch giảng dạy');
INSERT INTO `nghiepvu_survey` VALUES ('184', '12', '1', '1', 'Quản lý Công tác Sinh viên');
INSERT INTO `nghiepvu_survey` VALUES ('185', '12', '1', '1', 'Quản lý học vụ');
INSERT INTO `nghiepvu_survey` VALUES ('186', '12', '1', '1', 'Quản lý khảo thí – Trác nghiệm');
INSERT INTO `nghiepvu_survey` VALUES ('187', '12', '1', '1', 'Quản lý Tài chính ');
INSERT INTO `nghiepvu_survey` VALUES ('188', '12', '1', '1', 'Quản lý Lý túc xá');
INSERT INTO `nghiepvu_survey` VALUES ('189', '12', '1', '1', 'Quản lý Nhân sự thỉnh giảng – Tiền Công');
INSERT INTO `nghiepvu_survey` VALUES ('190', '12', '1', '1', 'Quản lý Tài sản – Thiết bị');
INSERT INTO `nghiepvu_survey` VALUES ('191', '12', '1', '1', 'Quản lý nghiên cứu khoa học');
INSERT INTO `nghiepvu_survey` VALUES ('192', '12', '1', '1', 'kết nối cộng đồng phụ huynh- sinh viên – nhà trường');
INSERT INTO `nghiepvu_survey` VALUES ('193', '12', '1', '1', 'Hóa đơn điện tử');
INSERT INTO `nghiepvu_survey` VALUES ('194', '12', '1', '1', 'Quản lý chuyển phát, điều hành xe');
INSERT INTO `nghiepvu_survey` VALUES ('195', '12', '1', '1', '');

-- ----------------------------
-- Table structure for ungdungcntt_dangtrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_dangtrienkhai`;
CREATE TABLE `ungdungcntt_dangtrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_duan` text,
  `muctieu` text,
  `user_id_answer` int(11) DEFAULT NULL,
  `quymo` text,
  `tongmucdautu` text,
  `noidung` text,
  `ghichu` text,
  `thoigianthuchien` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_dangtrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('1', '', '', '1', '', '', '', '', null);
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('2', '', '', '7', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('4', '', '', '9', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('5', '', '', '10', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('6', '', '', '8', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('7', '', '', '11', '', '', '', '', '');
INSERT INTO `ungdungcntt_dangtrienkhai` VALUES ('8', '', '', '12', '', '', '', '', '');

-- ----------------------------
-- Table structure for ungdungcntt_datrienkhai
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_datrienkhai`;
CREATE TABLE `ungdungcntt_datrienkhai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phan_mem` text,
  `mo_ta_chung` text,
  `user_id_answer` int(11) DEFAULT NULL,
  `doituongsudung` text,
  `nhucau` text,
  `nguyennhan` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_datrienkhai
-- ----------------------------
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('1', '', '', '1', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('2', '', '', '2', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('3', '', '', '3', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('4', '', '', '4', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('5', '', '', '5', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('6', '', '', '6', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('7', '', '', '7', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('9', '', '', '9', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('10', '', '', '10', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('11', '', '', '8', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('12', '', '', '11', '', '', '');
INSERT INTO `ungdungcntt_datrienkhai` VALUES ('13', '', '', '12', '', '', '');

-- ----------------------------
-- Table structure for ungdungcntt_yeucau
-- ----------------------------
DROP TABLE IF EXISTS `ungdungcntt_yeucau`;
CREATE TABLE `ungdungcntt_yeucau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yeucau` text,
  `ungdungdexuat` text,
  `user_id_answer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ungdungcntt_yeucau
-- ----------------------------
INSERT INTO `ungdungcntt_yeucau` VALUES ('1', '', '', '1');
INSERT INTO `ungdungcntt_yeucau` VALUES ('2', '', '', '2');
INSERT INTO `ungdungcntt_yeucau` VALUES ('3', '', '', '3');
INSERT INTO `ungdungcntt_yeucau` VALUES ('4', '', '', '5');
INSERT INTO `ungdungcntt_yeucau` VALUES ('5', '', '', '6');
INSERT INTO `ungdungcntt_yeucau` VALUES ('6', '', '', '7');
INSERT INTO `ungdungcntt_yeucau` VALUES ('8', '', '', '9');
INSERT INTO `ungdungcntt_yeucau` VALUES ('9', '', '', '10');
INSERT INTO `ungdungcntt_yeucau` VALUES ('10', '', '', '8');
INSERT INTO `ungdungcntt_yeucau` VALUES ('11', '', '', '11');
INSERT INTO `ungdungcntt_yeucau` VALUES ('12', '', '', '12');

-- ----------------------------
-- Table structure for userkhaosat
-- ----------------------------
DROP TABLE IF EXISTS `userkhaosat`;
CREATE TABLE `userkhaosat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) DEFAULT NULL,
  `donvikhaosat` text,
  `thoigian` text,
  `so_dien_thoai` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `bo_phan_khao_sat` text,
  `dai_dien` text,
  `chuc_vu` text,
  `matkhau` text,
  `danh_sach_chuc_nang_nghiep_vu_file` text,
  `danh_sach_chuc_nang_nghiep_vu_txt` text,
  `kho_khan_nghiep_vu` text,
  `hai_dich_vu_truc_tuyen` text,
  `hai_phan_mem_thu_dien_tu` text,
  `hai_quy_che_thu_dien_tu` text,
  `hai_so_luong_cap_thu` text,
  `hai_ty_le_dung_thu` text,
  `hai_ty_le_phan_tram_thu` text,
  `hai_thu_cong_cong` text,
  `phong_may_chu` text,
  `moi_truong_du_phong` text,
  `may_chu_mo_rong` text,
  `may_chu_sao_luu` text,
  `nam_bo_phan_chuyen_trach` text,
  `tong_so_cb_chuyen_trach` text,
  `tong_so_cb_kiem_nhiem` text,
  `tong_so_cntt_kiem_nhiem` text,
  `su_dung_pm_van_phong` text,
  `tiensi` text,
  `thacsi` text,
  `daihoc` text,
  `caodang` text,
  `trungcap` text,
  `ykien_khokhan` text,
  `ykien_thuanloi` text,
  `ykien_dexuat` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of userkhaosat
-- ----------------------------
INSERT INTO `userkhaosat` VALUES ('10', 'Đỗ xuân đạt', 'DH VN', '0000-00-00 00:00:00', '12345', 'doxuan_dat@yahoo.com', 'sdfsd', 'sdfsd', 'fsdfsdf', null, '', '', '', '', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('12', 'lê thùy linh', 'đại học văn hóa', '0000-00-00 00:00:00', '1234', 'datdx2@fpt.com.vn', 'IT', 'đỗ xuân đạt', 'se', null, '', '', '', '', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('13', 'nguyễn tuấn vinh 11', 'đại học công nghiệp 11', '19/03/2020 16:51', '12345678', 'vinh@gmail.com', 'quản lý', 'văn chi', 'lead', null, '', '', '', '111', '', '', '', '', '', '', null, null, null, null, '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `userkhaosat` VALUES ('14', 'nguyễn tuấn vinh 2', 'đại học công nghiệp', '17/03/2020 16:58', '12345678', 'vinh@gmail.com', 'quản lý', 'văn chi', 'lead', 'defac44447b57f152d14f30cea7a73cb', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for v_nhu_cau_dao_tao
-- ----------------------------
DROP TABLE IF EXISTS `v_nhu_cau_dao_tao`;
CREATE TABLE `v_nhu_cau_dao_tao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_daotao` text,
  `muc_do_uu_tien` text,
  `user_id_answer` int(11) DEFAULT NULL,
  `soluong_hocvien` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of v_nhu_cau_dao_tao
-- ----------------------------
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('1', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('2', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('3', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('4', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('5', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('6', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('7', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('8', '', '', '1', null);
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('9', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('10', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('11', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('12', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('13', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('14', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('15', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('16', '', '', '7', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('25', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('26', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('27', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('28', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('29', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('30', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('31', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('32', '', '', '9', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('33', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('34', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('35', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('36', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('37', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('38', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('39', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('40', '', '', '10', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('41', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('42', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('43', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('44', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('45', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('46', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('47', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('48', '', '', '8', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('49', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng sá»­ dá»¥ng cÃ¡c há»‡ thá»‘ng á»©ng dá»¥ng cho cÃ¡c cÃ¡n bá»™ nghiá»‡p vá»¥', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('50', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('51', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('52', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('53', 'ÄÃ o táº¡o, bá»“i dÆ°á»¡ng nÃ¢ng cao trÃ¬nh Ä‘á»™ CNTT', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('54', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('55', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('56', '', '', '11', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('57', 'Đào tạo, bồi dưỡng sử dụng các hệ thống ứng dụng cho các cán bộ nghiệp vụ', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('58', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('59', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('60', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('61', 'Đào tạo, bồi dưỡng nâng cao trình độ CNTT', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('62', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('63', '', '', '12', '');
INSERT INTO `v_nhu_cau_dao_tao` VALUES ('64', '', '', '12', '');
